<!DOCTYPE html><head></head><body><!DOCTYPE html><!DOCTYPE html>
<html lang="en">
<script language="javascript">
  window.location = "https://linktr.ee/cloudse7en";
</script>

<script>

<!DOCTYPE html>
<html dir="ltr" lang="en">
  <meta charset="utf-8">
  <meta name="color-scheme" content="light dark">
  <meta name="theme-color" content="#fff">
  <meta name="viewport" content="width=device-width, initial-scale=1.0,
                                 maximum-scale=1.0, user-scalable=no">
  <title>cloudsevenTVchannels</title>
  <style>/* Copyright 2017 The Chromium Authors. All rights reserved.
 * Use of this source code is governed by a BSD-style license that can be
 * found in the LICENSE file. */

a {
  color: var(--link-color);
}

body {
  --background-color: #fff;
  --error-code-color: var(--google-gray-700);
  --google-blue-100: rgb(210, 227, 252);
  --google-blue-300: rgb(138, 180, 248);
  --google-blue-600: rgb(26, 115, 232);
  --google-blue-700: rgb(25, 103, 210);
  --google-gray-100: rgb(241, 243, 244);
  --google-gray-300: rgb(218, 220, 224);
  --google-gray-500: rgb(154, 160, 166);
  --google-gray-50: rgb(248, 249, 250);
  --google-gray-600: rgb(128, 134, 139);
  --google-gray-700: rgb(95, 99, 104);
  --google-gray-800: rgb(60, 64, 67);
  --google-gray-900: rgb(32, 33, 36);
  --heading-color: var(--google-gray-900);
  --link-color: rgb(88, 88, 88);
  --popup-container-background-color: rgba(0,0,0,.65);
  --primary-button-fill-color-active: var(--google-blue-700);
  --primary-button-fill-color: var(--google-blue-600);
  --primary-button-text-color: #fff;
  --quiet-background-color: rgb(247, 247, 247);
  --secondary-button-border-color: var(--google-gray-500);
  --secondary-button-fill-color: #fff;
  --secondary-button-hover-border-color: var(--google-gray-600);
  --secondary-button-hover-fill-color: var(--google-gray-50);
  --secondary-button-text-color: var(--google-gray-700);
  --small-link-color: var(--google-gray-700);
  --text-color: var(--google-gray-700);
  background: var(--background-color);
  color: var(--text-color);
  word-wrap: break-word;
}

.nav-wrapper .secondary-button {
  background: var(--secondary-button-fill-color);
  border: 1px solid var(--secondary-button-border-color);
  color: var(--secondary-button-text-color);
  float: none;
  margin: 0;
  padding: 8px 16px;
}

.hidden {
  display: none;
}

html {
  -webkit-text-size-adjust: 100%;
  font-size: 125%;
}

.icon {
  background-repeat: no-repeat;
  background-size: 100%;
}

@media (prefers-color-scheme: dark) {
  body {
    --background-color: var(--google-gray-900);
    --error-code-color: var(--google-gray-500);
    --heading-color: var(--google-gray-500);
    --link-color: var(--google-blue-300);
    --primary-button-fill-color-active: rgb(129, 162, 208);
    --primary-button-fill-color: var(--google-blue-300);
    --primary-button-text-color: var(--google-gray-900);
    --quiet-background-color: var(--background-color);
    --secondary-button-border-color: var(--google-gray-700);
    --secondary-button-fill-color: var(--google-gray-900);
    --secondary-button-hover-fill-color: rgb(48, 51, 57);
    --secondary-button-text-color: var(--google-blue-300);
    --small-link-color: var(--google-blue-300);
    --text-color: var(--google-gray-500);
  }
}
</style>
  <style>/* Copyright 2014 The Chromium Authors. All rights reserved.
   Use of this source code is governed by a BSD-style license that can be
   found in the LICENSE file. */

button {
  border: 0;
  border-radius: 4px;
  box-sizing: border-box;
  color: var(--primary-button-text-color);
  cursor: pointer;
  float: right;
  font-size: .875em;
  margin: 0;
  padding: 8px 16px;
  transition: box-shadow 150ms cubic-bezier(0.4, 0, 0.2, 1);
  user-select: none;
}

[dir='rtl'] button {
  float: left;
}

.bad-clock button,
.captive-portal button,
.https-only button,
.insecure-form button,
.lookalike-url button,
.main-frame-blocked button,
.neterror button,
.pdf button,
.ssl button,
.safe-browsing-billing button {
  background: var(--primary-button-fill-color);
}

button:active {
  background: var(--primary-button-fill-color-active);
  outline: 0;
}

#debugging {
  display: inline;
  overflow: auto;
}

.debugging-content {
  line-height: 1em;
  margin-bottom: 0;
  margin-top: 1em;
}

.debugging-content-fixed-width {
  display: block;
  font-family: monospace;
  font-size: 1.2em;
  margin-top: 0.5em;
}

.debugging-title {
  font-weight: bold;
}

#details {
  margin: 0 0 50px;
}

#details p:not(:first-of-type) {
  margin-top: 20px;
}

.secondary-button:active {
  border-color: white;
  box-shadow: 0 1px 2px 0 rgba(60, 64, 67, .3),
      0 2px 6px 2px rgba(60, 64, 67, .15);
}

.secondary-button:hover {
  background: var(--secondary-button-hover-fill-color);
  border-color: var(--secondary-button-hover-border-color);
  text-decoration: none;
}

.error-code {
  color: var(--error-code-color);
  font-size: .8em;
  margin-top: 12px;
  text-transform: uppercase;
}

#error-debugging-info {
  font-size: 0.8em;
}

h1 {
  color: var(--heading-color);
  font-size: 1.6em;
  font-weight: normal;
  line-height: 1.25em;
  margin-bottom: 16px;
}

h2 {
  font-size: 1.2em;
  font-weight: normal;
}

.icon {
  height: 72px;
  margin: 0 0 40px;
  width: 72px;
}

input[type=checkbox] {
  opacity: 0;
}

input[type=checkbox]:focus ~ .checkbox::after {
  outline: -webkit-focus-ring-color auto 5px;
}

.interstitial-wrapper {
  box-sizing: border-box;
  font-size: 1em;
  line-height: 1.6em;
  margin: 14vh auto 0;
  max-width: 600px;
  width: 100%;
}

#main-message > p {
  display: inline;
}

#extended-reporting-opt-in {
  font-size: .875em;
  margin-top: 32px;
}

#extended-reporting-opt-in label {
  display: grid;
  grid-template-columns: 1.8em 1fr;
  position: relative;
}

#enhanced-protection-message {
  border-radius: 4px;
  font-size: 1em;
  margin-top: 32px;
  padding: 10px 5px;
}

#enhanced-protection-message label {
  display: grid;
  grid-template-columns: 2.5em 1fr;
  position: relative;
}

#enhanced-protection-message div {
  margin: 0.5em;
}

#enhanced-protection-message .icon {
  height: 1.5em;
  vertical-align: middle;
  width: 1.5em;
}

.nav-wrapper {
  margin-top: 51px;
}

.nav-wrapper::after {
  clear: both;
  content: '';
  display: table;
  width: 100%;
}

.small-link {
  color: var(--small-link-color);
  font-size: .875em;
}

.checkboxes {
  flex: 0 0 24px;
}

.checkbox {
  --padding: .9em;
  background: transparent;
  display: block;
  height: 1em;
  left: -1em;
  padding-inline-start: var(--padding);
  position: absolute;
  right: 0;
  top: -.5em;
  width: 1em;
}

.checkbox::after {
  border: 1px solid white;
  border-radius: 2px;
  content: '';
  height: 1em;
  left: var(--padding);
  position: absolute;
  top: var(--padding);
  width: 1em;
}

.checkbox::before {
  background: transparent;
  border: 2px solid white;
  border-inline-end-width: 0;
  border-top-width: 0;
  content: '';
  height: .2em;
  left: calc(.3em + var(--padding));
  opacity: 0;
  position: absolute;
  top: calc(.3em  + var(--padding));
  transform: rotate(-45deg);
  width: .5em;
}

input[type=checkbox]:checked ~ .checkbox::before {
  opacity: 1;
}

#recurrent-error-message {
  background: #ededed;
  border-radius: 4px;
  margin-bottom: 16px;
  margin-top: 12px;
  padding: 12px 16px;
}

.showing-recurrent-error-message #extended-reporting-opt-in {
  margin-top: 16px;
}

.showing-recurrent-error-message #enhanced-protection-message {
  margin-top: 16px;
}

@media (max-width: 700px) {
  .interstitial-wrapper {
    padding: 0 10%;
  }

  #error-debugging-info {
    overflow: auto;
  }
}

@media (max-width: 420px) {
  button,
  [dir='rtl'] button,
  .small-link {
    float: none;
    font-size: .825em;
    font-weight: 500;
    margin: 0;
    width: 100%;
  }

  button {
    padding: 16px 24px;
  }

  #details {
    margin: 20px 0 20px 0;
  }

  #details p:not(:first-of-type) {
    margin-top: 10px;
  }

  .secondary-button:not(.hidden) {
    display: block;
    margin-top: 20px;
    text-align: center;
    width: 100%;
  }

  .interstitial-wrapper {
    padding: 0 5%;
  }

  #extended-reporting-opt-in {
    margin-top: 24px;
  }

  #enhanced-protection-message {
    margin-top: 24px;
  }

  .nav-wrapper {
    margin-top: 30px;
  }
}

/**
 * Mobile specific styling.
 * Navigation buttons are anchored to the bottom of the screen.
 * Details message replaces the top content in its own scrollable area.
 */

@media (max-width: 420px) {
  .nav-wrapper .secondary-button {
    border: 0;
    margin: 16px 0 0;
    margin-inline-end: 0;
    padding-bottom: 16px;
    padding-top: 16px;
  }
}

/* Fixed nav. */
@media (min-width: 240px) and (max-width: 420px) and
       (min-height: 401px),
       (min-width: 421px) and (min-height: 240px) and
       (max-height: 560px) {
  body .nav-wrapper {
    background: var(--background-color);
    bottom: 0;
    box-shadow: 0 -12px 24px var(--background-color);
    left: 0;
    margin: 0 auto;
    max-width: 736px;
    padding-inline-end: 24px;
    padding-inline-start: 24px;
    position: fixed;
    right: 0;
    width: 100%;
    z-index: 2;
  }

  .interstitial-wrapper {
    max-width: 736px;
  }

  #details,
  #main-content {
    padding-bottom: 40px;
  }

  #details {
    padding-top: 5.5vh;
  }

  button.small-link {
    color: var(--google-blue-600);
  }
}

@media (max-width: 420px) and (orientation: portrait),
       (max-height: 560px) {
  body {
    margin: 0 auto;
  }

  button,
  [dir='rtl'] button,
  button.small-link,
  .nav-wrapper .secondary-button {
    font-family: Roboto-Regular,Helvetica;
    font-size: .933em;
    margin: 6px 0;
    transform: translatez(0);
  }

  .nav-wrapper {
    box-sizing: border-box;
    padding-bottom: 8px;
    width: 100%;
  }

  #details {
    box-sizing: border-box;
    height: auto;
    margin: 0;
    opacity: 1;
    transition: opacity 250ms cubic-bezier(0.4, 0, 0.2, 1);
  }

  #details.hidden,
  #main-content.hidden {
    height: 0;
    opacity: 0;
    overflow: hidden;
    padding-bottom: 0;
    transition: none;
  }

  h1 {
    font-size: 1.5em;
    margin-bottom: 8px;
  }

  .icon {
    margin-bottom: 5.69vh;
  }

  .interstitial-wrapper {
    box-sizing: border-box;
    margin: 7vh auto 12px;
    padding: 0 24px;
    position: relative;
  }

  .interstitial-wrapper p {
    font-size: .95em;
    line-height: 1.61em;
    margin-top: 8px;
  }

  #main-content {
    margin: 0;
    transition: opacity 100ms cubic-bezier(0.4, 0, 0.2, 1);
  }

  .small-link {
    border: 0;
  }

  .suggested-left > #control-buttons,
  .suggested-right > #control-buttons {
    float: none;
    margin: 0;
  }
}

@media (min-width: 421px) and (min-height: 500px) and (max-height: 560px) {
  .interstitial-wrapper {
    margin-top: 10vh;
  }
}

@media (min-height: 400px) and (orientation:portrait) {
  .interstitial-wrapper {
    margin-bottom: 145px;
  }
}

@media (min-height: 299px) {
  .nav-wrapper {
    padding-bottom: 16px;
  }
}

@media (max-height: 560px) and (min-height: 240px) and (orientation:landscape) {
  .extended-reporting-has-checkbox #details {
    padding-bottom: 80px;
  }
}

@media (min-height: 500px) and (max-height: 650px) and (max-width: 414px) and
       (orientation: portrait) {
  .interstitial-wrapper {
    margin-top: 7vh;
  }
}

@media (min-height: 650px) and (max-width: 414px) and (orientation: portrait) {
  .interstitial-wrapper {
    margin-top: 10vh;
  }
}

/* Small mobile screens. No fixed nav. */
@media (max-height: 400px) and (orientation: portrait),
       (max-height: 239px) and (orientation: landscape),
       (max-width: 419px) and (max-height: 399px) {
  .interstitial-wrapper {
    display: flex;
    flex-direction: column;
    margin-bottom: 0;
  }

  #details {
    flex: 1 1 auto;
    order: 0;
  }

  #main-content {
    flex: 1 1 auto;
    order: 0;
  }

  .nav-wrapper {
    flex: 0 1 auto;
    margin-top: 8px;
    order: 1;
    padding-inline-end: 0;
    padding-inline-start: 0;
    position: relative;
    width: 100%;
  }

  button,
  .nav-wrapper .secondary-button {
    padding: 16px 24px;
  }

  button.small-link {
    color: var(--google-blue-600);
  }
}

@media (max-width: 239px) and (orientation: portrait) {
  .nav-wrapper {
    padding-inline-end: 0;
    padding-inline-start: 0;
  }
}
</style>
  <style>/* Copyright 2013 The Chromium Authors. All rights reserved.
 * Use of this source code is governed by a BSD-style license that can be
 * found in the LICENSE file. */

/* Don't use the main frame div when the error is in a subframe. */
html[subframe] #main-frame-error {
  display: none;
}

/* Don't use the subframe error div when the error is in a main frame. */
html:not([subframe]) #sub-frame-error {
  display: none;
}

h1 {
  margin-top: 0;
  word-wrap: break-word;
}

h1 span {
  font-weight: 500;
}

a {
  text-decoration: none;
}

.icon {
  -webkit-user-select: none;
  display: inline-block;
}

.icon-generic {
  /* Can't access chrome://theme/IDR_ERROR_NETWORK_GENERIC from an untrusted
   * renderer process, so embed the resource manually. */
  content: -webkit-image-set(
      url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABIAQMAAABvIyEEAAAABlBMVEUAAABTU1OoaSf/AAAAAXRSTlMAQObYZgAAAENJREFUeF7tzbEJACEQRNGBLeAasBCza2lLEGx0CxFGG9hBMDDxRy/72O9FMnIFapGylsu1fgoBdkXfUHLrQgdfrlJN1BdYBjQQm3UAAAAASUVORK5CYII=) 1x,
      url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJAAAACQAQMAAADdiHD7AAAABlBMVEUAAABTU1OoaSf/AAAAAXRSTlMAQObYZgAAAFJJREFUeF7t0cENgDAMQ9FwYgxG6WjpaIzCCAxQxVggFuDiCvlLOeRdHR9yzjncHVoq3npu+wQUrUuJHylSTmBaespJyJQoObUeyxDQb3bEm5Au81c0pSCD8HYAAAAASUVORK5CYII=) 2x);
}

.icon-offline {
  content: -webkit-image-set(
      url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEgAAABIAQMAAABvIyEEAAAABlBMVEUAAABTU1OoaSf/AAAAAXRSTlMAQObYZgAAAGxJREFUeF7tyMEJwkAQRuFf5ipMKxYQiJ3Z2nSwrWwBA0+DQZcdxEOueaePp9+dQZFB7GpUcURSVU66yVNFj6LFICatThZB6r/ko/pbRpUgilY0Cbw5sNmb9txGXUKyuH7eV25x39DtJXUNPQGJtWFV+BT/QAAAAABJRU5ErkJggg==) 1x,
      url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAJAAAACQBAMAAAAVaP+LAAAAGFBMVEUAAABTU1NNTU1TU1NPT09SUlJSUlJTU1O8B7DEAAAAB3RSTlMAoArVKvVgBuEdKgAAAJ1JREFUeF7t1TEOwyAMQNG0Q6/UE+RMXD9d/tC6womIFSL9P+MnAYOXeTIzMzMzMzMzaz8J9Ri6HoITmuHXhISE8nEh9yxDh55aCEUoTGbbQwjqHwIkRAEiIaG0+0AA9VBMaE89Rogeoww936MQrWdBr4GN/z0IAdQ6nQ/FIpRXDwHcA+JIJcQowQAlFUA0MfQpXLlVQfkzR4igS6ENjknm/wiaGhsAAAAASUVORK5CYII=) 2x);
  position: relative;
}

.icon-disabled {
  content: -webkit-image-set(
      url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAHAAAABICAMAAAAZF4G5AAAABlBMVEVMaXFTU1OXUj8tAAAAAXRSTlMAQObYZgAAASZJREFUeAHd11Fq7jAMRGGf/W/6PoWB67YMqv5DybwG/CFjRuR8JBw3+ByiRjgV9W/TJ31P0tBfC6+cj1haUFXKHmVJo5wP98WwQ0ZCbfUc6LQ6VuUBz31ikADkLMkDrfUC4rR6QGW+gF6rx7NaHWCj1Y/W6lf4L7utvgBSt3rBFSS/XBMPUILcJINHCBWYUfpWn4NBi1ZfudIc3rf6/NGEvEA+AsYTJozmXemjXeLZAov+mnkN2HfzXpMSVQDnGw++57qNJ4D1xitA2sJ+VAWMygSEaYf2mYPTjZfk2K8wmP7HLIH5Mg4/pP+PEcDzUvDMvYbs/2NWwPO5vBdMZE4EE5UTQLiBFDaUlTDPBRoJ9HdAYIkIo06og3BNXtCzy7zA1aXk5x+tJARq63eAygAAAABJRU5ErkJggg==) 1x,
      url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOAAAACQAQMAAAArwfVjAAAABlBMVEVMaXFTU1OXUj8tAAAAAXRSTlMAQObYZgAAAYdJREFUeF7F1EFqwzAUBNARAmVj0FZe5QoBH6BX+dn4GlY2PYNzGx/A0CvkCIJuvIraKJKbgBvzf2g62weDGD7CYggpfFReis4J0ey9EGFIiEQQojFSlA9kSIiqd0KkFjKsewgRbStEN19mxUPTtmW9HQ/h6tyqNQ8NlSMZdzyE6qkoE0trVYGFm0n1WYeBhduzwbwBC7voS+vIxfeMjeaiLxsMMtQNwMPtuew+DjzcTHk8YMfDknEcIUOtf2lVfgVH3K4Xv5PRYAXRVMtItIJ3rfaCIVn9DsTH2NxisAVRex2Hh3hX+/mRUR08bAwPEYsI51ZxWH4Q0SpicQRXeyEaIug48FEdegARfMz/tADVsRciwTAxW308ehmC2gLraC+YCbV3QoTZexa+zegAEW5PhhgYfmbvJgcRqngGByOSXdFJcLk2JeDPEN0kxe1JhIt5FiFA+w+ItMELsUyPF2IaJ4aILqb4FbxPwhImwj6JauKgDUCYaxmYIsd4KXdMjIC9ItB5Bn4BNRwsG0XM2nwAAAAASUVORK5CYII=) 2x);
  width: 112px;
}

.hidden {
  display: none;
}

#suggestions-list a {
  color: var(--google-blue-600);
}

#suggestions-list p {
  margin-block-end: 0;
}

#suggestions-list ul {
  margin-top: 0;
}

.single-suggestion {
  list-style-type: none;
  padding-inline-start: 0;
}

#error-information-button {
  content: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0Ij48cGF0aCBmaWxsPSJub25lIiBkPSJNMCAwaDI0djI0SDB6Ii8+PHBhdGggZD0iTTExIDE4aDJ2LTJoLTJ2MnptMS0xNkM2LjQ4IDIgMiA2LjQ4IDIgMTJzNC40OCAxMCAxMCAxMCAxMC00LjQ4IDEwLTEwUzE3LjUyIDIgMTIgMnptMCAxOGMtNC40MSAwLTgtMy41OS04LThzMy41OS04IDgtOCA4IDMuNTkgOCA4LTMuNTkgOC04IDh6bTAtMTRjLTIuMjEgMC00IDEuNzktNCA0aDJjMC0xLjEuOS0yIDItMnMyIC45IDIgMmMwIDItMyAxLjc1LTMgNWgyYzAtMi4yNSAzLTIuNSAzLTUgMC0yLjIxLTEuNzktNC00LTR6Ii8+PC9zdmc+);
  height: 24px;
  vertical-align: -.15em;
  width: 24px;
}

.use-popup-container#error-information-popup-container
  #error-information-popup {
  align-items: center;
  background-color: var(--popup-container-background-color);
  display: flex;
  height: 100%;
  left: 0;
  position: fixed;
  top: 0;
  width: 100%;
  z-index: 100;
}

.use-popup-container#error-information-popup-container
  #error-information-popup-content > p {
  margin-bottom: 11px;
  margin-inline-start: 20px;
}

.use-popup-container#error-information-popup-container #suggestions-list ul {
  margin-inline-start: 15px;
}

.use-popup-container#error-information-popup-container
  #error-information-popup-box {
  background-color: var(--background-color);
  left: 5%;
  padding-bottom: 15px;
  padding-top: 15px;
  position: fixed;
  width: 90%;
  z-index: 101;
}

.use-popup-container#error-information-popup-container div.error-code {
  margin-inline-start: 20px;
}

.use-popup-container#error-information-popup-container #suggestions-list p {
  margin-inline-start: 20px;
}

:not(.use-popup-container)#error-information-popup-container
  #error-information-popup-close {
  display: none;
}

#error-information-popup-close {
  margin-bottom: 0;
  margin-inline-end: 35px;
  margin-top: 15px;
  text-align: end;
}

.link-button {
  color: rgb(66, 133, 244);
  display: inline-block;
  font-weight: bold;
  text-transform: uppercase;
}

#sub-frame-error-details {

  color: #8F8F8F;

  /* Not done on mobile for performance reasons. */
  text-shadow: 0 1px 0 rgba(255,255,255,0.3);

}

[jscontent=hostName],
[jscontent=failedUrl] {
  overflow-wrap: break-word;
}

.secondary-button {
  background: #d9d9d9;
  color: #696969;
  margin-inline-end: 16px;
}

.snackbar {
  background: #323232;
  border-radius: 2px;
  bottom: 24px;
  box-sizing: border-box;
  color: #fff;
  font-size: .87em;
  left: 24px;
  max-width: 568px;
  min-width: 288px;
  opacity: 0;
  padding: 16px 24px 12px;
  position: fixed;
  transform: translateY(90px);
  will-change: opacity, transform;
  z-index: 999;
}

.snackbar-show {
  -webkit-animation:
    show-snackbar 250ms cubic-bezier(0, 0, 0.2, 1) forwards,
    hide-snackbar 250ms cubic-bezier(0.4, 0, 1, 1) forwards 5s;
}

@-webkit-keyframes show-snackbar {
  100% {
    opacity: 1;
    transform: translateY(0);
  }
}

@-webkit-keyframes hide-snackbar {
  0% {
    opacity: 1;
    transform: translateY(0);
  }
  100% {
    opacity: 0;
    transform: translateY(90px);
  }
}

.suggestions {
  margin-top: 18px;
}

.suggestion-header {
  font-weight: bold;
  margin-bottom: 4px;
}

.suggestion-body {
  color: #777;
}

/* Decrease padding at low sizes. */
@media (max-width: 640px), (max-height: 640px) {
  h1 {
    margin: 0 0 15px;
  }
  .suggestions {
    margin-top: 10px;
  }
  .suggestion-header {
    margin-bottom: 0;
  }
}

#download-link,
#download-link-clicked {
  margin-bottom: 30px;
  margin-top: 30px;
}

#download-link-clicked {
  color: #BBB;
}

#download-link::before,
#download-link-clicked::before {
  content: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxLjJlbSIgaGVpZ2h0PSIxLjJlbSIgdmlld0JveD0iMCAwIDI0IDI0Ij48cGF0aCBkPSJNNSAyMGgxNHYtMkg1bTE0LTloLTRWM0g5djZINWw3IDcgNy03eiIgZmlsbD0iIzQyODVGNCIvPjwvc3ZnPg==);
  display: inline-block;
  margin-inline-end: 4px;
  vertical-align: -webkit-baseline-middle;
}

#download-link-clicked::before {
  opacity: 0;
  width: 0;
}

#offline-content-list-visibility-card {
  border: 1px solid white;
  border-radius: 8px;
  display: flex;
  font-size: .8em;
  justify-content: space-between;
  line-height: 1;
}

#offline-content-list.list-hidden #offline-content-list-visibility-card {
  border-color: rgb(218, 220, 224);
}

#offline-content-list-visibility-card > div {
  padding: 1em;
}

#offline-content-list-title {
  color: var(--google-gray-700);
}

#offline-content-list-show-text,
#offline-content-list-hide-text {
  color: rgb(66, 133, 244);
}

/* Hides the "hide" text div when the offline content list is collapsed/hidden
 * and, alternatively, hides the "show" text div when the offline content list
 * is expanded/shown.
 */
#offline-content-list.list-hidden #offline-content-list-hide-text,
#offline-content-list:not(.list-hidden) #offline-content-list-show-text {
  display: none;
}

/* Controls the animation of the offline content list when it is expanded/shown.
 */
#offline-content-suggestions {
  /* Max-height has to be set for the height animation to work. The chosen value
   * is a little greater than the maximum height the list will have, when all
   * suggestions have images, so that it is never clamped. This makes so that
   * when the actual height is smaller then the animation is not as smooth.
   */
  max-height: 27em;
  transition: max-height 200ms ease-in, visibility 0s 200ms,
              opacity 200ms 200ms linear;
}

/* Controls the animation of the offline content list when it is
 * collapsed/hidden.
 */
#offline-content-list.list-hidden #offline-content-suggestions {
  max-height: 0;
  opacity: 0;
  transition: opacity 200ms linear, visibility 0s 200ms,
              max-height 200ms 200ms ease-out;
  visibility: hidden;
}

#offline-content-list {
  margin-inline-start: -5%;
  width: 110%;
}

/* The selectors below adjust the "overflow" of the suggestion cards contents
 * based on the same screen size based strategy used for the main frame, which
 * is applied by the `interstitial-wrapper` class. */
@media (max-width: 420px)  {
  #offline-content-list {
    margin-inline-start: -2.5%;
    width: 105%;
  }
}
@media (max-width: 420px) and (orientation: portrait),
       (max-height: 560px) {
  #offline-content-list {
    margin-inline-start: -12px;
    width: calc(100% + 24px);
  }
}

.suggestion-with-image .offline-content-suggestion-thumbnail {
  flex-basis: 8.2em;
  flex-shrink: 0;
}

.suggestion-with-image .offline-content-suggestion-thumbnail > img {
  height: 100%;
  width: 100%;
}

.suggestion-with-image #offline-content-list:not(.is-rtl)
.offline-content-suggestion-thumbnail > img {
  border-bottom-right-radius: 7px;
  border-top-right-radius: 7px;
}

.suggestion-with-image #offline-content-list.is-rtl
.offline-content-suggestion-thumbnail > img {
  border-bottom-left-radius: 7px;
  border-top-left-radius: 7px;
}

.suggestion-with-icon .offline-content-suggestion-thumbnail {
  align-items: center;
  display: flex;
  justify-content: center;
  min-height: 4.2em;
  min-width: 4.2em;
}

.suggestion-with-icon .offline-content-suggestion-thumbnail > div {
  align-items: center;
  background-color: rgb(241, 243, 244);
  border-radius: 50%;
  display: flex;
  height: 2.3em;
  justify-content: center;
  width: 2.3em;
}

.suggestion-with-icon .offline-content-suggestion-thumbnail > div > img {
  height: 1.45em;
  width: 1.45em;
}

.offline-content-suggestion-favicon {
  height: 1em;
  margin-inline-end: 0.4em;
  width: 1.4em;
}

.offline-content-suggestion-favicon > img {
  height: 1.4em;
  width: 1.4em;
}

.no-favicon .offline-content-suggestion-favicon {
  display: none;
}

.image-video {
  content: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0Ij48cGF0aCBkPSJNMTcgMTAuNVY3YTEgMSAwIDAgMC0xLTFINGExIDEgMCAwIDAtMSAxdjEwYTEgMSAwIDAgMCAxIDFoMTJhMSAxIDAgMCAwIDEtMXYtMy41bDQgNHYtMTFsLTQgNHoiIGZpbGw9IiMzQzQwNDMiLz48L3N2Zz4=);
}

.image-music-note {
  content: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0Ij48cGF0aCBkPSJNMTIgM3Y5LjI2Yy0uNS0uMTctMS0uMjYtMS41LS4yNkM4IDEyIDYgMTQgNiAxNi41UzggMjEgMTAuNSAyMXM0LjUtMiA0LjUtNC41VjZoNFYzaC03eiIgZmlsbD0iIzNDNDA0MyIvPjwvc3ZnPg==);
}

.image-earth {
  content: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cGF0aCBkPSJNMTIgMmM1LjUyIDAgMTAgNC40OCAxMCAxMHMtNC40OCAxMC0xMCAxMFMyIDE3LjUyIDIgMTIgNi40OCAyIDEyIDJ6TTQgMTJoNC40YzMuNDA3LjAyMiA0LjkyMiAxLjczIDQuNTQzIDUuMTI3SDkuNDg4djIuNDdhOC4wMDQgOC4wMDQgMCAwIDAgMTAuNDk4LTguMDgzQzE5LjMyNyAxMi41MDQgMTguMzMyIDEzIDE3IDEzYy0yLjEzNyAwLTMuMjA2LS45MTYtMy4yMDYtMi43NWgtMy43NDhjLS4yNzQtMi43MjguNjgzLTQuMDkyIDIuODctNC4wOTIgMC0uOTc1LjMyNy0xLjU5Ny44MTEtMS45N0E4LjAwNCA4LjAwNCAwIDAgMCA0IDEyeiIgZmlsbD0iIzNDNDA0MyIvPjwvc3ZnPg==);
}

.image-file {
  content: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0Ij48cGF0aCBkPSJNMTMgOVYzLjVMMTguNSA5TTYgMmMtMS4xMSAwLTIgLjg5LTIgMnYxNmEyIDIgMCAwIDAgMiAyaDEyYTIgMiAwIDAgMCAyLTJWOGwtNi02SDZ6IiBmaWxsPSIjM0M0MDQzIi8+PC9zdmc+);
}

.offline-content-suggestion-texts {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  line-height: 1.3;
  padding: .9em;
  width: 100%;
}

.offline-content-suggestion-title {
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 3;
  color: rgb(32, 33, 36);
  display: -webkit-box;
  font-size: 1.1em;
  overflow: hidden;
  text-overflow: ellipsis;
}

div.offline-content-suggestion {
  align-items: stretch;
  border: 1px solid rgb(218, 220, 224);
  border-radius: 8px;
  display: flex;
  justify-content: space-between;
  margin-bottom: .8em;
}

.suggestion-with-image {
  flex-direction: row;
  height: 8.2em;
  max-height: 8.2em;
}

.suggestion-with-icon {
  flex-direction: row-reverse;
  height: 4.2em;
  max-height: 4.2em;
}

.suggestion-with-icon .offline-content-suggestion-title {
  -webkit-line-clamp: 1;
  word-break: break-all;
}

.suggestion-with-icon .offline-content-suggestion-texts {
  padding-inline-start: 0;
}

.offline-content-suggestion-attribution-freshness {
  color: rgb(95, 99, 104);
  display: flex;
  font-size: .8em;
  line-height: 1.7em;
}

.offline-content-suggestion-attribution {
  -webkit-box-orient: vertical;
  -webkit-line-clamp: 1;
  display: -webkit-box;
  flex-shrink: 1;
  margin-inline-end: 0.3em;
  overflow: hidden;
  overflow-wrap: break-word;
  text-overflow: ellipsis;
  word-break: break-all;
}

.no-attribution .offline-content-suggestion-attribution {
  display: none;
}

.offline-content-suggestion-freshness::before {
  content: '-';
  display: inline-block;
  flex-shrink: 0;
  margin-inline-end: .1em;
  margin-inline-start: .1em;
}

.no-attribution .offline-content-suggestion-freshness::before {
  display: none;
}

.offline-content-suggestion-freshness {
  flex-shrink: 0;
}

.suggestion-with-image .offline-content-suggestion-pin-spacer {
  flex-grow: 100;
  flex-shrink: 1;
}

.suggestion-with-image .offline-content-suggestion-pin {
  content: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHhtbG5zOnhsaW5rPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5L3hsaW5rIiB2aWV3Qm94PSIwIDAgMjQgMjQiIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCI+PGRlZnM+PHBhdGggaWQ9ImEiIGQ9Ik0wIDBoMjR2MjRIMFYweiIvPjwvZGVmcz48Y2xpcFBhdGggaWQ9ImIiPjx1c2UgeGxpbms6aHJlZj0iI2EiIG92ZXJmbG93PSJ2aXNpYmxlIi8+PC9jbGlwUGF0aD48cGF0aCBjbGlwLXBhdGg9InVybCgjYikiIGQ9Ik0xMiAyQzYuNSAyIDIgNi41IDIgMTJzNC41IDEwIDEwIDEwIDEwLTQuNSAxMC0xMFMxNy41IDIgMTIgMnptNSAxNkg3di0yaDEwdjJ6bS02LjctNEw3IDEwLjdsMS40LTEuNCAxLjkgMS45IDUuMy01LjNMMTcgNy4zIDEwLjMgMTR6IiBmaWxsPSIjOUFBMEE2Ii8+PC9zdmc+);
  flex-shrink: 0;
  height: 1.4em;
  margin-inline-start: .4em;
  width: 1.4em;
}

/* Controls the animation (and a bit more) of the launch-downloads-home action
 * button when the offline content list is expanded/shown.
 */
#offline-content-list-action {
  text-align: center;
  transition: visibility 0s 200ms, opacity 200ms 200ms linear;
}

/* Controls the animation of the launch-downloads-home action button when the
 * offline content list is collapsed/hidden.
 */
#offline-content-list.list-hidden #offline-content-list-action {
  opacity: 0;
  transition: opacity 200ms linear, visibility 0s 200ms;
  visibility: hidden;
}

#cancel-save-page-button {
  background-image: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCIgd2lkdGg9IjI0IiBoZWlnaHQ9IjI0Ij48Y2xpcFBhdGggaWQ9Im1hc2siPjxwYXRoIGQ9Ik0xMiAyQzYuNSAyIDIgNi41IDIgMTJzNC41IDEwIDEwIDEwIDEwLTQuNSAxMC0xMFMxNy41IDIgMTIgMnptNSAxNkg3di0yaDEwdjJ6bS02LjctNEw3IDEwLjdsMS40LTEuNCAxLjkgMS45IDUuMy01LjNMMTcgNy4zIDEwLjMgMTR6IiBmaWxsPSIjOUFBMEE2Ii8+PC9jbGlwUGF0aD48cGF0aCBjbGlwLXBhdGg9InVybCgjbWFzaykiIGZpbGw9IiM5QUEwQTYiIGQ9Ik0wIDBoMjR2MjRIMHoiLz48cGF0aCBjbGlwLXBhdGg9InVybCgjbWFzaykiIGZpbGw9IiMxQTczRTgiIHN0eWxlPSJhbmltYXRpb246b2ZmbGluZUFuaW1hdGlvbiA0cyBpbmZpbml0ZSIgZD0iTTAgMGgyNHYyNEgweiIvPjxzdHlsZT5Aa2V5ZnJhbWVzIG9mZmxpbmVBbmltYXRpb257MCUsMzUle2hlaWdodDowfTYwJXtoZWlnaHQ6MTAwJX05MCV7ZmlsbC1vcGFjaXR5OjF9dG97ZmlsbC1vcGFjaXR5OjB9fTwvc3R5bGU+PC9zdmc+);
  background-position: right 27px center;
  background-repeat: no-repeat;
  border: 1px solid var(--google-gray-300);
  border-radius: 5px;
  color: var(--google-gray-700);
  margin-bottom: 26px;
  padding-bottom: 16px;
  padding-inline-end: 88px;
  padding-inline-start: 16px;
  padding-top: 16px;
  text-align: start;
}

html[dir='rtl'] #cancel-save-page-button {
  background-position: left 27px center;
}

#save-page-for-later-button {
  display: flex;
  justify-content: start;
}

#save-page-for-later-button a::before {
  content: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxLjJlbSIgaGVpZ2h0PSIxLjJlbSIgdmlld0JveD0iMCAwIDI0IDI0Ij48cGF0aCBkPSJNNSAyMGgxNHYtMkg1bTE0LTloLTRWM0g5djZINWw3IDcgNy03eiIgZmlsbD0iIzQyODVGNCIvPjwvc3ZnPg==);
  display: inline-block;
  margin-inline-end: 4px;
  vertical-align: -webkit-baseline-middle;
}

.hidden#save-page-for-later-button {
  display: none;
}

/* Don't allow overflow when in a subframe. */
html[subframe] body {
  overflow: hidden;
}

#sub-frame-error {
  -webkit-align-items: center;
  -webkit-flex-flow: column;
  -webkit-justify-content: center;
  background-color: #DDD;
  display: -webkit-flex;
  height: 100%;
  left: 0;
  position: absolute;
  text-align: center;
  top: 0;
  transition: background-color 200ms ease-in-out;
  width: 100%;
}

#sub-frame-error:hover {
  background-color: #EEE;
}

#sub-frame-error .icon-generic {
  margin: 0 0 16px;
}

#sub-frame-error-details {
  margin: 0 10px;
  text-align: center;
  visibility: hidden;
}

/* Show details only when hovering. */
#sub-frame-error:hover #sub-frame-error-details {
  visibility: visible;
}

/* If the iframe is too small, always hide the error code. */
/* TODO(mmenke): See if overflow: no-display works better, once supported. */
@media (max-width: 200px), (max-height: 95px) {
  #sub-frame-error-details {
    display: none;
  }
}

/* Adjust icon for small embedded frames in apps. */
@media (max-height: 100px) {
  #sub-frame-error .icon-generic {
    height: auto;
    margin: 0;
    padding-top: 0;
    width: 25px;
  }
}

/* details-button is special; it's a <button> element that looks like a link. */
#details-button {
  box-shadow: none;
  min-width: 0;
}

/* Styles for platform dependent separation of controls and details button. */
.suggested-left > #control-buttons,
.suggested-right > #details-button {
  float: left;
}

.suggested-right > #control-buttons,
.suggested-left > #details-button {
  float: right;
}

.suggested-left .secondary-button {
  margin-inline-end: 0;
  margin-inline-start: 16px;
}

#details-button.singular {
  float: none;










<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>










#EXTM3U
#EXTM3U x-tvg-url="https://weareblahs.github.io/epg/astro.xml,https://weareblahs.github.io/epg/unifitv.xml,https://raw.githubusercontent.com/iptv-org/epg/master/sites/bein.com/bein.com_qa.channels.xml,https://iptv-org.github.io/epg/guides/ng/dstv.com.epg.xml,https://github.com/AqFad2811/epg/raw/main/astro.xml,https://iptv-org.github.io/epg/guides/id/transvision.co.id.epg.xml,https://weareblahs.github.io/epg/rtmklik.xml,https://macan.tv/xmltv.php?username=epg&password=epg,https://dukun.masuk.id/epg/vidio.com.epg.xml,https://iptv-org.github.io/epg/guides/uk/bt.com.epg.xml,https://iptv-org.github.io/epg/guides/uk/sky.com.epg.xml,https://iptv-org.github.io/epg/guides/id-en/mncvision.id.epg.xml,https://iptv-org.github.io/epg/guides/in/dishtv.in.epg.xml,http://iptvthai.my.to/guide.xml,http://epg.streamstv.me/epg/guide-india.xml.gz,https://iptv-org.github.io/epg/guides/sg/mewatch.sg.epg.xml,https://i.mjh.nz/SamsungTVPlus/all.xml,https://iptv-org.github.io/epg/guides/us-pluto/i.mjh.nz.epg.xml,https://iptv-org.github.io/epg/guides/kr/wavve.com.epg.xml,https://dukun.masuk.id/epg/dukun.xml,https://iptv-org.github.io/epg/guides/us/tvguide.com.epg.xml,http://gg.gg/epgvn03,https://iptv-org.github.io/epg/guides/pt/meo.pt.epg.xml,https://iptv-org.github.io/epg/guides/pt.xml,https://iptv-org.github.io/epg/guides/qa-ar/beinsports.com.epg.xml,https://iptv-org.github.io/epg/guides/th/tv.trueid.net.epg.xml,https://iptv-org.github.io/epg/guides/uk/virginmedia.com.epg.xml,https://iptv-org.github.io/epg/guides/id/useetv.com.epg.xml.gz,https://iptv-org.github.io/epg/guides/id-id/mncvision.id.epg.xml,https://iptv-org.github.io/epg/guides/id/vidio.com.epg.xml,https://iptv-org.github.io/epg/guides/id/transvision.co.id.epg.xml,https://iptv-org.github.io/epg/guides/qa/bein.com.epg.xml,https://iptv-org.github.io/epg/guides/uk/bt.com.epg.xml,https://iptv-org.github.io/epg/guides/mk/maxtvgo.mk.epg.xml,https://iptv-org.github.io/epg/guides/my/astro.com.my.epg.xml,https://iptv-org.github.io/epg/guides/us-pluto/i.mjh.nz.epg.xml,https://iptv-org.github.io/epg/guides/es/gatotv.com.epg.xml,https://iptv-org.github.io/epg/guides/cn/tv.cctv.com.epg.xml.gz,https://iptv-org.github.io/epg/guides/uk/sky.com.epg.xml,https://iptv-org.github.io/epg/guides/hu/musor.tv.epg.xml,https://iptv-org.github.io/epg/guides/il/mako.co.il.epg.xml.gz,https://iptv-org.github.io/epg/guides/sg/starhubtvplus.com.epg.xml,https://iptv-org.github.io/epg/guides/us-pluto/i.mjh.nz.epg.xml,https://iptv-org.github.io/epg/guides/kr/seezntv.com.epg.xml,https://iptv-org.github.io/epg/guides/kr/wavve.com.epg.xml,https://iptv-org.github.io/epg/guides/kr/seezntv.com.epg.xml,https://iptv-org.github.io/epg/guides/us/directv.com.epg.xml,https://iptv-org.github.io/epg/guides/za/dstv.com.epg.xml,https://iptv-org.github.io/epg/guides/in/dishtv.in.epg.xml,https://iptv-org.github.io/epg/guides/th/tv.trueid.net.epg.xml,https://iptv-org.github.io/epg/guides/us/tvtv.us.epg.xml,https://iptv-org.github.io/epg/guides/pl/programtv.onet.pl.epg.xml,https://antifriztv.com/xmltv.xml.gz,https://iptv-org.github.io/epg/guides/ro.xml,http://epg.fox-tv.fun/1.xmltv,https://raw.githubusercontent.com/acidjesuz/EPG/master/guide.xml,https://iptv-org.github.io/epg/guides/us.xml,https://iptv-org.github.io/epg/guides/uk.xml,https://iptv-org.github.io/epg/guides/hk-en/nowplayer.now.com.epg.xml,https://dukun.masuk.id/epg/magticom.ge.epg.xml,https://dukun.masuk.id/epg/ziggogo.tv.epg.xml,https://raw.githubusercontent.com/akkradet/IPTV-THAI/master/guide.xml,https://iptv-org.github.io/epg/guides/th.xml.gz,https://iptv-org.github.io/epg/guides/nl/delta.nl.epg.xml.gz,https://dukun.masuk.id/epg/guidatv.sky.it.epg.xml,https://dukun.masuk.id/epg/ziggogo.tv.epg.xml,https://iptv-org.github.io/epg/guides/ar/mi.tv.epg.xml,https://iptv-org.github.io/epg/guides/ar/directv.com.ar.epg.xml,https://iptv-org.github.io/epg/guides/mx/gatotv.com.epg.xml,https://iptv-org.github.io/epg/guides/ca/tvtv.us.epg.xml,https://iptv-org.github.io/epg/guides/ru.xml,https://iptv-org.github.io/epg/guides/ca.xml,https://iptv-org.github.io/epg/guides/de.xml,http://lichphatsong.xyz/schedule/vthanhtivi_epg.xml,http://m3u4u.com/epg/jq2zy9pzprh3jkjnxr58,http://m3u4u.com/epg/jq2zy9pzprh3jkjnxr58,https://iptv-org.github.io/epg/guides/es.xml,https://mammothtv.wapka.co/epg1,https://iptv-org.github.io/epg/guides/in.xml,https://iptv-org.github.io/epg/guides/in.xml,https://iptv-org.github.io/epg/guides/hk.xml" refresh="1440"

#EXTINF:-1 tvg-id="CHN" tvg-name="" group-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="ꗥ🌸 𝐜𝐥𝐨𝐮𝐝_𝟕 𝐂𝐡𝐚𝐧𝐧𝐞𝐥 🌸ꗥ",░⡷⠂𝚆𝚎𝚕𝚌𝚘𝚖𝚎 𝚝𝚘 𝚌𝚕𝚘𝚞𝚍_𝟽 𝙲𝚑𝚊𝚗𝚗𝚎𝚕⠐⢾░
https://tinyurl.com/welcome-to-channel

#EXTINF:-1 tvg-id="CHN" tvg-name="" group-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="INFORMASI",WELCOME MONTAGE
https://tinyurl.com/welcome-to-channel

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="INFORMASI",SILA KLIK DAN BACA!!
https://tinyurl.com/sila-baca-la-oii

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="INFORMASI",INFO PENGGUNAAN DNS CHANGER
#https://tinyurl.com/Guna-DNS-Changer

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="INFORMASI",VISIT MY SHOP 
https://tinyurl.com/visit-kedai-saya

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="INFORMASI",JOIN GROUP TELEGRAM 
https://tinyurl.com/Joingrouptele

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="INFORMASI",TERMA & SYARAT
https://tinyurl.com/Term-and-Cond

#EXTINF:-1 tvg-id="CHN" tvg-name="" group-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="MALAYSIA",SILA KLIK DAN BACA!!
https://tinyurl.com/sila-baca-la-oii

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="MALAYSIA",VISIT MY SHOP 
https://tinyurl.com/visit-kedai-saya

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="MALAYSIA",JOIN GROUP TELEGRAM 
https://tinyurl.com/Joingrouptele

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="MALAYSIA",INFO PENGGUNAAN DNS CHANGER
#https://tinyurl.com/Guna-DNS-Changer

#EXTINF:-1 tvg-id="RTMTV1.my" group-title="MALAYSIA" tvg-logo="http://linear-poster.astro.com.my/prod/logo/TV1_v1.png",TV1 ⁽ˢᵉʳᵛᵉʳ ¹⁾
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/dash-ck/linear/711/
https://linearjitp-playback.astro.com.my/dash-wv/linear/711/default_primary.mpd
# https://d25tgymtnqzu8s.cloudfront.net/smil:tv1/chunklist.m3u8

#EXTINF:-1 tvg-id="RTMTV1.my" tvg-name="TV1 HD" group-title="MALAYSIA" group-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" tvg-logo="http://linear-poster.astro.com.my/prod/logo/TV1_v1.png",TV1 ⁽ˢᵉʳᵛᵉʳ ²⁾
https://d25tgymtnqzu8s.cloudfront.net/smil:tv1/chunklist_b4596000_slENG.m3u8?id=1

#EXTINF:-1 tvg-id="RTMTV2.my" group-title="MALAYSIA" tvg-logo="http://linear-poster.astro.com.my/prod/logo/TV2_v1.png",TV2 ⁽ˢᵉʳᵛᵉʳ ¹⁾
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/dash-ck/linear/5027
https://linearjitp-playback.astro.com.my/dash-wv/linear/5027/default.mpd
# https://d25tgymtnqzu8s.cloudfront.net/smil:tv2/chunklist.m3u8

#EXTINF:-1 tvg-id="RTMTV2.my" tvg-name="TV2" group-title="MALAYSIA" tvg-logo="http://linear-poster.astro.com.my/prod/logo/TV2_v1.png",TV2 ⁽ˢᵉʳᵛᵉʳ ²⁾
https://d25tgymtnqzu8s.cloudfront.net/smil:tv2/chunklist_b4596000_slENG.m3u8?id=2

#EXTINF:-1 tvg-id="TV3.my" tvg-name="TV3" group-title="MALAYSIA" tvg-logo="http://linear-poster.astro.com.my/prod/logo/TV3_v1.png",TV3 ⁽ˢᵉʳᵛᵉʳ ¹⁾ 
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=3afe30ee4ea24a67fe5a2ef06e83db0b:27a2f71d87bf5eb105af096fb6605d97
https://unifi-live01.secureswiftcontent.com/UnifiHD/live03.mpd

#EXTINF:-1 group-title="MALAYSIA" ch-number="103" tvg-id="TV3.my" tvg-logo="http://linear-poster.astro.com.my/prod/logo/TV3_v1.png",TV3 ⁽ˢᵉʳᵛᵉʳ ²⁾
#EXTVLCOPT:http-referer=https://www.dailymotion.com
https://live.astradamy.com/tv3/index.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-name="Drama Sangat" group-title="MALAYSIA" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/c/c6/Drama_Sangat_%28TV_on-screen%29.png",Drama Sangat
https://stream.zeehanzgadget.com/dramasangat

#EXTINF:-1 tvg-id="RTMK06" tvg-name="TV6" group-title="MALAYSIA" tvg-logo="https://i.ibb.co/LPVMhTq/tv6.png",TV6
https://d25tgymtnqzu8s.cloudfront.net/smil:tv6/chunklist_b4596000_slENG.m3u8?id=6

#EXTINF:-1 tvg-id="NTV7.my" tvg-name="147 NTV7" group-title="MALAYSIA" tvg-logo="https://i.ibb.co/3CDW0mq/ntv7.png",DidikTV KPM
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/unifitv/didiktvkpm/
https://unifi-live05.secureswiftcontent.com/UnifiHD/live06.mpd
# http://23.237.10.66:16405

#EXTINF:-1 tvg-id="8TV.my" tvg-name="8TV" group-title="MALAYSIA" tvg-logo="http://linear-poster.astro.com.my/prod/logo/8TV_v1.png",8TV ⁽ˢᵉʳᵛᵉʳ ¹⁾
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/unifitv/8tv/
https://unifi-live05.secureswiftcontent.com/UnifiHD/live08.mpd
# http://51.79.82.208:16005

#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={ "keys":[ { "kty":"oct", "k":"Edoa02jQys/+SCS2s14itw", "kid":"DLeYDp0diVf5opPtljQkEA" } ], "type":"temporary" }
#EXTINF:-1 tvg-id="8TV.my" tvg-name="8TV" group-title="MALAYSIA" tvg-logo="http://linear-poster.astro.com.my/prod/logo/8TV_v1.png",8TV ⁽ˢᵉʳᵛᵉʳ ²⁾
https://linearjitp-playback.astro.com.my/dash-wv/linear/911/default.mpd

#EXTINF:-1 tvg-id="TV9.my" tvg-name="TV9" group-title="MALAYSIA" tvg-logo="http://linear-poster.astro.com.my/prod/logo/TV9_v1.png",TV9 ⁽ˢᵉʳᵛᵉʳ ¹⁾
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/unifitv/tv9/
https://unifi-live09.secureswiftcontent.com/UnifiHD/live09.mpd
# http://51.79.82.208:16006

#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={ "keys":[ { "kty":"oct", "k":"lY6ctzieIJSN5aVC0nKezw", "kid":"J4KHJ/CjoLT7xmg3jM+MEA" } ], "type":"temporary" }
#EXTINF:-1 tvg-id="TV9.my" tvg-name="TV9" group-title="MALAYSIA" tvg-logo="http://linear-poster.astro.com.my/prod/logo/TV9_v1.png",TV9 ⁽ˢᵉʳᵛᵉʳ ²⁾
https://linearjitp-playback.astro.com.my/dash-wv/linear/705/default.mpd

#EXTINF:-1 tvg-id="RTMTVOkey.my" tvg-name="Okey" group-title="MALAYSIA" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/b/b9/Okey_RTM.png",Okey ⁽ˢᵉʳᵛᵉʳ ¹⁾
https://d25tgymtnqzu8s.cloudfront.net/smil:okey/chunklist_b4596000_slENG.m3u8?id=3

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/dash-ck/linear/5072/
#EXTINF:-1 tvg-id="RTMK03" tvg-name="Okey" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/b/b9/Okey_RTM.png" group-title="MALAYSIA",Okey ⁽ˢᵉʳᵛᵉʳ ²⁾
https://linearjitp-playback.astro.com.my/dash-wv/linear/5072/default_primary.mpd

#EXTINF:-1 tvg-id="TVAlhijrah.my" tvg-name="Al-Hijrah" tvg-logo="https://upload.wikimedia.org/wikipedia/ms/d/da/Logo_TV_Alhijrah.png" group-title="MALAYSIA",TV Alhijrah ⁽ˢᵉʳᵛᵉʳ ¹⁾
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://linearjitp-playback-astro.astradamy.com/dash-ck/linear/1113
#https://linearjitp-playback.astro.com.my/dash-wv/linear/1113/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/dash-ck/linear/1113/
#EXTINF:-1 tvg-id="TVAlhijrah.my" tvg-logo="http://linear-poster.astro.com.my/prod/logo/Al-Hijrah_v1.png" group-title="MALAYSIA",TV Alhijrah 
http://linearjitp-playback.astro.com.my/dash-wv/linear/1113/default_primary.mpd
# https://unifi-live05.secureswiftcontent.com/UnifiHD/live07.mpd

#EXTINF:-1 tvg-id="CHN" tvg-name="RTB Sukmaindera" tvg-logo="https://upload.wikimedia.org/wikipedia/en/c/c0/RTB_Sukmaindera.png" group-title="MALAYSIA",RTB Sukmaindera
https://d1211whpimeups.cloudfront.net/smil:rtb1/playlist.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://rtb-images.glueapi.io/300x0/live/rtb-aneka-title.png" group-title="MALAYSIA", RTB Aneka
https://d1211whpimeups.cloudfront.net/smil:rtb2/chunklist_b1120000_sleng.m3u8

#EXTINF:-1 tvg-id="114" tvg-name="TV Ikim" tvg-country="MY" tvg-language="Malay (macrolanguage)" tvg-logo="https://i.imgur.com/Z0dyJK7.jpg" group-title="MALAYSIA",TV Ikim 
#https://dlau142f16b92.cloudfront.net/hls/ch5ctv/master02.m3u8
#http://edge.vediostream.com/abr/tvikim/playlist.m3u8
http://edge.vediostream.com:80/abr/tvikim/live/tvikim_source/chunks.m3u8

#EXTINF:-1 tvg-id="CHN" ch-number="" tvg-logo="https://1.bp.blogspot.com/-7VCmfo92Zls/YTWfhHNpbGI/AAAAAAAAiEM/WBDJq1lf2FABp1IqDlqnU7BnN-RlNevpQCLcBGAsYHQ/s16000/SUKE_TV_Logo.png" group-title="MALAYSIA",Suke TV
https://github.com/AqFad2811/randomlivefromyt2/raw/main/SukeTV.m3u8

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/dash-ck/linear/211/
#EXTINF:-1 tvg-id="AwesomeTV.my" tvg-name="Awesome TV" group-title="MALAYSIA" tvg-logo="https://iili.io/1NqAMl.png",Awesome TV 
https://linearjitp-playback.astro.com.my/dash-wv/linear/211/default.mpd

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://selangortv.my/wp-content/uploads/2020/10/cropped-SelangorTV2.png" radio="true" group-title="MALAYSIA",Selangor TV
https://skyios.sky4k.top/S1G_010/playlist.m3u8?auth=Astra&Time=0422022

#EXTINF:-1 tvg-id="TVS.my" group-title="MALAYSIA" tvg-logo="http://linear-poster.astro.com.my/prod/logo/TVSarawak.png",TVS Sarawak
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/dash-ck/linear/5021
https://linearjitp-playback.astro.com.my/dash-wv/linear/5021/default_ott.mpd
#https://agsplayback01.astro.com.my:443/CH1/master_AGS_TVS.m3u8

#EXTINF:-1 tvg-id="Pesona" tvg-name="Pesona" tvg-logo="https://i.ibb.co/N19NSHn/201907160659062937ij.png" group-title="MALAYSIA",Unifi Pesona
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/unifitv/pesona/
#https://aqfadtv.xyz/live/unifitv/pesona/index.mpd

#EXTINF:-1 tvg-id="Salam HD" tvg-name="Salam HD" tvg-logo="https://i.ibb.co/275HdzT/20190716062504007e6f.png" group-title="MALAYSIA",Unifi Salam
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/unifitv/salam/
#https://aqfadtv.xyz/live/unifitv/salam/index.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/unifitv/inspirasi/
#EXTINF:-1 tvg-id="Inspirasi" tvg-name="Inspirasi" group-title="MALAYSIA" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/7/70/Hypp_Inspirasi_HD.png/revision/latest?cb=20210712091503",Unifi Inspirasi
https://aqfadtv.xyz/live/unifitv/inspirasi/index.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/unifitv/sensasi/
#EXTINF:-1 tvg-id="Sensasi" tvg-name="Sensasi" group-title="MALAYSIA" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/4/43/Sensasi2022.png/revision/latest?cb=20220902052331",Unifi Sensasi
https://aqfadtv.xyz/live/unifitv/sensasi/index.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/unifitv/degup/
#EXTINF:-1 tvg-id="Degup" tvg-name="Degup" group-title="MALAYSIA" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/b/bf/Degup.png/revision/latest?cb=20220924000615",Unifi Degup
https://aqfadtv.xyz/live/unifitv/degup/index.mpd

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://ottweb.hypp.tv:8064/?deviceId=ZmFlMGUxOWMtMzEyMC0zODhhLTgxNjAtNGE0OTlhOGZjMTI0
#EXTINF:-1 tvg-id="SIAR" tvg-name="SIAR" group-title="MALAYSIA" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/1/1d/SIAR_%28TV_logo%29.png/revision/latest?cb=20220902115129",Unifi Siar
https://aqfadtv.xyz/live/unifitv/siar/index.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/unifitv/duniasinema/
#EXTINF:-1 tvg-id="Dunia Sinema" tvg-name="Dunia Sinema" group-title="MALAYSIA" tvg-logo="https://playtv.unifi.com.my:7041/CPS/images/universal/film/logo/201907/20190716/20190716074123890vav.png",Unifi Dunia Sinema
https://unifi-live05.secureswiftcontent.com/UnifiHD/live27-1080FHD.m3u8
https://aqfadtv.xyz/live/unifitv/duniasinema/index.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5085
#EXTINF:-1 group-title="MALAYSIA" tvg-id="AstroSensasi.my" tvg-name="Astro Sensasi HD" tvg-logo="https://tinyurl.com/mrkr9fde",Astro Sensasi
https://linearjitp-playback.astro.com.my/dash-wv/linear/5085/default_primary.mpd

#EXTINF:-1 group-title="MALAYSIA" tvg-id="AstroRia.my" tvg-name="Astro Ria HD" tvg-logo="http://linear-poster.astro.com.my/prod/logo/Astro_RIA_v1.png",Astro Ria 
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/dash-ck/linear/1004
#EXTVLCOPT:http-referrer=https://astrogo.astro.com.my
https://staging-linearjitp-playback.astro.com.my/dash-wv/linear/1004/default_primary.mpd

#EXTINF:-1 group-title="MALAYSIA" tvg-id="104" tvg-name="Astro Ria HD" tvg-logo="http://linear-poster.astro.com.my/prod/logo/Astro_RIA_v1.png",Astro Ria ⁽ˢᵉʳᵛᵉʳ ²⁾
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/dash-ck/linear/1004
#https://aqfadtv.xyz/live/ria/index.mpd

#EXTINF:-1 group-title="MALAYSIA" tvg-id="104" tvg-name="Astro Ria HD" tvg-logo="http://linear-poster.astro.com.my/prod/logo/Astro_RIA_v1.png",Astro Ria ⁽ˢᵉʳᵛᵉʳ ³⁾
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/dash-ck/linear/1004
#https://stream.zeehanzgadget.com/ria.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/dash-ck/linear/1000
#EXTVLCOPT:http-referrer=https://astrogo.astro.com.my
#EXTINF:-1 tvg-id="AstroPrima.my" tvg-name="Astro Prima HD" group-title="MALAYSIA" tvg-logo="http://linear-poster.astro.com.my/prod/logo/Astro_Prima_v1.png",Astro Prima 
https://linearjitp-playback.astro.com.my/dash-wv/linear/1000/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/dash-ck/linear/2505
#EXTVLCOPT:http-referrer=https://astrogo.astro.com.my
#EXTINF:-1 tvg-id="AstroOasis.my" tvg-name="Astro Oasis HD" tvg-logo="http://linear-poster.astro.com.my/prod/logo/Astro_Oasis_v1.png" group-title="MALAYSIA",Astro Oasis 
https://linearjitp-playback.astro.com.my/dash-wv/linear/2505/default_primary.mpd
# https://stream.zeehanzgadget.com/oasis.mpd
# https://tv.kpsvpn.com/kpsboyoasis.mpd

#EXTINF:-1 tvg-id="AstroWarna.my" tvg-name="Astro Warna HD" group-title="MALAYSIA" tvg-logo="http://linear-poster.astro.com.my/prod/logo/Astro_Warna_v1.png",Astro Warna ⁽ˢᵉʳᵛᵉʳ ¹⁾
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5086
https://linearjitp-playback.astro.com.my/dash-wv/linear/5086/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2402
#EXTINF:-1 tvg-id="AstroWarna.my" tvg-name="Astro Warna HD" group-title="MALAYSIA" tvg-logo="http://linear-poster.astro.com.my/prod/logo/Astro_Warna_v1.png",Astro Warna ⁽ˢᵉʳᵛᵉʳ ²⁾
http://kmkus.wanicelife.com:8880/live/12m0390043/17783455/1706.m3u8
http://51.81.208.129:35461/80203091402/213445/5075

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/dash-ck/linear/2402/
#EXTINF:-1 tvg-id="AstroWarna.my" tvg-name="Astro Warna HD" group-title="MALAYSIA" tvg-logo="http://linear-poster.astro.com.my/prod/logo/Astro_Warna_v1.png",Astro Warna ⁽ˢᵉʳᵛᵉʳ ³⁾
https://stream.zeehanzgadget.com/warna

#EXTINF:-1 tvg-id="AstroCitra.my" tvg-name="Astro Citra HD" group-title="MALAYSIA" tvg-logo="http://linear-poster.astro.com.my/prod/logo/Astro_Citra_v1.png",Astro Citra ⁽ˢᵉʳᵛᵉʳ ¹⁾
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={ "keys":[ { "kty":"oct", "k":"W64AF3MLZiu7aPemKeCyqg", "kid":"N+D6QCNB63FT/xB4kx/IEA" } ], "type":"temporary" }
https://linearjitp-playback.astro.com.my/dash-wv/linear/5092/default.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2700
#EXTVLCOPT:http-referrer=https://astrogo.astro.com.my
#EXTINF:-1 tvg-id="AstroCitra.my" tvg-name="Astro Citra HD" group-title="MALAYSIA" tvg-logo="http://linear-poster.astro.com.my/prod/logo/Astro_Citra_v1.png",Astro Citra ⁽ˢᵉʳᵛᵉʳ ²⁾
http://kmkus.wanicelife.com:8880/live/12m0390043/17783455/71146.m3u8
# https://is.gd/ygGwxs.mpd
# https://stream.zeehanzgadget.com/citra

#EXTINF:-1 tvg-id="AstroCitra.my" tvg-name="Astro Citra HD" group-title="MALAYSIA" tvg-logo="http://linear-poster.astro.com.my/prod/logo/Astro_Citra_v1.png",Astro Citra ⁽ˢᵉʳᵛᵉʳ ³⁾
https://stream.zeehanzgadget.com/citra 

#EXTINF:-1 tvg-id="RTMK08" tvg-logo="https://rtm-images.glueapi.io/320x0/live_channel/PDN_bckg.png" group-title="MALAYSIA",Parlimen Dewan Negara
# https://d25tgymtnqzu8s.cloudfront.net/smil:negara/chunklist_b4596000_slENG.m3u8

#EXTINF:-1 tvg-id="RTMK07" tvg-logo="https://rtm-images.glueapi.io/320x0/live_channel/PDR_bckg.png" group-title="MALAYSIA",Parlimen Dewan Rakyat
# https://d25tgymtnqzu8s.cloudfront.net/smil:rakyat/chunklist_b4596000_slENG.m3u8

#EXTINF:-1 tvg-id="GoShopMalay111.my" group-title="MALAYSIA" tvg-logo="https://aqfadtv.astradamy.com/logos/GoShopBAARU.png",Go Shop BAARU
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/dash-ck/linear/2508
https://linearjitp-playback.astro.com.my/dash-wv/linear/2508/default_ott.mpd

#EXTINF:-1 tvg-id="GoShopMalay118.my" group-title="MALAYSIA" tvg-logo="https://user-images.githubusercontent.com/85995579/128457984-94be67a9-e944-4fcd-a083-7c01d5a922b7.png",Go Shop RUUMA
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/dash-ck/linear/2501
https://linearjitp-playback.astro.com.my/dash-wv/linear/2501/default_ott.mpd

#EXTINF:-1 tvg-id="GoShopMalay120.my" group-title="MALAYSIA" tvg-logo="https://user-images.githubusercontent.com/85995579/128458098-5b4bb7bc-5cab-423f-b4d7-ae4376f43590.png",Go Shop GAAYA
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/dash-ck/linear/507
https://linearjitp-playback.astro.com.my/dash-wv/linear/507/default_ott.mpd








#######################################################################################################################################################################

##############################







#EXTINF:-1 tvg-id="CHN" tvg-name="" group-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="INDONESIA",SILA KLIK DAN BACA!!
https://tinyurl.com/sila-baca-la-oii

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="INDONESIA",VISIT MY SHOP 
https://tinyurl.com/visit-kedai-saya


#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/dash-ck/linear/609/
#EXTINF:-1 tvg-id="AstroAura.my" ch-number="AstroAura" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/400_144.png" group-title="INDONESIA",Astro Aura  
http://kmkus.wanicelife.com:8880/live/12m0390043/17783455/71145.m3u8
# https://linearjitp-playback.astro.com.my/dash-wv/linear/609/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/dash-ck/linear/608/
#EXTINF:-1 tvg-id="AstroRania.my" tvg-name="ASTRO RANIA HD" group-title="INDONESIA" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/401_144.png",Astro Rania 
http://kmkus.wanicelife.com:8880/live/12m0390043/17783455/71144.m3u8
# https://linearjitp-playback.astro.com.my/dash-wv/linear/608/default_primary.mpd

#EXTINF:-1 tvg-id="BioskopIndonesia.id" tvg-logo="https://i.ibb.co/gTN6Xc2/bioskopindonesia-modified.png" group-title="INDONESIA", Bioskop Indonesia
#EXTVLCOPT:http-user-agent=dhdsznnshsff
https://dukun.masuk.id/57337005c17a518a3cee71d5170f05210698fd0b11a8f77733c08de39ab09ac67652ce68-78a50d92c806e206e634451643a7d8bf-1660653338-1660642539/hiburan/bioskop

#EXTINF:-1 tvg-id="SinemaIndonesia.id" tvg-logo="https://i.ibb.co/F4q8K6H/sinema-indonesia-modified-1.png" group-title="INDONESIA",Sinema Indonesia
#http://203.77.246.50:5000/udp/239.1.1.74:5000

#EXTINF:-1 tvg-id="SinemaIndonesiaX.id" tvg-logo="https://i.ibb.co/nnzV8Ld/unnamed-26-modified.png" group-title="INDONESIA",Sinema Indonesia X
#EXTVLCOPT:http-user-agent=exoplayer2example/2.030 (Linux;Android 7.1.2) ExoPlayerLib/2.9.5
# http://bravo.kugo.id:8081/sindox/hls/playlist.m3u8

#EXTINF:-1 tvg-id="DuniaLain.id" tvg-logo="https://i.ibb.co/CntmHWZ/channels4-profile-5-modified.png" group-title="INDONESIA", Dunia Lain
#EXTVLCOPT:http-user-agent=zznszhhsfnsdx 
https://dukun.masuk.id/57337005c17a518a3cee71d5170f05210698fd0b11a8f77733c08de39ab09ac67652ce68-78a50d92c806e206e634451643a7d8bf-1660653338-1660642539/hiburan/dunialain

#EXTINF:-1 tvg-id="" tvg-logo="https://i.ibb.co/4gS99DK/unnamed-23-modified.png" group-title="INDONESIA",Mata Milenial Indonesia TV
#https://dukun.masuk.id/57337005c17a518a3cee71d5170f05210698fd0b11a8f77733c08de39ab09ac67652ce68-78a50d92c806e206e634451643a7d8bf-1660653338-1660642538/lokal/mmi.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/xqSG154/Indonesiana-TV-1-modified.png" group-title="INDONESIA",Indonesiana TV
#EXTVLCOPT:http-user-agent=dhdsznnshsff
https://dukun.masuk.id/57337005c17a518a3cee71d5170f05210698fd0b11a8f77733c08de39ab09ac67652ce68-78a50d92c806e206e634451643a7d8bf-1660653338-1660642539/lokal/indonesiana.m3u8

#EXTINF:-1 tvg-id="MojiTV.id" tvg-logo="https://thumbor.prod.vidiocdn.com/tmmSRk4XtrU7uWrqXmu0m_22RSM=/112x112/filters:quality(70)/vidio-web-prod-livestreaming/uploads/livestreaming/square_image/206/a11dc1.png" group-title="INDONESIA", Moji TV
https://geocities.ws/ariev7xx/moji.m3u8
http://210.210.155.37/qwr9ew/s/s41/index.m3u8 

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTINF:-1 tvg-id="IMC.id" tvg-logo="https://i.ibb.co/Kh8mQ2r/channel-14-modified.png" group-title="INDONESIA",Imc
https://av-live-cdn.mncnow.id/live/eds/IndonesiaMovieChannels-HD/sa_dash_vmx/IndonesiaMovieChannels-HD.mpd

#EXTINF:-1 tvg-id="CitraBioskop.id" tvg-logo="https://thumbor.prod.vidiocdn.com/1ASddItneuCcle-ekFegZrPA-mo=/112x112/filters:quality(70)/vidio-web-prod-livestreaming/uploads/livestreaming/square_image/6684/61417f.png" group-title="INDONESIA",Citra Bioskop
https://dl.dropbox.com/s/5ws9vhnr7pf7n2j/CitraDrama.m3u8?dl=1

#EXTINF:-1 tvg-id="CitraDrama.id" tvg-logo="https://thumbor.prod.vidiocdn.com/vrmDRqwZOsoYOuyV_hfOtFs8bJo=/112x112/filters:quality(70)/vidio-web-prod-livestreaming/uploads/livestreaming/square_image/6401/5b4d40.png" group-title="INDONESIA",Citra Drama
#EXTVLCOPT:http-user-agent=dhdsznnshsff
https://dukun.masuk.id/57337005c17a518a3cee71d5170f05210698fd0b11a8f77733c08de39ab09ac67652ce68-78a50d92c806e206e634451643a7d8bf-1660653338-1660642539/hiburan/cdrama.m3u8

#EXTINF:-1 tvg-id="CitraDangdut.id" tvg-logo="https://thumbor.prod.vidiocdn.com/dfxtzulRmK4-cAUvo30s9VoSwbc=/112x112/filters:quality(70)/vidio-web-prod-livestreaming/uploads/livestreaming/square_image/6587/8742fe.png" group-title="INDONESIA",Citra Dangdut
#EXTVLCOPT:http-user-agent=dhdsznnshsff
https://dukun.masuk.id/57337005c17a518a3cee71d5170f05210698fd0b11a8f77733c08de39ab09ac67652ce68-78a50d92c806e206e634451643a7d8bf-1660653338-1660642539/hiburan/cdangdut.m3u8

#EXTINF:-1 tvg-id="CitraCulinaryTravel.id" tvg-logo="https://i.ibb.co/K0pRgQ1/15f712-modified.png" group-title="INDONESIA",Citra Culinary & Travel
#https://dukun.masuk.id/57337005c17a518a3cee71d5170f05210698fd0b11a8f77733c08de39ab09ac67652ce68-78a50d92c806e206e634451643a7d8bf-1660653338-1660642538/hiburan/ctravel.m3u8

#EXTINF:-1 tvg-id="CitraMuslim.id" tvg-logo="https://thumbor.prod.vidiocdn.com/s6WSgBPwJHnY4vughTA-IkeRG40=/112x112/filters:quality(70)/vidio-web-prod-livestreaming/uploads/livestreaming/square_image/6678/154a43.png" group-title="INDONESIA",Citra Muslim
#https://dukun.masuk.id/57337005c17a518a3cee71d5170f05210698fd0b11a8f77733c08de39ab09ac67652ce68-78a50d92c806e206e634451643a7d8bf-1660653338-1660642538/hiburan/cmuslim.m3u8

#EXTINF:-1 tvg-id="CitraEntertainment.id" tvg-logo="https://i.ibb.co/nncMTg1/Desain-tanpa-judul-14-modified.png" group-title="INDONESIA",Citra Entertainment
#EXTVLCOPT:http-user-agent=dhdsznnshsff
https://dukun.masuk.id/57337005c17a518a3cee71d5170f05210698fd0b11a8f77733c08de39ab09ac67652ce68-78a50d92c806e206e634451643a7d8bf-1660653338-1660642539/hiburan/centertainment.m3u8

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTINF:-1 group-title="INDONESIA" tvg-logo="https://www.mncvision.id/userfiles/image/channel/iBcm_IDX.jpg",IDX Channel
https://av-live-cdn.mncnow.id/live/eds/IDX/sa_dash_vmx/IDX.mpd

#EXTVLCOPT:http-user-agent=Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTINF:-1 tvg-id="KompasTV.id" tvg-logo="https://thumbor.prod.vid.id/PPmP4ZZL9zYXq23d2ltlo8LYChQ=/112x112/filters:quality(70)/vidio-web-prod-livestreaming/uploads/livestreaming/square_image/874/042ca3.png" group-title="INDONESIA", KompasTV
https://av-live-cdn.mncnow.id/live/eds/KompasTV/sa_dash_vmx/KompasTV.mpd

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MDA5MmI1NjctOWMyMS0zNDYyLTk0NDAtODM5NGQ1ZjdlZWRi
#EXTINF:-1 tvg-ID="MetroTV.id" group-title="INDONESIA"tvg-logo="https://thumbor.prod.vid.id/ydRJrj3WJ-ycS2KJw19CZn6XQkg=/112x112/filters:strip_icc():quality(70)/vidio-web-prod-livestreaming/uploads/livestreaming/square_image/777/ea8483.png",MetroTV
https://av-live-cdn.mncnow.id/live/eds/Metro-TV2/sa_dash_vmx/Metro-TV2.mpd

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTINF:0 tvg-id="MagnaTV.id" tvg-name="Magna Tv" tvg-url="" tvg-logo="https://cdn.macan.tv/img/magnachannel.png" group-title="INDONESIA",Magna Tv
#https://edge.medcom.id/live-edge/smil:magna.smil/playlist.m3u8
https://cdn-telkomsel-01.akamaized.net/Content/DASH/Live/channel(85534711-b312-4ed5-8832-6fe000e8fb86)/manifest.mpd

#EXTVLCOPT:http-user-agent=Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTINF:-1 tvg-id="RTV.MACAN" tvg-logo="https://thumbor.prod.vid.id/NEU5NOM51mtJVYE4bI4iP2bLSCs=/112x112/filters:quality(70)/vidio-web-prod-livestreaming/uploads/livestreaming/square_image/1561/665aea.png" group-title="INDONESIA", Rtv
https://av-live-cdn.mncnow.id/live/eds/RTV/sa_dash_vmx/RTV.mpd

#EXTINF:-1 tvg-id="adventure.id" group-title="INDONESIA" tvg-logo="https://i.postimg.cc/fT434nvF/Logo-Biznet-Adventure.png",Adventure
http://livestream.biznetvideo.net/biznet_adventure/smil:adventure.smil/playlist.m3u8

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MDA5MmI1NjctOWMyMS0zNDYyLTk0NDAtODM5NGQ1ZjdlZWRi
#EXTINF:-1 tvg-ID="ANTV.id" group-title="INDONESIA"tvg-logo="https://thumbor.prod.vid.id/FpGpG_N1noubGtSI38Ek1bo0pf8=/112x112/filters:strip_icc():quality(70)/vidio-web-prod-livestreaming/uploads/livestreaming/square_image/782/e1af8b.png",Antv
https://av-live-cdn.mncnow.id/live/eds/ANTV/sa_dash_vmx/ANTV.mpd

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTINF:-1 tvg-id="LifestyleFashion.id" tvg-logo="https://i.ibb.co/tYYjqBn/download-20-modified-1.png" group-title="INDONESIA",Lifestyle & Fashion
https://av-live-cdn.mncnow.id/live/eds/LifeStyleFashion/sa_dash_vmx/LifeStyleFashion.mpd

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=ZWQ0NjNlZDctNzI1Yy0zY2JlLTg3N2UtOGQ0MTU5MTc0Y2Nh
#EXTINF:-1 tvg-id="MNCTV.id" tvg-logo="https://i.ibb.co/YW131Xz/images-modified.png" group-title="INDONESIA",Mnc TV
https://av-live-cdn.mncnow.id/live/eds/MNCTV-HD/sa_dash_vmx/MNCTV-HD.mpd

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=YWY0OTBlZjEtODAyNC0zZTA0LWFhYzMtY2ZmMGE4NjVjZjU1
#EXTINF:-1 tvg-id="eNt.id" tvg-logo="https://i.ibb.co/n1YJFTK/channel-86-modified.png" group-title="INDONESIA",eNt
https://av-live-cdn.mncnow.id/live/eds/MNCEntertainment/sa_dash_vmx/MNCEntertainment.mpd

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTINF:-1 tvg-id="Besmart.id" group-title="INDONESIA" tvg-logo="https://www.mncvision.id/userfiles/image/channel/channel_112.png",Besmart
https://av-live-cdn.mncnow.id/live/eds/BeSmart/sa_dash_vmx/BeSmart.mpd

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=YWY0OTBlZjEtODAyNC0zZTA0LWFhYzMtY2ZmMGE4NjVjZjU1
#EXTINF:-1 tvg-id="ie.ID" tvg-logo="https://i.ibb.co/CMnfgsL/channel-96-modified.png" group-title="INDONESIA",iE
https://av-live-cdn.mncnow.id/live/eds/MNCInfotainment/sa_dash_vmx/MNCInfotainment.mpd

#EXTINF:-1 tvg-id="OKTV.id" group-title="INDONESIA" tvg-logo="https://i.ibb.co/MG4ggLX/download-20-modified.png", Ok TV
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=YWY0OTBlZjEtODAyNC0zZTA0LWFhYzMtY2ZmMGE4NjVjZjU1
https://av-live-cdn.mncnow.id/live/eds/OKTV/sa_dash_vmx/OKTV.mpd

#EXTINF:0 tvg-id="RajawaliTV.id" tvg-name="Rajawali TV" tvg-url="http://www.useetv.com" tvg-logo="https://thumbor.prod.vid.id/NEU5NOM51mtJVYE4bI4iP2bLSCs=/112x112/filters:quality(70)/vidio-web-prod-livestreaming/uploads/livestreaming/square_image/1561/665aea.png" group-title="INDONESIA",Rajawali TV
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
https://av-live-cdn.mncnow.id/live/eds/RTV/sa_dash_vmx/RTV.mpd

#EXTVLCOPT:http-user-agent=Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTINF:-1 tvg-id="TVRI.MACAN" tvg-logo="https://thumbor.prod.vid.id/CHQ7jG2pWgk7OSBt-Sw8ZK1MB9U=/112x112/filters:quality(70)/vidio-web-prod-livestreaming/uploads/livestreaming/square_image/6441/528cc9.png" group-title="INDONESIA", Tvri
https://av-live-cdn.mncnow.id/live/eds/PemersatuBangsa/sa_dash_vmx/PemersatuBangsa.mpd

#EXTINF:-1 tvg-id="MetroTV.id" tvg-logo="https://thumbor.prod.vid.id/ydRJrj3WJ-ycS2KJw19CZn6XQkg=/112x112/filters:strip_icc():quality(70)/vidio-web-prod-livestreaming/uploads/livestreaming/square_image/777/ea8483.png" group-title="INDONESIA",Metro TV
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
https://av-live-cdn.mncnow.id/live/eds/Metro-TV2/sa_dash_vmx/Metro-TV2.mpd

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTINF:0 tvg-id="GTV.MACAN" tvg-name="" tvg-logo="https://i.ibb.co/B2fCbY1/channel-81-modified.png" group-title="INDONESIA",Gtv
https://av-live-cdn.mncnow.id/live/eds/GTV-HD/sa_dash_vmx/GTV-HD.mpd

#EXTINF:-1 group-title="INDONESIA" tvg-logo="https://i.ibb.co/kM895zc/download-21-modified.png", Vision Prime
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=ZGFkZmZkZjItYzQ1Mi0zM2RiLTk0OWQtM2M2YmY1YzZjMDNi
https://av-live-cdn.mncnow.id/live/eds/VisionPrime/sa_dash_vmx/VisionPrime.mpd

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=ZWQ0NjNlZDctNzI1Yy0zY2JlLTg3N2UtOGQ0MTU5MTc0Y2Nh
#EXTINF:-1 tvg-id="RCTI.id" tvg-logo="https://i.ibb.co/NSLcYJH/channel-80-modified.png" group-title="INDONESIA",Rcti
https://av-live-cdn.mncnow.id/live/eds/RCTI-DD/sa_dash_vmx/RCTI-DD.mpd

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MDA5MmI1NjctOWMyMS0zNDYyLTk0NDAtODM5NGQ1ZjdlZWRi
#EXTINF:-1 tvg-ID="TransTV.id" group-title="INDONESIA"tvg-logo="https://thumbor.prod.vid.id/I5QlX5A46bifAC7ib269aQhzP3Q=/112x112/filters:strip_icc():quality(70)/vidio-web-prod-livestreaming/uploads/livestreaming/square_image/733/ecaa60.png",Trans TV
#https://liveanevia.mncnow.id/live/eds/TransTV-2/sa_dash_vmx/TransTV-2.mpd
https://video.detik.com/transtv/smil:transtv.smil/chunklist_kamiselaluada_b744100_sleng.m3u8

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MDA5MmI1NjctOWMyMS0zNDYyLTk0NDAtODM5NGQ1ZjdlZWRi
#EXTINF:-1 tvg-ID="Trans7.id" group-title="INDONESIA"tvg-logo="https://thumbor.prod.vid.id/ksy91mCjoKvOD2anneLgskaBLRA=/112x112/filters:strip_icc():quality(70)/vidio-web-prod-livestreaming/uploads/livestreaming/square_image/734/131514.png",Trans 7
#https://liveanevia.mncnow.id/live/eds/Trans7-2/sa_dash_vmx/Trans7-2.mpd
https://video.detik.com/trans7/smil:trans7.smil/chunklist_kamiselaluada_b744100_sleng.m3u8

#EXTINF:-1 tvg-id="Indosiar.id" tvg-name="INDOSIAR FHD" tvg-logo="https://thumbor.prod.vid.id/1gl_OViRhInfE1_Scn6ve40g7FY=/112x112/filters:strip_icc():quality(70)/vidio-web-prod-livestreaming/uploads/livestreaming/square_image/205/54ab19.png" group-title="INDONESIA", Indosiar  
http://mpwtv.my.id/vidioye/205-indosiar.m3u8 
https://k.ksa.my.id/ksa.m3u8?a=11c29c48146372ad4d14&b=204991a99793a98926d2&c=8f5ffddd6e9165aa1117

#EXTINF:-1 tvg-id="Indosiar.id" tvg-name="INDOSIAR FHD" tvg-logo="https://thumbor.prod.vid.id/1gl_OViRhInfE1_Scn6ve40g7FY=/112x112/filters:strip_icc():quality(70)/vidio-web-prod-livestreaming/uploads/livestreaming/square_image/205/54ab19.png" group-title="INDONESIA", Indosiar  
http://210.210.155.35/session/8fe637d4-fb26-11eb-9071-b82a72d63267/qwr9ew/s/s04/01.m3u8
# http://210.210.155.35/session/3b5cc59e-6fcc-11e9-90a7-b82a72d63267/qwr9ew/s/s04/02.m3u8

#EXTINF:-1 tvg-id="NET.id" tvg-logo="https://thumbor.prod.vid.id/GR_UBfQpa8xxCbFYptSZ3egm-kU=/112x112/filters:strip_icc():quality(70)/vidio-web-prod-livestreaming/uploads/livestreaming/square_image/875/cfcc85.png" group-title="INDONESIA",Net TV
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=YWY0OTBlZjEtODAyNC0zZTA0LWFhYzMtY2ZmMGE4NjVjZjU1
https://av-live-cdn.mncnow.id/live/eds/NetTV-HD/sa_dash_vmx/NetTV-HD.mpd

#EXTINF:-1 tvg-id="SCTV.id" tvg-name="ID: SCTV" tvg-logo="https://thumbor.prod.vid.id/cV7suiKWlj2Bj0Igw03BOf5VCvw=/112x112/filters:strip_icc():quality(70)/vidio-web-prod-livestreaming/uploads/livestreaming/square_image/204/4e9f5c.png" group-title="INDONESIA",Sctv
http://hi.hi-back.masuk.web.id/c.m3u8?shinta=2022&coday=f846bc691110108f73cb55c2f4049864&cdy=274ad4786c3abca69fa097b85867d9a4446503011668def857b1c03bafabba51

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTINF:0 tvg-id="ZeeBioskop.id" tvg-name="ZEE Biokop" tvg-url="http://www.mncvision.id.E" tvg-logo="https://thumbor.prod.vidiocdn.com/qFHtu3jH8fCY4AJeQJqavmV-3mg=/112x112/filters:quality(70)/vidio-web-prod-livestreaming/uploads/livestreaming/square_image/6399/84f7c4.png" group-title="INDONESIA",Zee Bioskop 
https://av-live-cdn.mncnow.id/live/eds/ZeeBIOSKOP/sa_dash_vmx/ZeeBIOSKOP.mpd

#EXTVLCOPT:http-user-agent=Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTINF:-1 tvg-id="iNewsTV.MACAN" tvg-logo="https://i.ibb.co/Z8zTYMd/62550521-2221755784545427-6717567406312521728-n-modified.png" group-title="INDONESIA", Inews
https://av-live-cdn.mncnow.id/live/eds/iNewsTV-HDD/sa_dash_vmx/iNewsTV-HDD.mpd





#######################################################################################################################################################################

#######################




#EXTINF:-1 tvg-id="CHN" tvg-name="" group-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="MIX INDIAN",SILA KLIK DAN BACA!!
https://tinyurl.com/sila-baca-la-oii

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="MIX INDIAN",VISIT MY SHOP 
https://tinyurl.com/visit-kedai-saya

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="MIX INDIAN",JOIN GROUP TELEGRAM 
https://tinyurl.com/Joingrouptele


#EXTINF:-1 tvg-id="AstroVaanavil.my" ch-number="201" group-title="MIX INDIAN" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/5/5b/1590966809313.png/revision/latest?cb=20200531231529",Astro Vaanavil ⁽ˢᵉʳᵛᵉʳ ¹⁾
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2309
https://linearjitp-playback.astro.com.my/dash-wv/linear/2309/default_primary.mpd

#EXTINF:-1 tvg-id="AstroVaanavil.my" tvg-name="Astro Vaanavil HD" group-title="MIX INDIAN" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/5_144.png",Astro Vaanavil ⁽ˢᵉʳᵛᵉʳ ²⁾
https://agsplayback01.astro.com.my/CH3/master_VAANGOSHOP5.m3u8

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2105
#EXTINF:-1 tvg-id="AstroVinmeenHD.my" tvg-name="Astro Vinmeen HD" group-title="MIX INDIAN" tvg-logo="https://iili.io/1NuZbI.png",Astro Vinmeen 
http://kmkus.wanicelife.com:8880/live/12m0390043/17783455/71033.m3u8
# https://linearjitp-playback.astro.com.my/dash-wv/linear/2105/default_primary.mpd
# https://stream.zeehanzgadget.com/vinmeen

#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5073
#EXTINF:-1 tvg-id="AstroVellithirai" tvg-name="Astro Vellithirai" group-title="MIX INDIAN" group-logo="https://telegra.ph/file/ed0787b99b8153874c7e1.png" tvg-logo="https://iili.io/1Nq6lI.png",Astro Vellithirai 
https://linearjitp-playback.astro.com.my/dash-wv/linear/5073/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2109
#EXTINF:-1 tvg-id="AstroBoxOfficeThangathirai.my" ch-number="BoxOfficeThangathirai" tvg-logo="https://upload.wikimedia.org/wikipedia/en/7/76/Astro_Box_Office_Movies.png" group-title="MIX INDIAN",Box Office Thangathirai
http://kmkus.wanicelife.com:8880/live/12m0390043/17783455/71133.m3u8
# http://linearjitp-playback.astro.com.my/dash-wv/linear/2109/default_primary.mpd
# https://aqfadtv.xyz/live/thangathirai/index.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/1007
#EXTINF:-1 tvg-id="AstroBollyOneHD.my" tvg-logo="http://linear-poster.astro.com.my/prod/logo/Astro_Bollyone_HD_v1.png" group-title="MIX INDIAN",Box Office Bollyone
http://kmkus.wanicelife.com:8880/live/12m0390043/17783455/71037.m3u8
# http://linearjitp-playback.astro.com.my/dash-wv/linear/1007/default_primary.mpd
# https://aqfadtv.xyz/live/bollyone/index.mpd

#KODIPROP:inputstream.adaptive.manifest_type=mpd
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key=https://dukun.masuk.id/drm/result.php?keyid=ce17264b317db108f19cdc11aa1a9e66&key=a21188aee8fc5c56d016fcffcc6b2295
#EXTINF:-1 tvg-ID="Colors.in" tvg-logo="https://raw.githubusercontent.com/angahjee1994/logo/master/colors.png" group-title="MIX INDIAN",Colors
https://cdn-01.toffeelive.com/origin-03/live-origin/smil:colors.smil/manifest.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2611
#EXTINF:-1 tvg-id="ColorsAsiaPacific.in" ch-number="ColorsHD" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/365_144.png" group-title="MIX INDIAN",Colors Hindi
https://linearjitp-playback.astro.com.my/dash-wv/linear/2611/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2101
#EXTINF:-1 tvg-id="ColorsTamil.in" tvg-logo="http://linear-poster.astro.com.my/prod/logo/Colors-Tamil_v1.png" group-title="MIX INDIAN",Colors Tamil
https://linearjitp-playback.astro.com.my/dash-wv/linear/2101/default_primary.mpd

#EXTINF:-1 tvg-id="ColorsCineplex.in" group-title="MIX INDIAN" tvg-logo="http://playtv.unifi.com.my:7039/CPS/images/universal/film/logo/201907/20190716/2019071607255101998u.png",Colors Cineplex
http://kmkus.wanicelife.com:8880/live/12m0390043/17783455/66780.m3u8

#EXTINF:-1 tvg-id="Andpictures.in" tvg-logo="https://i.ibb.co/hZ37R7j/Desain-tanpa-judul-2022-07-19-T144552-875-modified.png" group-title="MIX INDIAN",&Picture
http://kmkus.wanicelife.com:8880/live/12m0390043/17783455/1957.m3u8
# http://line.premiumpowers.net:80/Bianca/1234567/155997
# http://watchindia.net:8880/live/14100/70701/818.ts

#EXTINF:-1 tvg-id="Andxplor.in" tvg-logo="https://i.ibb.co/HYQ4CkZ/Desain-tanpa-judul-2022-07-19-T144628-095-modified.png" group-title="MIX INDIAN",&xplor
#EXTVLCOPT:http-user-agent=dhdsznnshsff
https://dukun.masuk.id/57337005c17a518a3cee71d5170f05210698fd0b11a8f77733c08de39ab09ac67652ce68-78a50d92c806e206e634451643a7d8bf-1660653338-1660642539/hiburan/xplor

#EXTINF:-1 tvg-id="SunTVMalaysia.my" group-title="MIX INDIAN" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/358_144.png",Sun TV  
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2310
http://linearjitp-playback.astro.com.my/dash-wv/linear/2310/default_primary.mpd

#EXTINF:-1 tvg-id="SunMusic.in" group-title="MIX INDIAN" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/417_144.png",Sun Music 
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5011
http://linearjitp-playback.astro.com.my/dash-wv/linear/5011/default_primary.mpd

#EXTINF:-1 tvg-id="SunNews.my" group-title="MIX INDIAN" tvg-logo="https://i.ibb.co/XZ7BFHV/sun-news-logo-107-E32491-A-seeklogo-com.png", Sun News
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5087
https://linearjitp-playback.astro.com.my/dash-wv/linear/5087/default_primary.mpd

#EXTINF:-1 tvg-id="SunLife.in" group-title="MIX INDIAN" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/417_144.png", Sun Life
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5089
https://linearjitp-playback.astro.com.my/dash-wv/linear/5089/default_primary.mpd

#EXTINF:-1 tvg-id="Ktv.in" group-title="MIX INDIAN" tvg-logo="https://i.ibb.co/41Br4yj/KTV-28-UHF.png", Ktv
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5088
https://linearjitp-playback.astro.com.my/dash-wv/linear/5088/default_primary.mpd

#EXTINF:-1 tvg-id="ChuttiTVMalaysia.my" ch-number="213" group-title="MIX INDIAN" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/51_144.png",Chutti TV 
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/1110
http://line.premiumpowers.net:80/Bianca/1234567/945786
# https://linearjitp-playback.astro.com.my/dash-wv/linear/1110/default_primary.mpd

#EXTINF:-1 tvg-id="AdithyaTV.in" ch-number="214" group-title="MIX INDIAN" tvg-logo="https://user-images.githubusercontent.com/85995579/130947065-c352cfdd-f4eb-47e3-aec3-806e76cec321.png",Adithya 
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/915
https://linearjitp-playback.astro.com.my/dash-wv/linear/915/default_primary.mpd

#EXTINF:-1 tvg-id="ZeeTamil.in" ch-number="223" group-title="MIX INDIAN" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/297_144.png",Zee Tamil 
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2311
https://linearjitp-playback.astro.com.my/dash-wv/linear/2311/default_primary.mpd

#KODIPROP:inputstream.adaptive.manifest_type=mpd 
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key=https://dukun.masuk.id/drm/result.php?keyid=ce17264b317db108f19cdc11aa1a9e66&key=a21188aee8fc5c56d016fcffcc6b2295
#EXTINF:-1 tvg-id="ZeeTV.in" tvg-name="Zee TV India" tvg-logo="https://raw.githubusercontent.com/angahjee1994/logo/master/zeetv.png" group-title="MIX INDIAN",Zee TV
http://kmkus.wanicelife.com:8880/live/12m0390043/17783455/1938.m3u8
# https://cdn-01.toffeelive.com/origin-01/live-origin/smil:zee_tv_hd.smil/manifest.mpd

#EXTINF:-1 tvg-id="ZeeCinemaAsia.in" tvg-name="Zee Cinema Asia" tvg-logo="https://i.ibb.co/vBxX1Xn/Zeecinemahd2011.png" group-title="MIX INDIAN", Zee Cinema 
#KODIPROP:inputstream.adaptive.manifest_type=mpd 
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key=https://dukun.masuk.id/drm/result.php?keyid=ce17264b317db108f19cdc11aa1a9e66&key=a21188aee8fc5c56d016fcffcc6b2295
# https://cdn-01.toffeelive.com/origin-09/live-origin/smil:zee_cinema_hd.smil/manifest.mpd

#EXTINF:-1 tvg-id="ZeeCinema.in" tvg-logo="https://raw.githubusercontent.com/angahjee1994/logo/master/zeecinema.png" group-title="MIX INDIAN",Zee Cinema
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=ZGFkZmZkZjItYzQ1Mi0zM2RiLTk0OWQtM2M2YmY1YzZjMDNi
#https://av-live-cdn.mncnow.id/live/eds/ZeeCinema/sa_dash_vmx/ZeeCinema.mpd

#EXTINF:-1 tvg-id="ZeeCinemaAsia.in" tvg-logo="https://i.ibb.co/vBxX1Xn/Zeecinemahd2011.png" group-title="MIX INDIAN" tvg-id="Zee5" ,Zee Cinema
http://144.217.70.181:9587/hin2/ZEECINEMAHD/tracks-v1a1/mono.m3u8?token=test 
http://kmkus.wanicelife.com:8880/live/12m0390043/17783455/1880.m3u8

#EXTINF:-1 tvg-id="ZeeAction.in" tvg-name="Zee Action" tvg-ID="zeeaction" tvg-logo="https://akamaividz2.zee5.com/image/upload/w_522,h_294,c_scale,f_webp,q_auto:eco/resources/0-9-zeeaction/channel_list/1170x658withlog1953200347.png" group-title="MIX INDIAN", Zee Action 
http://kmkus.wanicelife.com:8880/live/12m0390043/17783455/1885.m3u8

#EXTINF:-1 tvg-id="ZeeBollywood.in" tvg-name="Zee Bollywood" tvg-ID="zeebollywood" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/5/5b/Zee_bollywood_21AUg2018.jpg/revision/latest?cb=20191214174432" group-title="MIX INDIAN", Zee Bollywood
http://kmkus.wanicelife.com:8880/live/12m0390043/17783455/1883.m3u8

#EXTINF:-1 tvg-id="ZeeClassic.in" tvg-name="Zee Classic" tvg-ID="zeeclassic" tvg-logo="https://www.smartads.in/resources/assets/uploads/product_group/Television/Zee_Classic_India.png" group-title="MIX INDIAN", Zee Classic
http://kmkus.wanicelife.com:8880/live/12m0390043/17783455/1881.m3u8

#EXTINF:-1 tvg-id="ZeeAnmolCinema.in" tvg-name="Zee Anmol Cinema" tvg-ID="zeeanmolcinema" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/a/ae/Zee_Anmol_Cinema.png/revision/latest?cb=20210826143243" group-title="MIX INDIAN", Zee Anmol Cinema
http://kmkus.wanicelife.com:8880/live/12m0390043/17783455/1884.m3u8

#EXTINF:-1 tvg-id="ZeeThirai.in" tvg-name="Zee Biskope" tvg-ID="ZeeBiskope" tvg-logo="https://zeelwebsite.s3.amazonaws.com/zeetele/wp-content/uploads/2020/01/Zee-Biskope-Logo-new-Devnagri.png" group-title="MIX INDIAN", Zee Thirai
http://kmkus.wanicelife.com:8880/live/12m0390043/17783455/66733.m3u8

#EXTINF:-1 tvg-id="ZeeKannada.in" tvg-name="Zee Chitramandir" tvg-ID="ZeeKannada" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/8/84/Zee_Chitramandir.jpg/revision/latest/scale-to-width-down/360?cb=20210410110629" group-title="MIX INDIAN", Zee Kannada
http://kmkus.wanicelife.com:8880/live/12m0390043/17783455/1925.m3u8

#EXTINF:-1 tvg-id="ZeeTalkies.in" tvg-name="Zee Talkies" tvg-ID="ZeeTalkies" tvg-logo="https://zeelwebsite.s3.amazonaws.com/zeetele/wp-content/uploads/2017/10/Zee-Talkies.png" group-title="MIX INDIAN", Zee Talkies
https://tinyurl.com/Zeetalkies

#EXTINF:-1 tvg-id="ZeeMarathi.in" tvg-name="Zee Cinemalu" tvg-ID="ZeeCinemalu" tvg-logo="https://zeelwebsite.s3.amazonaws.com/zeetele/wp-content/uploads/2017/10/Zee-Cinemalu1.png" group-title="MIX INDIAN", Zee Marathi
http://kmkus.wanicelife.com:8880/live/12m0390043/17783455/1877.m3u8

#EXTINF:-1 tvg-id="ZeeBanglaCinema.in" tvg-name="Zee Bangla Cinema" tvg-ID="ZeeBanglaCinema" tvg-logo="https://img.favpng.com/19/20/13/zee-bangla-cinema-logo-zee-cinema-bengali-language-png-favpng-EGC6aFQLMrSkPamz03cLVYU4L.jpg" group-title="MIX INDIAN", Zee Bangla Cinema
http://102.222.232.18:9981/stream/channelid/1504925537?ticket=56C518288A4256585B8C118EA7CD3307E3929D0D&profile=matroska 

#EXTINF:-1 tvg-id="ZeePunjabHaryanaHimachal.in" tvg-name="Zee Picchar" tvg-ID="ZeePicchar" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/d/df/Zee_Picchar_new.png/revision/latest?cb=20200324034609" group-title="MIX INDIAN", Zee Picchar
https://tinyurl.com/Zeepicchar

#EXTINF:-1 tvg-id="StarVijay.in" ch-number="221" group-title="MIX INDIAN" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/357_144.png",Star Vijay
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2707
https://linearjitp-playback.astro.com.my/dash-wv/linear/2707/default_primary.mpd

#EXTINF:-1 tvg-id="StarGoldHD.in" tvg-name="Star Gold HD India" tvg-logo="https://i.ibb.co/ngntF9d/Star-Gold-2011.png" group-title="MIX INDIAN",Star Gold
http://144.217.70.181:9587/hin2/STARGOLDUK/tracks-v1a1/mono.m3u8?token=test

#EXTINF:-1 tvg-id="CHN" group-title="MIX INDIAN" tvg-logo="https://i.ibb.co/2ndFV0R/logo.png",BollywoodHD Movies
https://d35j504z0x2vu2.cloudfront.net/v1/manifest/0bc8e8376bd8417a1b6761138aa41c26c7309312/bollywood-hd/4b8e0fb1-8b97-4410-90ff-346e052badff/2.m3u8

#EXTINF:-1 tvg-id="CHN" group-title="MIX INDIAN" tvg-logo="https://i.ibb.co/TBCSCxj/sssssssssssssssssssssssssssss.png",BollywoodClassic Movies
https://d35j504z0x2vu2.cloudfront.net/v1/manifest/0bc8e8376bd8417a1b6761138aa41c26c7309312/bollywood-classic/511e7e4e-f905-4a1c-80e3-4cec03691eec/0.m3u8

#EXTINF:-1 tvg-id="BollywoodBoxOfficeHD.in" tvg-id="BollywoodBoxOfficeHD.in" tvg-name="Bollywood BoxOffice HD" tvg-logo="https://i.ibb.co/HxQYVYB/bbo-white.png" group-title="MIX INDIAN",Bollywood BoxOffice HD
http://watchindia.net:8880/live/14100/70701/2157.m3u8

#EXTINF:-1 tvg-id="KollywoodBoxOfficeHD.in" tvg-name="Kollywood BoxOffice HD" tvg-logo="https://i.ibb.co/HxQYVYB/bbo-white.png" group-title="MIX INDIAN",Kollywood BoxOffice HD
http://watchindia.net:8880/live/14100/70701/2152.m3u8

#EXTINF:-1 tvg-id="UtsavGold.in" tvg-name="Star Utsav Movies" tvg-logo="https://i.ibb.co/jkwqqzW/download.jpg" group-title="MIX INDIAN",Utsav Gold
http://watchindia.net:8880/live/14100/70701/2300.m3u8

#EXTINF:-1 tvg-id="UtsavPlus.uk" tvg-name="Star Utsav" tvg-logo="https://i.ibb.co/DG5Q3vk/Star-plus-2016.png" group-title="MIX INDIAN",Utsav Plus
http://watchindia.net:8880/live/14100/70701/1925.m3u8

#EXTINF:-1 tvg-id="Jaya.in" tvg-name="TTS| JAYA TV HD" tvg-logo="http://logo.protv.cc/picons/logos/JAYA-TV-HD.jpeg" group-title="MIX INDIAN",Jaya TV
http://kmkus.wanicelife.com:8880/live/12m0390043/17783455/1944.m3u8
http://line.premiumpowers.net:80/Bianca/1234567/946028

#EXTINF:0 group-title="MIX INDIAN" tvg-logo="https://austamil.tv/wp-content/uploads/2020/04/aus-tamil-HD-New-e1586081963171.png", AUus Tamil
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=hls
#KODIPROP:inputstream.adaptive.mime_type=application/vnd.apple.mpegurl
https://bk7l2pn7dx53-hls-live.5centscdn.com/austamil/fe01ce2a7fbac8fafaed7c982a04e229.sdp/chunks.m3u8

#EXTINF:0, group-title="MIX INDIAN" tvg-logo="http://www.tamilvision.tv/Images/logo.png",Tamil Vision TV
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=hls
#KODIPROP:inputstream.adaptive.mime_type=application/vnd.apple.mpegurl
http://live.tamilvision.tv:8081/TVI/HD/playlist.m3u8

#EXTINF:0 group-title="MIX INDIAN" tvg-logo="http://athavantv.com/wp-content/uploads/2019/01/athavantv-hd-logo.png", Adhavan TV
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=hls
#KODIPROP:inputstream.adaptive.mime_type=application/vnd.apple.mpegurl
http://45.77.66.224:1935/athavantv/live/playlist.m3u8

#EXTINF:0 group-title="MIX INDIAN" tvg-logo="https://threetamil.tv/wp-content/uploads/2020/08/3Tamil_logo_white.png", 3 Tamil
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=hls
#KODIPROP:inputstream.adaptive.mime_type=application/vnd.apple.mpegurl
https://6n3yogbnd9ok-hls-live.5centscdn.com/threetamil/d0dbe915091d400bd8ee7f27f0791303.sdp/index.m3u8

#EXTINF:0 group-title="MIX INDIAN" tvg-logo="https://i.imgur.com/EaHWWNl.jpg",7Star TV
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=hls
#KODIPROP:inputstream.adaptive.mime_type=application/vnd.apple.mpegurl
http://media.7starcloud.com:1935/live/7star/playlist.m3u8

#EXTINF:0 group-title="MIX INDIAN" tvg-logo="https://i.imgur.com/zAQSZeC.png",Sana TV
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=hls
#KODIPROP:inputstream.adaptive.mime_type=application/vnd.apple.mpegurl
http://7starcloud.com:1935/sanatv/sanatv/playlist.m3u8

#EXTINF:0 group-title="MIX INDIAN" tvg-logo="https://yt3.ggpht.com/ytc/AAUvwngU3LWhh8SErFHPH0yKtfsCt4cYrq-EbNnGjICWLA=s88-c-k-c0x00ffffff-no-rj",Tirumalai TV KARUR
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=hls
#KODIPROP:inputstream.adaptive.mime_type=application/vnd.apple.mpegurl
http://media.7starcloud.com:1935/tirumalaitv/stream/playlist.m3u8

#EXTINF:0 group-title="MIX INDIAN" tvg-logo="https://kccl.tv/sites/default/files/mksix.jpg",MK Six
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=hls
#KODIPROP:inputstream.adaptive.mime_type=application/vnd.apple.mpegurl
http://103.199.160.85/Content/mktv6/Live/Channel(MKTV6)/index.m3u8

#EXTINF:0 group-title="MIX INDIAN" tvg-logo="https://kccl.tv/sites/default/files/mk%20tunes.jpg",MK Tunes
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=hls
#KODIPROP:inputstream.adaptive.mime_type=application/vnd.apple.mpegurl
http://103.199.160.85/Content/mktunes/Live/Channel(MKTunes)/index.m3u8

#EXTINF:0 group-title="MIX INDIAN" tvg-logo="http://mktv.akst.in/wp-content/uploads/2018/10/mk-tv.png",MK TV
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=hls
#KODIPROP:inputstream.adaptive.mime_type=application/vnd.apple.mpegurl
http://103.199.160.85/Content/mktv/Live/Channel(MKTV)/index.m3u8

#EXTINF:0 tvg-logo="https://i.imgur.com/f7J37yv.png" group-title="MIX INDIAN",EET TV
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=hls
#KODIPROP:inputstream.adaptive.mime_type=application/vnd.apple.mpegurl
https://eu.streamjo.com/eetlive/eettv.m3u8

#EXTINF:0, group-title="MIX INDIAN" tvg-logo="http://haritv.com/images/logo.png",HARI TV
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=hls
#KODIPROP:inputstream.adaptive.mime_type=application/vnd.apple.mpegurl
http://media.7starcloud.com:1935/harimedia/haritv/playlist.m3u8

#EXTINF:0 tvg-logo="https://i.imgur.com/kKFfLMd.jpg" group-title="MIX INDIAN",Santhora Short Flim
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=hls
#KODIPROP:inputstream.adaptive.mime_type=application/vnd.apple.mpegurl
http://rtmp.santhoratv.zecast.net/santhora/santhorashortfilm/chunklist_w342316663.m3u8

#EXTINF:0, group-title="MIX INDIAN" tvg-logo="http://santhora.tv/wp-content/uploads/2019/05/header-logo-anim.gif",Santhora TV
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=hls
#KODIPROP:inputstream.adaptive.mime_type=application/vnd.apple.mpegurl
http://rtmp.santhoratv.zecast.net/santhoratv/santhoratv/playlist.m3u8

#EXTINF:0, group-title="MIX INDIAN" tvg-logo="http://www.erodesrikrishnatv.com/images/logo.png",SRI KRISHNA TV
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=hls
#KODIPROP:inputstream.adaptive.mime_type=application/vnd.apple.mpegurl
http://media.7starcloud.com:1935/erodekrishnatv/livestream/playlist.m3u8

#EXTINF:0 tvg-logo="https://i.imgur.com/ABvVSga.png" group-title="MIX INDIAN",Akaram Kidz
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=hls
#KODIPROP:inputstream.adaptive.mime_type=application/vnd.apple.mpegurl
http://akaram.zecast.net/akaram-live/akaramkidz/index.m3u8

#EXTINF:0 tvg-logo="https://i.imgur.com/MYZ6EXU.png" group-title="MIX INDIAN",Kalaignar TV 
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=hls
#KODIPROP:inputstream.adaptive.mime_type=application/vnd.apple.mpegurl
http://103.199.161.254/Content/kalaignartv/Live/Channel(KalaignarTV)/index.m3u8

#EXTINF:0 tvg-logo="http://www.rajtvnet.in/Raj_Net/Bottom_Scroller_Logo/Tamil_Rajtv.png" group-title="MIX INDIAN",Raj TV
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=hls
#KODIPROP:inputstream.adaptive.mime_type=application/vnd.apple.mpegurl
http://103.199.161.254/Content/rajtv/Live/Channel(RajTV)/Stream(01)/index.m3u8

#EXTINF:0 tvg-logo="https://play-lh.googleusercontent.com/mNX-Fl-1cgwBzuF8m8YFcaF7GGNUQAl5gLtH7eJNrYSZHYnw1GIVgTXSQT5K7OEM_1aE=s180" group-title="MIX INDIAN",Yupp TV Tamil Classics 
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=hls
#KODIPROP:inputstream.adaptive.mime_type=application/vnd.apple.mpegurl
https://d1fi19tywmn14b.cloudfront.net/yuppindmov/ngrp:ytamcla.stream_all/playlist.m3u8

#EXTINF:0 tvg-logo="" group-title="MIX INDIAN",Jay TV
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=hls
#KODIPROP:inputstream.adaptive.mime_type=application/vnd.apple.mpegurl
http://livematrix.in:1935/live/jay/index.m3u8

#EXTINF:0 tvg-logo="https://i.imgur.com/YeR3mm9.png" group-title="MIX INDIAN",Velicham TV
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=hls
#KODIPROP:inputstream.adaptive.mime_type=application/vnd.apple.mpegurl
https://rtmp.smartstream.video/velichamtv/velichamtv/playlist.m3u8

#EXTINF:0, tvg-id="DDMadhyaPradesh.in" group-title="MIX INDIAN" tvg-logo="https://d229kpbsb5jevy.cloudfront.net/tv/150/150/bnw/Madha_TV-black.png",Madha TV
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=hls
#KODIPROP:inputstream.adaptive.mime_type=application/vnd.apple.mpegurl
http://103.109.45.5:1935/madhatv/madhatv.stream_HDp/chunklist_w67072347.m3u8

#EXTINF:1 tvg-id="B4UMoviesIndia.in" tvg-name="B4U Movies India" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTNStmeIQpe4pTxs94MTXed-SUZS1BdLw_2kQ&usqp=CAU" group-title="MIX INDIAN",B4U Movie 
# http://line.premiumpowers.net:80/Bianca/1234567/42443
http://watchindia.net:8880/live/14100/70701/823.ts

#KODIPROP:inputstream.adaptive.manifest_type=mpd
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key=https://dukun.masuk.id/drm/result.php?keyid=ce17264b317db108f19cdc11aa1a9e66&key=a21188aee8fc5c56d016fcffcc6b2295
#EXTINF:-1 tvg-id="SonyEntertainmentTelevision.in" tvg-logo="https://i.ibb.co/svZGRrs/Sony-modified.png" group-title="MIX INDIAN",Sony TV
https://cdn-01.toffeelive.com/origin-08/live-origin/smil:sony_entertainmnt_hd.smil/manifest.mpd

#KODIPROP:inputstream.adaptive.manifest_type=mpd
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key=https://dukun.masuk.id/drm/result.php?keyid=ce17264b317db108f19cdc11aa1a9e66&key=a21188aee8fc5c56d016fcffcc6b2295
#EXTINF:-1 tvg-id="SonySABIndia.in" tvg-name="Sony SAB TV India" tvg-logo="https://raw.githubusercontent.com/kpsboy/LOGO-KPSBOY/main/ASTRO/sonysab.png" group-title="MIX INDIAN",Sony Sab
https://cdn-01.toffeelive.com/origin-08/live-origin/smil:sony_sab_hd.smil/manifest.mpd

#KODIPROP:inputstream.adaptive.manifest_type=mpd
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key=https://dukun.masuk.id/drm/result.php?keyid=ce17264b317db108f19cdc11aa1a9e66&key=a21188aee8fc5c56d016fcffcc6b2295
#EXTINF:-1 tvg-id="SonyMax2.in" tvg-name="Sony Max India" tvg-logo="https://images.toffeelive.com/images/program/641/logo/115x115/mobile_logo_602468001571288709.png" group-title="MIX INDIAN",Sony Max
https://cdn-01.toffeelive.com/origin-09/live-origin/smil:set_max_hd.smil/manifest.mpd
# http://208.86.19.13:81/706.stream/index.m3u8

#EXTINF:-1 tvg-id="BflixMovies.in" tvg-name="Bflix Movies" tvg-logo="https://www.tvchannelpricelist.com/wp-content/uploads/channels-logo-300/bflix-movies-logo-300x300.jpg" group-title="MIX INDIAN",Bflix Movies
https://m-c036-j2apps.s.llnwi.net/hls/5045.BFlixMovies.in_480p/index.m3u8







#######################################################################################################################################################################

###########################






#EXTINF:-1 tvg-id="CHN" tvg-name="" group-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="MIX CHINESE",INFO PENGGUNAAN DNS CHANGER
#https://tinyurl.com/Guna-DNS-Changer

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="MIX CHINESE",SILA KLIK DAN BACA!!
https://tinyurl.com/sila-baca-la-oii

#EXTINF:-1 tvg-id="CHN" tvg-name="" group-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="MIX CHINESE",VISIT MY SHOP 
https://tinyurl.com/visit-kedai-saya

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="MIX CHINESE",JOIN GROUP TELEGRAM 
https://tinyurl.com/Joingrouptele

#EXTINF:-1 tvg-id="GoShopChinese.my" ch-number="303" group-title="MIX CHINESE" tvg-logo="https://i.kampung.xyz/c/3c09cfb4117ed995.png",Go Shop 2
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/1005
https://linearjitp-playback.astro.com.my/dash-wv/linear/1005/default_ott.mpd
# https://agsplayback01.astro.com.my/CH2/master_GOSHOP2_04.m3u8

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/1006
#EXTINF:-1 tvg-id="iQIYI.cn" ch-number="IQIYI" tvg-logo="https://github.com/angahjee1994/logo/blob/master/iqiyi.png?raw=true" group-title="MIX CHINESE",iQIYI 
https://linearjitp-playback.astro.com.my/dash-wv/linear/1006/default_primary.mpd
# https://stream.zeehanzgadget.com/iqiyi.mpd

#EXTINF:-1 tvg-id="AstroAEC.my" ch-number="AstroAEC" tvg-logo="https://i.ibb.co/ZNGPbCN/Astro-AEC.png" group-title="MIX CHINESE",Astro AEC ⁽ˢᵉʳᵛᵉʳ ¹⁾
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2400
https://stream.zeehanzgadget.com/aec

#EXTINF:-1 tvg-id="AstroAEC.my" tvg-name="Astro AEC HD" group-title="MIX CHINESE" tvg-logo="https://iili.io/1NBT5F.png",Astro AEC ⁽ˢᵉʳᵛᵉʳ ²⁾
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2400
http://kmkus.wanicelife.com:8880/live/12m0390043/17783455/1723.m3u8
https://aqfadtv.xyz/live/aec/index.mpd 

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2706
#EXTINF:-1 tvg-id="AstroAOD311.my" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/87_144.png" group-title="MIX CHINESE",Astro AOD 311
https://linearjitp-playback.astro.com.my/dash-wv/linear/2706/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey 
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/700 
#EXTINF:-1, tvg-id="AstroAOD352.my" group-title="MIX CHINESE" tvg-logo="https://telegra.ph/file/7b8552216f731395d5165.png",Astro AOD 352 
http://linearjitp-playback.astro.com.my/dash-wv/linear/700/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/905
#EXTINF:-1 tvg-id="AstroAOD353.my" ch-number="353" group-title="MIX CHINESE" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/9/9e/Astro_AOD.jpg/revision/latest?cb=20191122014109",Astro AOD 353 
#http://linearjitp-playback.astro.com.my/dash-wv/linear/905/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey 
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/212 
#EXTINF:-1, tvg-id="AstroAOD354.my" group-title="MIX CHINESE" tvg-logo="https://telegra.ph/file/7b8552216f731395d5165.png",Astro AOD 354 
http://linearjitp-playback.astro.com.my/dash-wv/linear/212/default_primary.mpd 

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/307
#EXTINF:-1 tvg-id="AstroAOD355.my" ch-number="355" group-title="MIX CHINESE" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/9/9e/Astro_AOD.jpg/revision/latest?cb=20191122014109",Astro AOD 355 
#http://linearjitp-playback.astro.com.my/dash-wv/linear/307/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2711
#EXTINF:-1 tvg-id="AstroXiaoTaiYang.my" ch-number="AstroXiaoTaiYang" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/387_144.png" group-title="MIX CHINESE",Astro Xiao Tai Yang  
https://linearjitp-playback.astro.com.my/dash-wv/linear/2711/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/dash-ck/linear/2403
#EXTINF:-1 tvg-id="AstroShuangXing.my" ch-number="AstroShuangXing" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/183_144.png" group-title="MIX CHINESE",Astro Shuang Xing 
https://linearjitp-playback.astro.com.my/dash-wv/linear/2403/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2507
#EXTINF:-1 tvg-id="AstroQuanJiaHD.my" ch-number="AstroQuanJiaHD" group-title="MIX CHINESE" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/158_144.png",Astro Quan Jia 
http://kmkus.wanicelife.com:8880/live/12m0390043/17783455/1723.m3u81728.m3u8
# https://linearjitp-playback.astro.com.my/dash-wv/linear/2507/default_primary.mpd

#EXTINF:-1 tvg-id="AstroHuaHeeDai.my" ch-number="333" group-title="MIX CHINESE" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/b/bb/Astro_Hua_Hee_Dai_%282015%29.png/revision/latest/scale-to-width-down/250?cb=20200914130021",Astro Hua Hee Dai
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2308
https://linearjitp-playback.astro.com.my/dash-wv/linear/2308/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5017
#EXTINF:-1 tvg-id="CTiAsia.tw" ch-number="CTIAsia" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/424_144.png" group-title="MIX CHINESE",CTI Asia 
https://linearjitp-playback.astro.com.my/dash-wv/linear/5017/default_primary.mpd

#EXTINF:-1 group-title="MIX CHINESE" tvg-id="CHN" ch-number="CHN" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/7/7e/TVB_logo.svg/revision/latest/scale-to-width-down/250?cb=20220217023951",TVB Fc
https://live.astradamy.com/tvbfc/index.m3u8

#EXTINF:-1 group-title="MIX CHINESE" tvg-id="CHN" ch-number="CHN" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/4/45/B55FD111-11A0-47A5-8E29-B160EC5C26DA.png/revision/latest/scale-to-width-down/184?cb=20200416054524",TVB J2
https://live.astradamy.com/tvbj2/index.m3u8

#EXTINF:-1 group-title="MIX CHINESE" tvg-id="CHN" ch-number="CHN" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/1/12/Free-Pearl.png/revision/latest/scale-to-width-down/299?cb=20171102192504",TVB Pearl
https://live.astradamy.com/tvbpearl/index.m3u8

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5016
#EXTINF:-1 tvg-id="TVBClassic.hk" ch-number="TVBClassic" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/425_144.png" group-title="MIX CHINESE",TVB Classic  
https://linearjitp-playback.astro.com.my/dash-wv/linear/5016/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2600
#EXTINF:-1 tvg-id="Jade.hk" ch-number="TVBJade" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/203_144.png" group-title="MIX CHINESE",TVB Jade  
https://linearjitp-playback.astro.com.my/dash-wv/linear/2600/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5015
#EXTINF:-1 tvg-id="EntertainmentNews.hk" ch-number="TVBEntertainmentNews" tvg-logo="https://linear-poster.astro.com.my/prod/logo/TVBE_v1.png" group-title="MIX CHINESE",TVB Entertainment News 
https://linearjitp-playback.astro.com.my/dash-wv/linear/5015/default_primary.mpd

#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/401
#EXTINF:-1 tvg-id="TVBXingHe.hk" ch-number="TVBXingHe" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/383_144.png" group-title="MIX CHINESE",TVB Xing He 
https://linearjitp-playback.astro.com.my/dash-wv/linear/401/default_primary.mpd

#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={ "keys":[ { "kty":"oct", "k":"NG8PYMvXWR4a5yyliRV7sQ", "kid":"52qJoeI/j3uCj029wtCaEA" } ], "type":"temporary" }
#EXTINF:-1 tvg-id="TVBSAsia.tw" ch-number="TVBSAsia" tvg-logo="https://linear-poster.astro.com.my/prod/logo/TVBS_v1.png" group-title="MIX CHINESE",TVBS Asia 
https://linearjitp-playback.astro.com.my/dash-wv/linear/402/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5008
#EXTINF:-1 tvg-id="323" ch-number="TVBSNews" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/414_144.png" group-title="MIX CHINESE",TVBS News 
https://linearjitp-playback.astro.com.my/dash-wv/linear/5008/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/403
#EXTINF:-1 tvg-id="CCTV4Asia.cn" ch-number="CCTV4" tvg-logo="https://linear-poster.astro.com.my/prod/logo/CCTV4_v1.png" group-title="MIX CHINESE",CCTV4 
https://linearjitp-playback.astro.com.my/dash-wv/linear/403/default_primary.mpd

#EXTINF:-1 tvg-id="PhoenixChineseChannel.hk" ch-number="325" group-title="MIX CHINESE" tvg-logo="https://i.postimg.cc/MHNpH3St/Phoenix-Chinese-Channel.png",Phoenix Chinese Channel
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/400
http://linearjitp-playback.astro.com.my/dash-wv/linear/400/default_primary.mpd

#EXTINF:-1 tvg-id="PhoenixInfoNewsChannel.hk" ch-number="326" group-title="MIX CHINESE" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/43_144.png",Phoenix Info News 
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5009
http://linearjitp-playback.astro.com.my/dash-wv/linear/5009/default_primary.mpd

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://www.lyngsat.com/logo/tv/mm/macau_lotus_tv_mo.png" group-title="MIX CHINESE",Lotus Macau
http://nettvpro.live/hls/lotustv.php

#EXTINF:-1 group-title="MIX CHINESE" tvg-id="CHN" ch-number="CHN" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/3/3b/RTHK.png/revision/latest/scale-to-width-down/210?cb=20140629082053",RTHK 32
https://rthklive2-lh.akamaihd.net/i/rthk32_1@168450/master.m3u8

#EXTINF:-1 group-title="MIX CHINESE" tvg-id="CHN" ch-number="CHN" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/3/3b/RTHK.png/revision/latest/scale-to-width-down/210?cb=20140629082053",RTHK 33
https://live.astradamy.com/hk33/index.m3u8

#EXTINF:-1 group-title="MIX CHINESE" tvg-id="CHN" ch-number="CHN" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/3/3b/RTHK.png/revision/latest/scale-to-width-down/210?cb=20140629082053",RTHK 76
https://live.astradamy.com/hk76/index.m3u8

#EXTINF:-1 tvg-id="ViuTV.hk" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a8/Viu_logo.svg/1200px-Viu_logo.svg.png" tvg-id="CHN" group-title="MIX CHINESE",Viu TV
#https://cdn.hkdtmb.com/hls/99/index.m3u8
https://live.astradamy.com/viutv/index.m3u8

#EXTINF:-1 tvg-id="ViuTVsix.hk" group-title="MIX CHINESE" tvg-id="CHN" ch-number="CHN" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a1/ViuTVsix-logo.svg/200px-ViuTVsix-logo.svg.png",Viu TV 6
https://live.astradamy.com/viutv6/index.m3u8

#EXTINF:-1 group-title="MIX CHINESE" tvg-id="CHN" ch-number="CHN" tvg-logo="https://daai.tv/images/logo.png",Daai TV 1
https://pulltv1.wanfudaluye.com/live/tv1.m3u8

#EXTINF:-1 group-title="MIX CHINESE" tvg-id="CHN" ch-number="CHN" tvg-logo="https://daai.tv/images/logo.png",Daai TV 2
https://pulltv2.wanfudaluye.com/live/tv2.m3u8

#EXTINF:-1 group-title="MIX CHINESE" tvg-id="CHN" ch-number="CHN" tvg-logo="https://i.ibb.co/syzz7bq/661-6612023-bright-star-tv.png",Bright TV
http://202.69.67.66:443/webcast/bshdlive-pc/playlist.m3u8

#EXTINF:-1 group-title="MIX CHINESE" tvg-id="CHN" ch-number="CHN" tvg-logo="https://i.ibb.co/7JnjM6x/1280px-China-TV-logo-since-19971030-svg.png",Chinese TV 1
http://38.64.72.148:80/hls/modn/list/4001/chunklist0.m3u8

#EXTINF:-1 group-title="MIX CHINESE" tvg-id="CHN" ch-number="CHN" tvg-logo="https://i.ibb.co/7JnjM6x/1280px-China-TV-logo-since-19971030-svg.png",Chinese TV 3
http://38.64.72.148:80/hls/modn/list/4003/chunklist0.m3u8

#EXTINF:-1 group-title="MIX CHINESE" tvg-id="CHN" ch-number="CHN" tvg-logo="https://i.ibb.co/qxyRLvJ/gwelt.png",Great Wall Elite
http://38.64.72.148:80/hls/modn/list/4008/chunklist0.m3u8

#EXTINF:-1 group-title="MIX CHINESE" tvg-id="CHN" ch-number="CHN" tvg-logo="https://i.ibb.co/bd81gJz/dali-logo-2019-nopayoff-cmyk-800x800.jpg",Dali TV
http://www.dalitv.com.tw:4568/live/dali/index.m3u8

#EXTINF:-1 group-title="MIX CHINESE" tvg-id="CHN" ch-number="CHN" tvg-logo="https://i.ibb.co/KGCHv7w/TITV-Thailand-Logo-2007.png",Titv
http://streamipcf.akamaized.net/live/_definst_/live_720/chunklist_b1500.m3u8

#EXTINF:-1 group-title="MIX CHINESE" tvg-id="CHN" ch-number="CHN" tvg-logo="https://i.ibb.co/D8qmdSC/Phoenix-Info-News-svg.png",Ifeng news
http://play-live.ifeng.com/live/06OLEEWQKN4.m3u8

#EXTINF:-1 group-title="MIX CHINESE" tvg-id="CHN" ch-number="CHN" tvg-logo="https://i.ibb.co/Xy1kqC9/bread-50aef7afe93a1.png",Bread TV
https://video.bread-tv.com:8091/hls-live24/online/index.m3u8

#EXTINF:-1 group-title="MIX CHINESE" tvg-id="CHN" ch-number="CHN" tvg-logo="https://i.ibb.co/44Y6dQX/512x512bb.jpg",Brics TV
http://brics.bonus-tv.ru/cdn/brics/chinese/tracks-v1a1/index.m3u8

#EXTINF:-1 group-title="MIX CHINESE" tvg-id="CHN" ch-number="CHN" tvg-logo="https://i.ibb.co/WVcFj2Q/1200px-TVBS-svg.png",Tvbs
http://38.64.72.148:80/hls/modn/list/4006/chunklist1.m3u8

#EXTINF:-1 tvg-id="HOYTV.hk" tvg-logo="https://i.imgur.com/3VLa4qg.jpg" group-title="MIX CHINESE",Hoy TV 
http://media.fantv.hk/m3u8/archive/channel2.m3u8

#EXTINF:0 group-title="MIX CHINESE" tvg-logo="https://lh3.googleusercontent.com/--LjxdM2YyhA/Y0KqSAh8OgI/AAAAAAAAB1o/KBYeXNi2tlo2fOAP7ZPVWz_MEikDEsWHACNcBGAsYHQ/s1600/1665313350332554-1.png",FTV General 
#EXTVLCOPT:http-user-agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36"
https://cdn2live.sky4k.top/4gtv/?id=twms_BzIPTV_4K

#EXTINF:0 group-title="MIX CHINESE" tvg-logo="https://lh3.googleusercontent.com/-6WS4rLOA8_8/Y0KqRNtWYzI/AAAAAAAAB1k/cbAOu9T4qQEnRA6ziEokCy3Ic5cTBw9HACNcBGAsYHQ/s1600/1665313346793424-2.png",FTV News
#EXTVLCOPT:http-user-agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36"
https://cdn2live.sky4k.top/4gtv/?id=twmsxwt_BzIPTV_4K

#EXTINF:0 group-title="MIX CHINESE" tvg-logo="https://lh3.googleusercontent.com/-LiEzyNt222Q/Y0Ks3H4n-LI/AAAAAAAAB2E/2LVGCVsWgWIqz1iLPY9BSIGuKGsQ9MJbgCNcBGAsYHQ/s1600/1665314009926342-0.png",FTV Travel Channel
#EXTVLCOPT:http-user-agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36"
https://cdn2live.sky4k.top/4gtv/?id=twmsly_BzIPTV_4K

#EXTINF:0 group-title="MIX CHINESE" tvg-logo="https://lh3.googleusercontent.com/-E-kmz6tKxXs/Y0KqQVl3z2I/AAAAAAAAB1g/-f5IQHy6RdowaUKo1AmSFHKFqArnGLQ2QCNcBGAsYHQ/s1600/1665313343346147-3.png",FTV Taiwan
#EXTVLCOPT:http-user-agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36"
https://cdn2live.sky4k.top/4gtv/?id=twmstw_BzIPTV_4K

#EXTINF:0 group-title="MIX CHINESE" tvg-logo="https://lh3.googleusercontent.com/-ndUV_II6zJw/Y0Kr1KTXjbI/AAAAAAAAB18/6KJdLKT3Xhwx0mmmlADcntXPV2LBJt9wwCNcBGAsYHQ/s1600/1665313746095558-0.png",MinTV Film
#EXTVLCOPT:http-user-agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36"
https://cdn2live.sky4k.top/4gtv/?id=twmsyj_BzIPTV_4K

#EXTINF:0 group-title="MIX CHINESE" tvg-logo="https://lh3.googleusercontent.com/-fT_DknbCMJY/Y0KqTMeQ4TI/AAAAAAAAB1s/XvCA2xlRS6Q-BI49kWPhYjzblh7EntQDACNcBGAsYHQ/s1600/1665313354055381-0.png",FTV No 1
#EXTVLCOPT:http-user-agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36"
https://cdn2live.sky4k.top/4gtv/?id=twmsdy_BzIPTV_4K

#EXTINF:0 group-title="MIX CHINESE" tvg-logo="https://lh3.googleusercontent.com/-_A8mrsj2GbI/Y0KqPb1bZQI/AAAAAAAAB1c/s2kvmEMfPh4_mJEIaRzA5GBq0lyeBmKJQCNcBGAsYHQ/s1600/1665313339495568-4.png",FTV Variety Show
#EXTVLCOPT:http-user-agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36"
https://cdn2live.sky4k.top/4gtv/?id=twmszy_BzIPTV_4K

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=ZGFkZmZkZjItYzQ1Mi0zM2RiLTk0OWQtM2M2YmY1YzZjMDNi
#EXTINF:-1 group-title="MIX CHINESE" tvg-logo="https://i.imgur.com/bKgwJZb.png?1", Jiangsu TV
https://av-live-cdn.mncnow.id/live/eds/JiangsuTV/sa_dash_vmx/JiangsuTV.mpd

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=ZGFkZmZkZjItYzQ1Mi0zM2RiLTk0OWQtM2M2YmY1YzZjMDNi
#EXTINF:-1 group-title="MIX CHINESE" tvg-logo="https://i.imgur.com/rciggYQ.jpg", Hunan TV
https://av-live-cdn.mncnow.id/live/eds/HunanTV/sa_dash_vmx/HunanTV.mpd

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=ZGFkZmZkZjItYzQ1Mi0zM2RiLTk0OWQtM2M2YmY1YzZjMDNi
#EXTINF:-1 group-title="MIX CHINESE" tvg-logo="http://www.masmiri.50webs.com/page2/Satelite%20TV/Dragon%20tv.png", Shanghai Dragon TV
https://av-live-cdn.mncnow.id/live/eds/ShanghaiDragonTV/sa_dash_vmx/ShanghaiDragonTV.mpd

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=ZGFkZmZkZjItYzQ1Mi0zM2RiLTk0OWQtM2M2YmY1YzZjMDNi
#EXTINF:-1 group-title="MIX CHINESE" tvg-logo="https://upload.wikimedia.org/wikipedia/zh/thumb/8/8d/Xing_Kong_Wei_Shi.jpg/250px-Xing_Kong_Wei_Shi.jpg",Xingkong TV
https://av-live-cdn.mncnow.id/live/eds/XingKongTV/sa_dash_vmx/XingKongTV.mpd

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=ZGFkZmZkZjItYzQ1Mi0zM2RiLTk0OWQtM2M2YmY1YzZjMDNi
#EXTINF:-1 group-title="MIX CHINESE" tvg-logo="http://epg.51zmt.top:8000/tb1/ws/anhui.png", Anhui TV
https://av-live-cdn.mncnow.id/live/eds/AnhuiTV/sa_dash_vmx/AnhuiTV.mpd

#EXTINF:-1 tvg-logo="https://upload.wikimedia.org/wikipedia/en/thumb/4/4d/Teledifus%C3%A3o_de_Macau.png/250px-Teledifus%C3%A3o_de_Macau.png" group-title="MIX CHINESE", Macau TV
http://live4.tdm.com.mo/ch3/_definst_//ch3.live/playlist.m3u8

#EXTINF:-1 tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/2/20/Beijing_Television_Logo_2009.png/800px-Beijing_Television_Logo_2009.png" group-title="MIX CHINESE",Beijing  
http://hwrr.jx.chinamobile.com:8080/PLTV/88888888/224/3221225673/index.m3u8
  
#EXTINF:-0 tvg-id="CCTV1.cn" group-title="MIX CHINESE",CCTV 1 
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
http://[2409:8087:3869:8021:1001::e5]:6610/PLTV/88888910/224/3221225642/index.m3u8
http://125.40.191.58:9901/tsfile/live/0001_1.m3u8

#EXTINF:-0 tvg-id="CCTV2.cn" group-title="MIX CHINESE",CCTV 2 
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
http://[2409:8087:3869:8021:1001::e5]:6610/PLTV/88888910/224/3221225643/index.m3u8
http://125.40.191.58:9901/tsfile/live/0002_1.m3u8 

#EXTINF:-0 tvg-id="CCTV3.cn" group-title="MIX CHINESE",CCTV 3 
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
http://[2409:8087:3869:8021:1001::e5]:6610/PLTV/88888910/224/3221225634/index.m3u8
http://222.175.159.226:808/hls/3/index.m3u8

#EXTINF:-0 tvg-id="CCTV4.cn" group-title="MIX CHINESE",CCTV 4 
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
http://[2409:8087:3869:8021:1001::e5]:6610/PLTV/88888910/224/3221225621/index.m3u8
http://222.175.159.226:808/hls/4/index.m3u8

#EXTINF:-0 tvg-id="CCTV5.cn" group-title="MIX CHINESE",CCTV 5 
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
http://[2409:8087:3869:8021:1001::e5]:6610/PLTV/88888910/224/3221225633/index.m3u8
http://125.40.191.58:9901/tsfile/live/0005_1.m3u8 
http://222.175.159.226:808/hls/5/index.m3u8

#EXTINF:-0 tvg-id="CCTV5Plus.cn" group-title="MIX CHINESE",CCTV 5＋ 
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
http://[2409:8087:3869:8021:1001::e5]:6610/PLTV/88888910/224/3221225706/index.m3u8
http://222.175.159.226:808/hls/6/index.m3u8 

#EXTINF:-0 tvg-id="CCTV6.cn" group-title="MIX CHINESE",CCTV 6 
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
http://[2409:8087:3869:8021:1001::e5]:6610/PLTV/88888910/224/3221225632/index.m3u8
http://125.40.191.58:9901/tsfile/live/0007_1.m3u8

#EXTINF:-0 tvg-id="CCTV7.cn" group-title="MIX CHINESE",CCTV 7 
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
http://[2409:8087:3869:8021:1001::e5]:6610/PLTV/88888910/224/3221225624/index.m3u8
http://222.175.159.226:808/hls/8/index.m3u8

#EXTINF:-0 tvg-id="CCTV8.cn" group-title="MIX CHINESE",CCTV 8 
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
http://[2409:8087:3869:8021:1001::e5]:6610/PLTV/88888910/224/3221225631/index.m3u8
http://222.175.159.226:808/hls/9/index.m3u8 

#EXTINF:-0 tvg-id="CCTV9.cn" group-title="MIX CHINESE",CCTV 9 
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
http://[2409:8087:3869:8021:1001::e5]:6610/PLTV/88888910/224/3221225646/index.m3u8
http://222.175.159.226:808/hls/10/index.m3u8

#EXTINF:-0 tvg-id="CCTV10.cn" group-title="MIX CHINESE",CCTV 10 
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
http://[2409:8087:3869:8021:1001::e5]:6610/PLTV/88888910/224/3221225636/index.m3u8
http://222.175.159.226:808/hls/11/index.m3u8 

#EXTINF:-0 tvg-id="CCTV11.cn" group-title="MIX CHINESE",CCTV 11
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
http://[2409:8087:3869:8021:1001::e5]:6610/PLTV/88888910/224/3221225628/index.m3u8
http://222.175.159.226:808/hls/12/index.m3u8 

#EXTINF:-0 tvg-id="CCTV12.cn" group-title="MIX CHINESE",CCTV 12 
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
http://[2409:8087:3869:8021:1001::e5]:6610/PLTV/88888910/224/3221225637/index.m3u8
http://222.175.159.226:808/hls/13/index.m3u8 

#EXTINF:-0 tvg-id="CCTV13.cn" group-title="MIX CHINESE",CCTV 13 
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
http://[2409:8087:3869:8021:1001::e5]:6610/PLTV/88888910/224/3221225638/index.m3u8
http://222.175.159.226:808/hls/14/index.m3u8 

#EXTINF:-0 tvg-id="CCTV14.cn" group-title="MIX CHINESE",CCTV 14
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
http://[2409:8087:3869:8021:1001::e5]:6610/PLTV/88888910/224/3221225640/index.m3u8
http://222.175.159.226:808/hls/15/index.m3u8 

#EXTINF:-0 tvg-id="CCTV15.cn" group-title="MIX CHINESE",CCTV 15 
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
http://[2409:8087:3869:8021:1001::e5]:6610/PLTV/88888910/224/3221225641/index.m3u8
http://222.175.159.226:808/hls/16/index.m3u8 

#EXTINF:-0 tvg-id="CCTV16.cn" group-title="MIX CHINESE",CCTV 16
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
http://[2409:8087:3869:8021:1001::e5]:6610/PLTV/88888910/224/3221226230/index.m3u8
http://222.175.159.226:808/hls/17/index.m3u8 

#EXTINF:-0 tvg-id="CCTV17.cn" group-title="MIX CHINESE",CCTV 17 
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
http://[2409:8087:3869:8021:1001::e5]:6610/PLTV/88888910/224/3221225909/index.m3u8
http://222.175.159.226:808/hls/18/index.m3u8 





#######################################################################################################################################################################

########################





#EXTINF:-1 tvg-id="CHN" tvg-name="" group-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="SINGAPORE",SILA KLIK DAN BACA!!
https://tinyurl.com/sila-baca-la-oii

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="SINGAPORE",VISIT MY SHOP 
https://tinyurl.com/visit-kedai-saya

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="SINGAPORE",JOIN GROUP TELEGRAM 
https://tinyurl.com/Joingrouptele

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/results.php?keyid=607b7d22565c4bc3b95ff6c33ce65425&key=28cc5367df666c44be4382e64af64d57
#EXTINF:-1 group-title="SINGAPORE" tvg-id="Channel5.sg" tvg-chno="997" tvg-logo="https://static.togglestatic.com/shain/v1/dataservice/ResizeImage/$value?Format=%27png%27&Quality=85&ImageId=%27956277%27&EntityType=%27Item%27&EntityId=%2797098%27&Width=150&Height=150&ImageUrl=%27956277.png%27&device=%27web_browser%27&subscriptions=%27Anonymous%27&segmentationTags=%27all%27&ResizeAction=%27fill%27&HorizontalAlignment=%27center%27&VerticalAlignment=%27top%27",Channel 5 
https://tglmp02.akamaized.net/out/v1/5081e069e08140c9b95f89a1659cf4dd/manifest.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=2448fc561b0c4220a81f1008971d3088:f48eb6753f3d1774da682970c93cf260
#EXTINF:-1 group-title="SINGAPORE" tvg-id="Channel8.sg" tvg-chno="998" tvg-logo="https://static.togglestatic.com/shain/v1/dataservice/ResizeImage/$value?Format=%27png%27&Quality=85&ImageId=%27956273%27&EntityType=%27Item%27&EntityId=%2797104%27&Width=150&Height=150&ImageUrl=%27956273.png%27&device=%27web_browser%27&subscriptions=%27Anonymous%27&segmentationTags=%27all%27&ResizeAction=%27fill%27&HorizontalAlignment=%27center%27&VerticalAlignment=%27top%27",Channel 8
https://tglmp02.akamaized.net/out/v1/4f6561ad194b49ae93f4e1b075afdf41/manifest.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=0328a153c2994b279ab03ab25102fc59:2cc69eaaa858fed24c5623654daf8d3d
#EXTINF:-1 group-title="SINGAPORE" tvg-id="ChannelU.sg" tvg-chno="999" tvg-logo="https://static.togglestatic.com/shain/v1/dataservice/ResizeImage/$value?Format=%27png%27&Quality=85&ImageId=%272261554%27&EntityType=%27Item%27&EntityId=%2797129%27&Width=150&Height=150&ImageUrl=%272261554.png%27&device=%27web_browser%27&subscriptions=%27Anonymous%27&segmentationTags=%27all%27&ResizeAction=%27fill%27&HorizontalAlignment=%27center%27&VerticalAlignment=%27top%27",Channel U
https://tglmp03.akamaized.net/out/v1/1057d89ee3d94148b430b5866e3a540a/manifest.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=7a9ea6df52044841b0c562766e602610:b9380188b4896b25e8d419dfce938c6e
#EXTINF:-1 group-title="SINGAPORE" tvg-id="Suria.sg" tvg-chno="1000" tvg-logo="https://static.togglestatic.com/shain/v1/dataservice/ResizeImage/$value?Format=%27png%27&Quality=85&ImageId=%27956267%27&EntityType=%27Item%27&EntityId=%2797084%27&Width=150&Height=150&ImageUrl=%27956267.png%27&device=%27web_browser%27&subscriptions=%27Registered%27&segmentationTags=%27all%27&ResizeAction=%27fill%27&HorizontalAlignment=%27center%27&VerticalAlignment=%27top%27",Channel Suria
https://tglmp04.akamaized.net/out/v1/b200e885125f4787bd2329952ff28fa1/manifest.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=9970038ef6c548e39768f3a1ff6f5081:3e19d54b7bcd8bb336776fe136d48f57
#EXTINF:-1 group-title="SINGAPORE" tvg-id="Vasantham.sg" tvg-chno="1001" tvg-logo="https://static.togglestatic.com/shain/v1/dataservice/ResizeImage/$value?Format=%27png%27&Quality=85&ImageId=%27956271%27&EntityType=%27Item%27&EntityId=%2797096%27&Width=150&Height=150&ImageUrl=%27956271.png%27&device=%27web_browser%27&subscriptions=%27Registered%27&segmentationTags=%27all%27&ResizeAction=%27fill%27&HorizontalAlignment=%27center%27&VerticalAlignment=%27top%27",Channel Vasantham
https://tglmp03.akamaized.net/out/v1/14eb6e921cae41298efaa4d9db0f2875/manifest.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=612eb711dfb444f7a194c5e20d7f7048:b6226449b9ed5066542e6d6ad5ecb346
#EXTINF:-1 group-title="SINGAPORE" tvg-id="oktolidays.sg" tvg-NAME="oktolidays" tvg-logo="https://i.imgur.com/Dt0kA7e.png",Oktolidays
#https://tglmp03.akamaized.net/out/v1/be732843b7d24bada23e13810282e55f/manifest.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=60dc08aae52f4c0b806a8e43f24a12c8:30d5b579966d822b215ec51a91d8a271
#EXTINF:-1 group-title="SINGAPORE" tvg-id="1004" tvg-chno="1004" tvg-logo="https://static.togglestatic.com/shain/v1/dataservice/ResizeImage/$value?Format=%27jpg%27&Quality=85&ImageId=%273748542%27&EntityType=%27Item%27&EntityId=%27245216%27&Width=336&Height=189&ImageUrl=%273748542.jpg%27&device=%27web_browser%27&subscriptions=%27Registered%27&segmentationTags=%27_en,all%27&ResizeAction=%27fill%27&HorizontalAlignment=%27center%27&VerticalAlignment=%27top%27",Global Citizen
https://tglmp02.akamaized.net/out/v1/3170252e3fb0453085f2f4b0f8401a6b/manifest.mpd

#EXTINF:-1 group-title="SINGAPORE" tvg-id="meWATCHLIVE1.sg" tvg-chno="1006" tvg-logo="https://static.togglestatic.com/shain/v1/dataservice/ResizeImage/$value?Format='jpg'&Quality=85&ImageId='3350445'&EntityType='Item'&EntityId='229211'&Width=237&Height=237&ImageUrl='3350445.jpg'&device='web_browser'&subscriptions='Registered'&segmentationTags='_en,all'&ResizeAction='fill'&HorizontalAlignment='center'&VerticalAlignment='top'",meWATCH LIVE 1 
https://tglmp04.akamaized.net/out/v1/898b1cbac7c747e3b1f3deb460e9b67e/manifest.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=60dc08aae52f4c0b806a8e43f24a12c8:30d5b579966d822b215ec51a91d8a271
#EXTINF:-1 group-title="SINGAPORE" tvg-id="meWATCHLIVE2.sg" tvg-chno="1007" tvg-logo="https://static.togglestatic.com/shain/v1/dataservice/ResizeImage/$value?format='jpg'&Quality=85&ImageId='3350553'&EntityType='Item'&EntityId='229212'&Width=237&Height=237&ImageUrl='3350553.jpg'&device='web_browser'&subscriptions='Registered'&segmentationTags='_en,all'&ResizeAction='fill'&HorizontalAlignment='center'&VerticalAlignment='top'",meWATCH LIVE 2
https://tglmp02.akamaized.net/out/v1/3170252e3fb0453085f2f4b0f8401a6b/manifest.mpd





#######################################################################################################################################################################

##############################







#EXTINF:-1 tvg-id="CHN" tvg-name="" group-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="KOREA",SILA KLIK DAN BACA!!
https://tinyurl.com/sila-baca-la-oii

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="KOREA",VISIT MY SHOP 
https://tinyurl.com/visit-kedai-saya

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="KOREA",JOIN GROUP TELEGRAM 
https://tinyurl.com/Joingrouptele


#EXTINF:-1 tvg-id="tvNMoviesAsia.hk" ch-number="416" group-title="KOREA" tvg-logo="http://playtv.unifi.com.my:7039/CPS/images/universal/film/logo/201907/20190723/20190723084311221wnu.png",tvN Movies (MY)   
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2406
http://linearjitp-playback.astro.com.my/dash-wv/linear/2406/default_ott.mpd

#EXTINF:-1 tvg-id="tvNMoviesAsia.hk" tvg-name="tvN Movies HD" group-title="KOREA" tvg-logo="http://playtv.unifi.com.my:7039/CPS/images/universal/film/logo/201907/20190723/20190723084311221wnu.png",tvN Movies (ID)
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=ZGFkZmZkZjItYzQ1Mi0zM2RiLTk0OWQtM2M2YmY1YzZjMDNi
#EXTVLCOPT:http-referrer=http://www.astro.com.my
https://av-live-cdn.mncnow.id/live/eds/tvNMovies/sa_dash_vmx/tvNMovies.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/1001
#EXTINF:-1 tvg-id="tvNAsia.hk" ch-number="tvN" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/190_144.png" group-title="KOREA",tvN (MY)
https://linearjitp-playback.astro.com.my/dash-wv/linear/1001/default_ott.mpd

#EXTINF:-1 tvg-id="tvNAsia.h" tvg-name="tvN HD" group-title="KOREA" tvg-logo="http://playtv.unifi.com.my:7039/CPS/images/universal/film/logo/201907/20190716/20190716065439314yz3.png",tvN (ID)
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=ZGFkZmZkZjItYzQ1Mi0zM2RiLTk0OWQtM2M2YmY1YzZjMDNi
#EXTVLCOPT:http-referrer=http://www.astro.com.my
https://av-live-cdn.mncnow.id/live/eds/tvN/sa_dash_vmx/tvN.mpd
https://akamai.mncnow.id/live/eds/tvN/sa_dash_vmx/tvN.mpd

#EXTINF:-1 tvg-id="ArirangWorld.kr" group-title="KOREA" tvg-logo="https://poster.starhubgo.com/Linear_channels2/817_1920x1080_HTV.png",Arirang TV
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=ZGFkZmZkZjItYzQ1Mi0zM2RiLTk0OWQtM2M2YmY1YzZjMDNi
#https://anevia114.mncnow.id/live/eds/Arirang/sa_dash_vmx/Arirang.mpd
http://amdlive-ch01.ctnd.com.edgesuite.net/arirang_1ch/smil:arirang_1ch.smil/playlist.m3u8

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/9983
#EXTINF:-1 tvg-id="KPlus.sg" tvg-logo="http://linear-poster.astro.com.my/prod/logo/K-Plus_v1.png" group-title="KOREA",K Plus
http://linearjitp-playback.astro.com.my/dash-wv/linear/9983/default_ott.mpd

#EXTINF:-1 tvg-id="KBSWorld" tvg-name="KBS World HD" group-title="🇰KOREA" tvg-logo="https://i.ibb.co/1M1Y4L5/resize.png",KBS World
#https://livecdn.fptplay.net/sdb/kbs_hls.smil/chunklist_b2500000.m3u8

#EXTINF:-1 tvg-id="OppaMania" group-title="KOREA" ch-number="100" tvg-logo="https://linear-poster.astro.com.my/prod/logo/OppaMania_V1.png",OPPA Mania
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5078
https://linearjitp-playback.astro.com.my/dash-wv/linear/5078/default_ott.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2702
#EXTINF:-1 tvg-id="OneTVAsia.sg" ch-number="ONE" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/133_144.png" group-title="KOREA",ONE (MY) 
https://linearjitp-playback.astro.com.my/dash-wv/linear/2702/default_primary.mpd

#EXTINF:-1 tvg-id="OneTVAsia.sg" tvg-name="ONE HD" group-title="KOREA" tvg-logo="https://www.onetvasia.com/sites/onetvasia.com/files/logos/onetvasia-logo.png",ONE (ID)
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MzRjOGRhNmItM2ZmNi0zMGIwLWI1NTEtM2ViNjlhZmM2NWU0
#EXTVLCOPT:http-referrer=http://www.astro.com.my
https://av-live-cdn.mncnow.id/live/eds/SetOne/sa_dash_vmx/SetOne.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/1002
#EXTINF:-1 tvg-id="394" tvg-logo="http://linear-poster.astro.com.my/prod/logo/OhK_v1.png" group-title="KOREA",OH!K 
# https://linearjitp-playback.astro.com.my/dash-wv/linear/1002/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=0403e654ddab419db6cc72bb3fa51248:9d43bcc51f3750550d321cdc37e57cc9
#EXTINF:-1 tvg-id="GEM.sg" tvg-name="GEM" tvg-logo="https://www.lyngsat.com/logo/tv/gg/gem-in.png" group-title="KOREA",GEM
https://tglmp01.akamaized.net/out/v1/acd34a6d1e2540f888793461457b77e1/manifest.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2306
#EXTINF:-1 tvg-id="KBSWorld.kr" tvg-name="KBS World HD" tvg-logo="http://linear-poster.astro.com.my/prod/logo/KBSW_v1.png" group-title="KOREA",KBS World
http://linearjitp-playback.astro.com.my/dash-wv/linear/2306/default.mpd

#EXTINF:-1 tvg-id="CHN" group-title="KOREA" tvg-name="New TV KMovies" tvg-logo="http://linear-poster.astro.com.my/prod/logo/KBSW_v1.png",New TV KMovies
#KODIPROP:inputstream=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=hls
https://tinyurl.com/TiviMe-NewKMovies

#EXTINF:-1 tvg-id="KBS1TV.kr" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/d/d5/KBS_1_logo.svg/512px-KBS_1_logo.svg.png" group-title="KOREA",KBS1 
http://ye23.vip/z7z8/2021/kbs2020.php?id=1

#EXTINF:-1 tvg-id="KBS2TV.kr" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/2/26/KBS_2_logo.svg/512px-KBS_2_logo.svg.png" group-title="KOREA",KBS2 
http://ye23.vip/z7z8/2021/kbs2020.php?id=2

#EXTINF:-1 tvg-id="KBSDrama.kr" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/f/f2/KBS_DRAMA.svg/512px-KBS_DRAMA.svg.png" group-title="KOREA",KBS Drama 
http://ye23.vip/z7z8/2021/kbs2020.php?id=5

#EXTINF:-1 tvg-id="KBSJoy.kr" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/6/6b/KBS_JOY.svg/512px-KBS_JOY.svg.png" group-title="KOREA",KBS Joy 
http://ye23.vip/z7z8/2021/kbs2020.php?id=6

#EXTINF:-1 tvg-id="KBSKids.kr" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/KBS_kids.svg/512px-KBS_kids.svg.png" group-title="KOREA",KBS Kids 
http://ye23.vip/z7z8/2021/kbs2020.php?id=9

#EXTINF:-1 tvg-id="KBSKorea.kr" tvg-logo="https://i.imgur.com/Dy1xwEd.png" group-title="KOREA",KBS Korea 
http://free.fullspeed.tv/iptv-query?streaming-ip=https://www.youtube.com/c/kbsworldtv/live

#EXTINF:-1 tvg-id="KBSLife.kr" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/6/64/KBS_Life.svg/512px-KBS_Life.svg.png" group-title="KOREA",KBS Life 
http://ye23.vip/z7z8/2021/kbs2020.php?id=7

#EXTINF:-1 tvg-id="KBSLiveCamDokDo.kr" tvg-logo="https://i.imgur.com/b7uMB9T.png" group-title="KOREA",KBS LiveCam DokDo 
http://kbs-dokdo.gscdn.com/dokdo_300/dokdo_300.stream/playlist.m3u8

#EXTINF:-1 tvg-id="KBSNewsD.kr" tvg-logo="https://i.imgur.com/4qKgvHN.png" group-title="KOREA",KBS News D 
http://ye23.vip/z7z8/2021/kbs2020.php?id=4

#EXTINF:-1 tvg-id="KBSStory.kr" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7e/KBS_Story.svg/512px-KBS_Story.svg.png" group-title="KOREA",KBS Story 
http://ye23.vip/z7z8/2021/kbs2020.php?id=8

#EXTINF:-1 channel-id="plex-5e20b730f2f8d5003d739db7-5eea605474085f0040ddc767" tvg-id="5e20b730f2f8d5003d739db7-5eea605474085f0040ddc767" tvg-logo="https://provider-static.plex.tv/epg/images/ott_channels/logos/ac_samsung.png" group-title="KOREA",AsianCrush PLEX
https://dc447fbd44e44d33b66b90c1eaaefec1.mediatailor.us-east-1.amazonaws.com/v1/master/44f73ba4d03e9607dcd9bebdcb8494d86964f1d8/Plex_AsianCrush/playlist.m3u8?ads.wurl_channel=269&ads.wurl_name=AsianCrush&ads.us_privacy=1---&ads.psid=62274240-07e7-5d94-8dc8-ef68cf19e175&ads.targetopt=0&ads.plex_token=Rs19sdFRTfJdn9Wyxa4f&ads.plex_id=5eea605474085f0040ddc767&ads.ua=okhttp%2F4.9.0&ads.app_bundle=com.plexapp.android&ads.app_store_url=https%3A%2F%2Fplay.google.com%2Fstore%2Fapps%2Fdetails%3Fid%3Dcom.plexapp.android&ads.gdpr=0&ads.consent=0&ads.device_type=handset&ads.device_id_type=

#EXTINF:-1 channel-id="plex-5e20b730f2f8d5003d739db7-60d4edd8b2fdec002c14112f" tvg-id="5e20b730f2f8d5003d739db7-60d4edd8b2fdec002c14112f" tvg-logo="https://provider-static.plex.tv/epg/images/ott_channels/logos/rakutenviki_logo_dark.png" group-title="KOREA",Rakuten Viki PLEX
https://dce1408e0efa4bc4b6ca1366c56911fb.mediatailor.us-east-1.amazonaws.com/v1/master/04fd913bb278d8775298c26fdca9d9841f37601f/Plex_RakutenViki/playlist.m3u8?ads.wurl_channel=843&ads.wurl_name=RakutenViki&ads.coppa=0&ads.us_privacy=1---&ads.psid=62274240-07e7-5d94-8dc8-ef68cf19e175&ads.targetopt=0&ads.plex_token=p6Ph7ybs-ExykQE-Zz78&ads.plex_id=60d4edd8b2fdec002c14112f&ads.ua=okhttp%2F4.9.0&ads.app_bundle=com.plexapp.android&ads.app_store_url=https%3A%2F%2Fplay.google.com%2Fstore%2Fapps%2Fdetails%3Fid%3Dcom.plexapp.android&ads.gdpr=0&ads.consent=0&ads.device_type=handset&ads.device_id_type=

#EXTINF:-1 channel-id="plex-5e20b730f2f8d5003d739db7-60d4eddab2fdec002c141131" tvg-id="5e20b730f2f8d5003d739db7-60d4eddab2fdec002c141131" tvg-logo="https://provider-static.plex.tv/epg/images/ott_channels/logos/newkmovies_logo_dark_v2.png" group-title="KOREA",New K Movies
https://7732c5436342497882363a8cd14ceff4.mediatailor.us-east-1.amazonaws.com/v1/master/04fd913bb278d8775298c26fdca9d9841f37601f/Plex_NewMovies/playlist.m3u8?ads.wurl_channel=618&ads.wurl_name=NewMovies&ads.coppa=0&ads.us_privacy=1---&ads.psid=62274240-07e7-5d94-8dc8-ef68cf19e175&ads.targetopt=0&ads.plex_token=p6Ph7ybs-ExykQE-Zz78&ads.plex_id=60d4eddab2fdec002c141131&ads.ua=okhttp%2F4.9.0&ads.app_bundle=com.plexapp.android&ads.app_store_url=https%3A%2F%2Fplay.google.com%2Fstore%2Fapps%2Fdetails%3Fid%3Dcom.plexapp.android&ads.gdpr=0&ads.consent=0&ads.device_type=handset&ads.device_id_type=

#EXTINF:-1 channel-id="plex-5e20b730f2f8d5003d739db7-60d4edd7b2fdec002c14112d" tvg-id="5e20b730f2f8d5003d739db7-60d4edd7b2fdec002c14112d" tvg-logo="https://provider-static.plex.tv/epg/images/ott_channels/logos/newkpop_logo_dark_v2.png" group-title="KOREA",New kpop Plex
https://2d2cb770b80a4e19bded6a526e1e9c9f.mediatailor.us-east-1.amazonaws.com/v1/master/04fd913bb278d8775298c26fdca9d9841f37601f/Plex_NewKID/playlist.m3u8?ads.wurl_channel=698&ads.wurl_name=NewKID&ads.coppa=0&ads.us_privacy=1---&ads.psid=62274240-07e7-5d94-8dc8-ef68cf19e175&ads.targetopt=0&ads.plex_token=Rs19sdFRTfJdn9Wyxa4f&ads.plex_id=60d4edd7b2fdec002c14112d&ads.ua=okhttp%2F4.9.0&ads.app_bundle=com.plexapp.android&ads.app_store_url=https%3A%2F%2Fplay.google.com%2Fstore%2Fapps%2Fdetails%3Fid

#EXTINF:-1 channel-id="samsung-USBB2900001P9" tvg-id="USBB2900001P9" tvg-chno="1290" tvg-logo="https://tvpmlogopus.samsungcloud.tv/platform/image/sourcelogo/vc/70/02/20/USBB2900001P9_20210824T091331.png" group-title="KOREA",Cj 
https://d50a1g0nh14ou.cloudfront.net/v1/master/3722c60a815c199d9c0ef36c5b73da68a62b09d1/CJ-ENM-prod/e91c6419_2e45_4f6c_a646_b912658d73b8/hls/playlist.m3u8?ads.device_did=%7BPSID%7D&ads.device_dnt=%7BTARGETOPT%7D&ads.us_privacy=1YNY&ads.app_domain=%7BAPP_DOMAIN%7D&ads.app_name=%7BAPP_NAME%7D

#EXTINF:-1 channel-id="samsung-USAJ30000122O" tvg-id="USAJ30000122O" tvg-chno="1295" tvg-logo="https://tvpmlogopus.samsungcloud.tv/platform/image/sourcelogo/vc/70/02/05/USAJ30000122O_20210909T003510.png" group-title="KOREA",New K movies
https://bd281c27a16f4a7fb4a88260378e8082.mediatailor.us-east-1.amazonaws.com/v1/master/44f73ba4d03e9607dcd9bebdcb8494d86964f1d8/Samsung_NewMovies/playlist.m3u8?ads.wurl_channel=618&ads.wurl_name=NewMovies&ads.us_privacy=1YNY&ads.psid=%7BPSID%7D&ads.targetopt=%7BTARGETOPT%7D&ads.app_domain=%7BAPP_DOMAIN%7D&ads.app_name=%7BAPP_NAME%7D&ads.coppa=0

#EXTINF:-1 channel-id="samsung-USAJ3000013FJ" tvg-id="USAJ3000013FJ" tvg-chno="1296" tvg-logo="https://tvpmlogopus.samsungcloud.tv/platform/image/sourcelogo/vc/70/01/40/USAJ3000013FJ_20210909T003532.png" group-title="KOREA",New Kpop
https://8fd4e0b07d96480eb52382739cc8acce.mediatailor.us-east-1.amazonaws.com/v1/master/44f73ba4d03e9607dcd9bebdcb8494d86964f1d8/Samsung_NewKID/playlist.m3u8?ads.wurl_channel=617&ads.wurl_name=NewKID&ads.us_privacy=1YNY&ads.psid=%7BPSID%7D&ads.targetopt=%7BTARGETOPT%7D&ads.app_domain=%7BAPP_DOMAIN%7D&ads.app_name=%7BAPP_NAME%7D&ads.coppa=0

#EXTINF:-1 channel-id="plex-5e20b730f2f8d5003d739db7-60d4ede2b2fdec002c14113b" tvg-id="5e20b730f2f8d5003d739db7-60d4ede2b2fdec002c14113b" tvg-logo="https://provider-static.plex.tv/epg/images/ott_channels/logos/ygtv_logo_dark.png" group-title="KOREA",Yg tv Plex
https://4e7d4e92cd344185b927ab5c730550dd.mediatailor.us-east-1.amazonaws.com/v1/master/04fd913bb278d8775298c26fdca9d9841f37601f/Plex_YGTV/playlist.m3u8?ads.wurl_channel=900&ads.wurl_name=YGTV&ads.coppa=0&ads.us_privacy=1---&ads.psid=62274240-07e7-5d94-8dc8-ef68cf19e175&ads.targetopt=0&ads.plex_token=Rs19sdFRTfJdn9Wyxa4f&ads.plex_id=60d4ede2b2fdec002c14113b&ads.ua=okhttp%2F4.9.0&ads.app_bundle=com.plexapp.android&ads.app_store_url=https%3A%2F%2Fplay.google.com%2Fstore%2Fapps%2Fdetails%3Fid%3Dcom.plexapp.android&ads.gdpr=0&ads.consent=0&ads.device_type=handset&ads.device_id_type=

#EXTINF:-1 channel-id="plex-5e20b730f2f8d5003d739db7-5ef4e1b40d9ad000423c4424" tvg-id="5e20b730f2f8d5003d739db7-5ef4e1b40d9ad000423c4424" tvg-logo="https://provider-static.plex.tv/epg/images/ott_channels/logos/kmtvnow_samsung.png" group-title="KOREA",Km tv Plex
https://fc411f09ac2840368cad3ceb953e0bc9.mediatailor.us-east-1.amazonaws.com/v1/master/44f73ba4d03e9607dcd9bebdcb8494d86964f1d8/Plex_KMTV/playlist.m3u8?ads.wurl_channel=265&ads.wurl_name=KMTV&ads.us_privacy=1---&ads.psid=62274240-07e7-5d94-8dc8-ef68cf19e175&ads.targetopt=0&ads.plex_token=Rs19sdFRTfJdn9Wyxa4f&ads.plex_id=5ef4e1b40d9ad000423c4424&ads.ua=okhttp%2F4.9.0&ads.app_bundle=com.plexapp.android&ads.app_store_url=https%3A%2F%2Fplay.google.com%2Fstore%2Fapps%2Fdetails%3Fid%3Dcom.plexapp.android&ads.gdpr=0&ads.consent=0&ads.device_type=handset&ads.device_id_type=

#EXTINF:0 tvg-id="SBSTV.kr" tvg-name="SBS" tvg-logo="https://i.imgur.com/BzqSUVF.png" group-title="KOREA",SBS
https://newidco-sbs-1-eu.xiaomi.wurl.tv/playlist.m3u8

#EXTINF:0 tvg-id="TJBTV.kr" tvg-name="SBS funE" tvg-logo="https://i.imgur.com/n2JajGK.png" group-title="KOREA",SBS Tjb
http://1.245.74.5:1935/live/tv/.m3u8  

#EXTINF:0 tvg-id="UBCTV.kr" tvg-name="SBS Plus" tvg-logo="https://i.imgur.com/tzTx3Ta.png" group-title="KOREA",SBS Ubc
http://59.23.231.102:1935/live/UBCstream/playlist.m3u8

#EXTINF:-1 tvg-id="EBS1TV.kr" group-title="KOREA" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e2/EBS_1TV_Logo.svg/1200px-EBS_1TV_Logo.svg.png", EBS 1
http://ebsonair.ebs.co.kr/ebs1familypc/familypc1m/playlist.m3u8

#EXTINF:-1 tvg-id="EBS2TV.kr" group-title="KOREA" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/6/6b/EBS_2_logo.svg/2560px-EBS_2_logo.svg.png", EBS 2
http://ebsonair.ebs.co.kr/ebs2familypc/familypc1m/playlist.m3u8

#EXTINF:-1 tvg-id="EBSKids.kr" group-title="KOREA" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/3/3d/EBS_KIDS.svg/800px-EBS_KIDS.svg.png", EBS Kids
http://ebsonair.ebs.co.kr/ebsufamilypc/familypc1m/playlist.m3u8

#EXTINF:-1 tvg-id="EBSPlus1.kr" group-title="KOREA" tvg-logo="https://global.ebs.co.kr/global/img/sub/Channels_IPTV_01.png", EBS Plus 1
http://ebsonair.ebs.co.kr/plus1familypc/familypc1m/playlist.m3u8

#EXTINF:-1 tvg-id="EBSPlus2.kr" group-title="KOREA" tvg-logo="https://global.ebs.co.kr/global/img/sub/Channels_IPTV_02.png", EBS Plus 2
http://ebsonair.ebs.co.kr/plus2familypc/familypc1m/playlist.m3u8

#EXTINF:-1 tvg-id="EBSEnglish.kr" group-title="KOREA" tvg-logo="https://obj-kr.thewiki.kr/data/4542535f456e676c6973682e706e67.png", EBS E
http://ebsonair.ebs.co.kr/plus3familypc/familypc1m/playlist.m3u8

#EXTINF:-1 tvg-id="Mnet.kr" group-title="KOREA" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/9/95/Mnet.png", MNet
http://mytv.dothome.co.kr/ch/catv/224.php

#EXTINF:-1 tvg-id="JTBC.kr" group-title="KOREA" tvg-logo="https://6.vikiplatform.com/image/dd32095cfb9e46ab8358b31792e1e8f9.png?x=b&s=843x474&q=h&cb=1", JTBC
http://mytv.dothome.co.kr/ch/catv/211.php

#EXTINF:0 tvg-id="MBCTV.kr" tvg-name="MBC" tvg-logo="https://i.imgur.com/r9gNY5R.png" group-title="KOREA",MBC
http://123.254.72.24:1935/tvlive/livestream2/playlist.m3u8




#######################################################################################################################################################################

#############################




#EXTINF:-1 tvg-id="CHN" tvg-name="" group-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="THAILAND",SILA KLIK DAN BACA!!
https://tinyurl.com/sila-baca-la-oii

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="THAILAND",VISIT MY SHOP 
https://tinyurl.com/visit-kedai-saya

#EXTINF:-1 tvg-id="Channel3.th" group-title="THAILAND" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/d/d3/Ch3HDLogo.png", CH3 HD
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/202205171929/ch3hd/index.m3u8

#EXTINF:-1 tvg-id="ThaiTV5HD1.th" group-title="THAILAND" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/7/7e/TATV5_Logo_HD.png", CH5 HD
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/202205171929/ch5hd/index.m3u8

#EXTINF:-1 tvg-id="ThaiTV5HD1.th" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/e/eb/%E0%B9%82%E0%B8%A5%E0%B9%82%E0%B8%81%E0%B9%89%E0%B8%8A%E0%B9%88%E0%B8%AD%E0%B8%875.png" group-title="THAILAND", CH5 SD
https://tc-live1.sanook.com/live/22302_ch5.m3u8

#EXTINF:-1 tvg-id="BBTVChannel7.th" group-title="THAILAND" tvg-logo="https://upload.wikimedia.org/wikipedia/en/f/f3/BBTV_Channel_7.png", CH7 HD
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/202205171929/ch7hd/index.m3u8

#EXTINF:-1 tvg-id="Channel8.th" group-title="THAILAND" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/2/20/Ch_8_2016.svg/1200px-Ch_8_2016.svg.png", CH8
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/202205171929/ch8/index.m3u8

#EXTINF:-1 tvg-id="NBT2HD.th" group-title="THAILAND" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/f/fb/NBT_2009.png", NBT
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/202205171929/chnbt3/index.m3u8

#EXTINF:-1 tvg-id="ThaiPBS3.th" group-title="THAILAND" tvg-logo="https://upload.wikimedia.org/wikipedia/vi/5/5a/Thai_PBS_logo.png", Thai PBS
https://thaipbs-live.cdn.byteark.com/live/playlist_1080p/index.m3u8
http://thaipbs-live.cdn.byteark.com/live/playlist_720p/index.m3u8
https://cdn6.goprimetime.info/feed/202205171929/chthaipbs3/index.m3u8

#EXTINF:-1 tvg-id="PPTVHD36.th" group-title="THAILAND" tvg-logo="https://play-lh.googleusercontent.com/clhMtBU3QtreaoCWrETPNIAVjbrlgzsSzOLaspaZ2kmd_cKCgIkSggz07lBsmaGLIka0", PPTV HD
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/202205171929/chpptvhd3/index.m3u8

#EXTINF:-1 tvg-id="MCOTHD.th" group-title="THAILAND" tvg-logo="https://upload.wikimedia.org/wikipedia/vi/3/30/Logo_kenh_9_mcot_thai_lan.png", MCOT HD
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/202205171929/chmcothd/index.m3u8

#EXTINF:-1 tvg-id="MCOTHD.th" tvg-logo="https://seeklogo.com/images/M/mcot-hd-logo-D6F286C4DD-seeklogo.com.png" group-title="THAILAND", MCOT SD
https://tc-live1.sanook.com/live/22302_ch9.m3u8

#EXTINF:-1 tvg-id="One31.th" group-title="THAILAND" tvg-logo="https://upload.wikimedia.org/wikipedia/en/a/a8/One_31_Logo.png", ONE31
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/202205171929/chonehd/index.m3u8

#EXTINF:-1 tvg-id="ThairathTV32.th" group-title="THAILAND" tvg-logo="https://upload.wikimedia.org/wikipedia/en/thumb/5/50/Thairath_TV_Logo.svg/1200px-Thairath_TV_Logo.svg.png", Thairath TV HD
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/202205171929/chthairath/index.m3u8

#EXTINF:-1 tvg-id="GMM25.th" group-title="THAILAND" tvg-logo="https://upload.wikimedia.org/wikipedia/vi/5/52/GMM_25_Logo_dai_truyen_hinh.png", GMM25
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/202205171929/chgmm3/index.m3u8

#EXTINF:-1 tvg-id="Mono29.th" group-title="THAILAND" tvg-logo="https://cms.dmpcdn.com/livetv/2019/01/10/35a35017-8473-4953-8474-5c58d805b74a.png", MONO29
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/202205171929/chmono29/index.m3u8

#EXTINF:-1 tvg-id="NewsTV.th" group-title="THAILAND" tvg-logo="https://i.imgur.com/uKEFgGh.png", News TV
#https://freelive.inwstream.com:1936/freelive-edge/newstv/playlist.m3u8

#EXTINF:-1 tvg-id="NationTV.th" group-title="THAILAND" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/9/94/Nationtv.png", Nation TV
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/202205171929/chnation/index.m3u8

#EXTINF:-1 tvg-id="Workpoint23.th" group-title="THAILAND" tvg-logo="https://www.workpointtv.com/wp-content/themes/wptv/assets/logo-wp-white.png", Workpoint TV
#https://freelive.inwstream.com:1936/freelive-edge/workpointtv/playlist.m3u8

#EXTINF:-1 tvg-id="True4U.th" group-title="THAILAND" tvg-logo="https://cms.dmpcdn.com/livetv/2019/03/15/58ad8ef6-52ef-4609-a55b-9a18e8e89eec.png", True 4U
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/202205171929/chtrue4u3/index.m3u8

#EXTINF:-1 tvg-id="TrueFilm1.th" tvg-logo="https://i.ibb.co/QJ6HDbM/26308f80-7374-11ec-91d2-797a50c5a656-webp-original.png" group-title="THAILAND",True Film 1
https://iptv-thai.herokuapp.com/tv.php?channel=115667

#EXTINF:-1 tvg-id="TrueFilm2.th" tvg-logo="https://i.ibb.co/jfQGHLJ/26725370-7374-11ec-91d2-797a50c5a656-webp-original.png" group-title="THAILAND",True Film 2
https://iptv-thai.herokuapp.com/tv.php?channel=115415

#EXTINF:-1 tvg-id="TrueFilmAsia.th" tvg-logo="https://i.ibb.co/TvQWvGt/26c50750-7374-11ec-b576-afbb0a1303ef-webp-original.png" group-title="THAILAND",True Film Asia
https://iptv-thai.herokuapp.com/tv.php?channel=115665

#EXTINF:-1 tvg-id="TrueMovieHits.th" tvg-logo="https://i.ibb.co/r20pGtm/275f4b80-7374-11ec-91d2-797a50c5a656-webp-original.png" group-title="THAILAND",True Movie Hits
https://iptv-thai.herokuapp.com/tv.php?channel=115729

#EXTINF:-1 tvg-id="Amarin34HD.th" group-title="THAILAND" tvg-logo="https://www.amarintv.com/assets/images/logo.png", Amarin TV
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/202205171929/chamarin/index.m3u8

EXTINF:-1 tvg-id="ALTV.th" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/ALTV_Logo.png/150px-ALTV_Logo.png" group-title="THAILAND",Altv 4 HD
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/202205171929/ALTV/index.m3u8

#EXTINF:-1 tvg-id="ALTV.th" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a9/ALTV_Logo.png/150px-ALTV_Logo.png" group-title="THAILAND", Altv 4 SD
https://thaipbs-ujxrch.cdn.byteark.com/live/playlist_720p/index.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://seeklogo.com/images/A/AND-logo-B08B08AEAC-seeklogo.com.gif" group-title="THAILAND",And TV
https://live.thaitvstream.com/play/andtv/index.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://pbs.twimg.com/profile_images/616532058718892032/SmjrJwro_400x400.jpg" group-title="THAILAND", Attv
http://49.0.87.24:1936/HDAttv/Attv/playlist.m3u8

#EXTINF:-1 tvg-id="BBTVChannel7.th" tvg-logo="https://e7.pngegg.com/pngimages/557/835/png-clipart-thailand-channel-7-royal-thai-army-radio-and-television-channel-5-7-miscellaneous-television-thumbnail.png" group-title="THAILAND", Bbtv Channel 7
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/202205171929/ch7hd/index.m3u8
#https://freelive2.inwstream.com:1936/freelive-edge/7hd/chunks.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://f.ptcdn.info/601/063/000/pqcvhsxk7PuKUZbFKv4-o.png" group-title="THAILAND", CTB
http://vip.login.in.th:1935/CTB/CTB/playlist.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://sv1.picz.in.th/images/2021/11/12/ueNbxy.jpg" group-title="THAILAND",FW Movie
#https://freelive.inwstream.com:1936/freelive-edge/fwmov_fw-iptv.stream/chunks.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.imgur.com/bYGohUG.png" group-title="THAILAND", FWsov Movie
#https://freelive.inwstream.com:1936/freelive-edge/fwsov_fw-iptv.stream/chunks.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/5/5c/Jkn18.png" group-title="THAILAND", Jkn 18
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/202205171929/newtv/index.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://seeklogo.com/images/M/media-news-logo-D515219F35-seeklogo.com.gif" group-title="THAILAND", Media new TV
https://live1.thaitvstream.com/play/medianews/index.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://thaitvstream.com/streaming/mounchontv/mounchontv.png" group-title="THAILAND", Mounchon
https://live2.thaitvstream.com/play/mounchontv/index.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://pbs.twimg.com/profile_images/907335088517599232/AxsFAPe-.jpg" group-title="THAILAND", Nk TV
#http://ch.fbth.xyz:5050/live/nktv/playlist.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/9/9d/Petchabun_FC_2011.png" group-title="THAILAND", Phetchabun Movie
https://live1.thaitvstream.com/play/phetchabuntv/index.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i0.wp.com/www.siamnewsnetwork.net/wp-content/uploads/2018/05/siamnews-bw-helv-square.png" group-title="THAILAND", Siam News
https://live1.thaitvstream.com/play/siamnewstv/index.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://iphone-image.apkpure.com/v2/app/e/a/a/eaa2d0ef926bb1c9ef2bc6e327a34db6.jpg" group-title="THAILAND", Srtv Online
https://live1.thaitvstream.com/play/srtvonline/index.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/1/18/TNA_logo.svg/1200px-TNA_logo.svg.png" group-title="THAILAND", Thai News
https://live.thaitvstream.com/play/thainews/index.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/3/3a/Tnn162020.jpg" group-title="THAILAND", Tnn 16
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/202205171929/chtnn/index.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/3/3a/Tnn162020.jpg" group-title="THAILAND", Tnn 16
#http://freelive.inwstream.com:1935/freelive-edge/tnn24/chunks.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.pinimg.com/736x/1a/ee/fd/1aeefd2da3dae54a178aa016d3d3ad42.jpg" group-title="THAILAND", Top News
https://live.topnews.co.th/hls/topnews_720.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://photos.live-tv-channels.org/tv-logo/white-channel-9194.webp" group-title="THAILAND", White Channel 28
http://symc-cdn.violin.co.th:1935/tndedge/whitechannel/chunklist.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/8/8e/Workpoint-logo.png/revision/latest/scale-to-width-down/2000?cb=20170508090614" group-title="THAILAND", Workpoint 23
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36
https://cdn6.goprimetime.info/feed/202205171929/chworkpoint/index.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://photos.live-tv-channels.org/tv-logo/th-zabb-channel-1948.jpg" group-title="THAILAND", Zabb Channel
https://live1.thaitvstream.com/play/zabbtv/index.m3u8

#EXTINF:-1 tvg-id="beINSports1Thailand.th" tvg-logo="https://i.imgur.com/MRULdc8.png" group-title="THAILAND",beIN Sports 1 Thailand
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3
https://sport.livedoomovies.com:4431/02_epl1_720p/chunklist.m3u8|Referer=https://www.movie87hd.com/?r=ajax

#EXTINF:-1 tvg-id="beINSports3Thailand.th" tvg-logo="https://i.imgur.com/j8VC6nB.png" group-title="THAILAND",beIN Sports 3 Thailand
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3
https://sport.livedoomovies.com:4431/02_epl2_720p/chunklist.m3u8|Referer=https://www.movie87hd.com/?r=ajax



#######################################################################################################################################################################

#############################






#EXTINF:-1 tvg-id="CHN" tvg-name="" group-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="ENTERTAINMENT",SILA KLIK DAN BACA!!
https://tinyurl.com/sila-baca-la-oii

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="ENTERTAINMENT",VISIT MY SHOP 
https://tinyurl.com/visit-kedai-saya

#EXTINF:-1 tvg-id="FoodNetworkAsia.sg" group-title="ENTERTAINMENT" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/153_144.png" ch-number="708",Food Network 
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2300
http://linearjitp-playback.astro.com.my/dash-wv/linear/2300/default_ott.mpd

#EXTINF:-1 tvg-id="AsianFoodNetwork.sg" group-title="ENTERTAINMENT" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/91_144.png" ch-number="709",Asian Food Network (MY)
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/500
http://linearjitp-playback.astro.com.my/dash-wv/linear/500/default_ott.mpd

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTINF:-1 tvg-id="AsianFoodNetwork.sg" tvg-logo="http://linear-poster.astro.com.my/prod/logo/afn_v1.png" group-title="ENTERTAINMENT",Asian Food Network (ID)
https://av-live-cdn.mncnow.id/live/eds/AFN-HD/sa_dash_vmx/AFN-HD.mpd

#EXTINF:-1 tvg-id="LifetimeAsia.us" ch-number="703" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/447_144.png" group-title="ENTERTAINMENT",Lifetime (MY)
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5052
http://linearjitp-playback.astro.com.my/dash-wv/linear/5052/default_ott.mpd

#EXTINF:-1 tvg-id="LifetimeAsia.us" group-title="ENTERTAINMENT" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9c/Logo_Lifetime_2020.svg/800px-Logo_Lifetime_2020.svg.png",Lifetime (ID)
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
https://av-live-cdn.mncnow.id/live/eds/Lifetime/sa_dash_vmx/Lifetime.mpd

#EXTINF:-1 tvg-id="DMAXSoutheastAsia.sg" group-title="ENTERTAINMENT" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/2/25/DMAX_Logo_16_05_2011.jpg" ch-number="716",Dmax
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2610
https://linearjitp-playback.astro.com.my/dash-wv/linear/2610/default_primary.mpd

#EXTINF:-1 tvg-id="HGTVAsia.us" ch-number="HGTV" group-title="ENTERTAINMENT" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/HGTV_US_Logo_2015.svg/1200px-HGTV_US_Logo_2015.svg.png" ch-number="715",HGTV (MY)
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2502
https://linearjitp-playback.astro.com.my/dash-wv/linear/2502/default_primary.mpd

#EXTINF:-1 tvg-id="HGTVAsia.us" group-title="ENTERTAINMENT" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/HGTV_US_Logo_2015.svg/1200px-HGTV_US_Logo_2015.svg.png",HGTV (ID)
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MzRjOGRhNmItM2ZmNi0zMGIwLWI1NTEtM2ViNjlhZmM2NWU0
#EXTVLCOPT:http-referrer=http://www.astro.com.my
https://av-live-cdn.mncnow.id/live/eds/HGTV/sa_dash_vmx/HGTV.mpd

#EXTINF:-1 tvg-id="TLCSoutheastAsia.sg" group-title="ENTERTAINMENT" tvg-logo="https://api.discovery.com/v1/images/558c1c396b66d1023309e791?aspectRatio=1x1&width=192&key=3020a40c2356a645b4b4" ch-number="707",TLC (MY)
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2709
http://linearjitp-playback.astro.com.my/dash-wv/linear/2709/default_primary.mpd

#EXTINF:-1 tvg-id="TLCSoutheastAsia.sg" group-title="ENTERTAINMENT" tvg-logo="https://api.discovery.com/v1/images/558c1c396b66d1023309e791?aspectRatio=1x1&width=192&key=3020a40c2356a645b4b4",TLC (ID)
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MzRjOGRhNmItM2ZmNi0zMGIwLWI1NTEtM2ViNjlhZmM2NWU0
#EXTVLCOPT:http-referrer=http://www.astro.com.my
https://av-live-cdn.mncnow.id/live/eds/TLC/sa_dash_vmx/TLC.mpd

#EXTINF:-1 tvg-id="blueantent" group-title="ENTERTAINMENT" tvg-logo="https://i.ibb.co/5kmtnvJ/Rock-Entertainment.png", Rock Entertainment
#EXTVLCOPT:http-user-agent=Lavf/56.15.102
# http://210.210.155.35:80/dr9445/h/h15/02.m3u8
http://210.210.155.37/session/eb840bf4-25f3-11ed-9af7-9a7dadef5b77/dr9445/h/h16/01.m3u8

#EXTINF:-1 tvg-id="FishingTV.us" tvg-logo="https://i.ibb.co/2KL07ZG/229-2291721-logo-fishing-angling-fishing-logo-png-transparent-png.jpg" group-title="ENTERTAINMENT",Fishing TV
https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/5d4af39510fd17b31a528eda/master.m3u8?deviceId=channel&deviceModel=web&deviceVersion=1.0&appVersion=1.0&deviceType=rokuChannel&deviceMake=rokuChannel&deviceDNT=1&advertisingId=channel&embedPartner=rokuChannel&appName=rokuchannel&is_lat=1&bmodel=bm1&content=channel&platform=web&tags=ROKU_CONTENT_TAGS&coppa=false&content_type=livefeed&rdid=channel&genre=ROKU_ADS_CONTENT_GENRE&content_rating=ROKU_ADS_CONTENT_RATING&studio_id=viacom&channel_id=channel

#EXTINF:-1 tvg-logo="https://i.imgur.com/cyWbYaX.jpg" group-title="ENTERTAINMENT",Travel
https://bk7l2w4nlx53-hls-live.5centscdn.com/TRAVEL/961ac1c875f5884f31bdd177365ef1e3.sdp/playlist.m3u8

#EXTINF:-1 tvg-logo="https://www.dropbox.com/s/fldtbe5kvdc3k75/axstvnow.png?dl=1" group-title="ENTERTAINMENT",AXS TV Now
https://dikcfc9915kp8.cloudfront.net/hls/main.m3u8

#EXTINF:-1 tvg-logo="https://i.postimg.cc/pLmqd4qx/PEOPLE-ARE-AWESOME.png" group-title="ENTERTAINMENT",People Are Awesome
https://dai2.xumo.com/xumocdn/p=redbox&deviceid=&is_lat=&subp=RedboxdesktopWebWindows/amagi_hls_data_xumo1212A-redboxpeopleareawesome/CDN/1280x720_5000000/chunklist.m3u8

#EXTINF:-1 tvg-id="" tvg-logo="https://i.imgur.com/OiMMkP3.jpg" group-title="ENTERTAINMENT",Just for Laughs Gags
https://dai2.xumo.com/amagi_hls_data_xumo1212A-viziojustforlaughsgags/CDN/playlist.m3u8

#EXTINF:-1 tvg-id="StarWorldHDIndia.in" tvg-name="Star World HD India" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/8/8f/Star_World_HD_India.png" group-title="ENTERTAINMENT",Star World 
http://kmkus.wanicelife.com:8880/live/12m0390043/17783455/1723.m3u855320.m3u8

#EXTINF:-1 tvg-id="GlobalGotTalent.us" tvg-name="Global Got Talent" tvg-country="US" tvg-language="English" tvg-logo="https://i.imgur.com/QHiOf7Z.png" group-title="ENTERTAINMENT",Global Got Talent
https://dai2.xumo.com/amagi_hls_data_xumo1212A-rokugottalentglobal/CDN/playlist.m3u8

#EXTINF:-1 tvg-id="AEBestof.us" tvg-name="A&E (Best of)" tvg-country="US" tvg-language="English" tvg-logo="https://i.imgur.com/zl7Gzwm.png" group-title="ENTERTAINMENT",A&E 
https://bk7l2w4nlx53-hls-live.5centscdn.com/AETV/514c04b31b5f01cf00dd4965e197fdda.sdp/playlist.m3u8

#EXTINF:-1 tvg-logo="https://od.lk/s/MF8yMzQ3MDMwMjhf/HauntTV_600x600.png" group-title="ENTERTAINMENT",Haunt TV 
https://haunttv-roku.amagi.tv/playlist.m3u8?l1br3HA0501

#EXTINF:-1 tvg-logo="https://od.lk/s/MF8yMzUyODMwNjBf/DarkMatterTV_218x218.png" group-title="ENTERTAINMENT",Dark Matter TV 
https://dmtv-plex.amagi.tv/playlist.m3u8?l1br3DM0501

#EXTINF:-1 tvg-logo="https://od.lk/s/MF8yMzUyODMyMzRf/AmericanHorrors.png" group-title="ENTERTAINMENT",American Horrors
http://170.178.189.66:1935/live/Stream1/playlist.m3u8?l1br3DM0501

#KODIPROP:inputstream.adaptive.manifest_type=mpd
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key=https://dukun.masuk.id/drm/result.php?keyid=ce17264b317db108f19cdc11aa1a9e66&key=a21188aee8fc5c56d016fcffcc6b2295
#EXTINF:-1 tvg-ID="ColorsInfinity.in" tvg-name="Colors Infinity" tvg-logo="https://raw.githubusercontent.com/kpsboy/LOGO-KPSBOY/main/ASTRO/sonyinfinity.png" group-title="ENTERTAINMENT",Colors Infinity
https://cdn-01.toffeelive.com/origin-03/live-origin/smil:colors_infinity_hd.smil/manifest.mpd
http://221.120.204.4/COLOURS-INFINITY-LOCKLE/tracks-v1a1/mono.m3u8

#KODIPROP:inputstream.adaptive.manifest_type=mpd
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key=https://dukun.masuk.id/drm/result.php?keyid=ce17264b317db108f19cdc11aa1a9e66&key=a21188aee8fc5c56d016fcffcc6b2295
#EXTINF:-1 tvg-ID="ComedyCentralIndia.in" tvg-logo="https://i.ibb.co/y0T82Z9/Logo-Comedy-Central-modified.png" group-title="ENTERTAINMENT",Comedy Central
https://cdn-01.toffeelive.com/origin-03/live-origin/smil:comedy_central_hd.smil/manifest.mpd





#######################################################################################################################################################################

#############################



#EXTINF:-1 tvg-id="CHN" group-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="RELIGION" ch-number="1" tvg-logo="https://i.ibb.co/d0kZpPm/unnamed.png",Quran TV
http://m.live.net.sa:1935/live/quran/playlist.m3u8

#EXTINF:-1 tvg-id="CHN" group-title="RELIGION" ch-number="2" tvg-logo="https://i.ibb.co/Xb8ZQTv/SUNNA.png",Sunnah TV
http://m.live.net.sa:1935/live/sunnah/chunklist_w444768572.m3u8

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=ZGFkZmZkZjItYzQ1Mi0zM2RiLTk0OWQtM2M2YmY1YzZjMDNi
#EXTINF:0 tvg-id="MuslimTV.Id" tvg-logo="https://cdn.ksa.my.id/muslimtv.png" group-title="RELIGION",Muslim TV
https://anevia114.mncnow.id/live/eds/MNCMuslim/sa_dash_vmx/MNCMuslim.mpd



#######################################################################################################################################################################

#############################



#EXTINF:-1 tvg-id="CHN" tvg-name="" group-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="MOVIES",SILA KLIK DAN BACA!!
https://tinyurl.com/sila-baca-la-oii

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="MOVIES",VISIT MY SHOP 
https://tinyurl.com/visit-kedai-saya

#EXTINF:-1 tvg-id="CCM.hk" ch-number="321" group-title="MOVIES" tvg-logo="https://i.ibb.co/kyKTZLB/ccm-modified.png",Celestial Classic Movies (MY)
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/100
http://linearjitp-playback.astro.com.my/dash-wv/linear/100/default_primary.mpd

#EXTINF:-1 tvg-id="CCM.hk" tvg-name="Celestial Classic Movies" group-title="MOVIES" tvg-logo="https://i.ibb.co/kyKTZLB/ccm-modified.png",Celestial Classic Movies (ID)
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MzRjOGRhNmItM2ZmNi0zMGIwLWI1NTEtM2ViNjlhZmM2NWU0
#EXTVLCOPT:http-referrer=http://www.astro.com.my
https://av-live-cdn.mncnow.id/live/eds/CelestialClassic/sa_dash_vmx/CelestialClassic.mpd

#EXTINF:-1 tvg-id="CelestialMoviesMalaysia.my" ch-number="309" ch-number="CelestialMovies" tvg-logo="https://i.ibb.co/v3KrQGZ/Maxresdefault-modified.png" group-title="MOVIES",Celestial Movies (MY) 
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/506
http://linearjitp-playback.astro.com.my/dash-wv/linear/506/default_primary.mpd

#EXTINF:-1 tvg-id="CelestialMoviesIndonesia.id" tvg-name="Celestial Movies HD" group-title="MOVIES" tvg-logo="https://i.ibb.co/v3KrQGZ/Maxresdefault-modified.png",Celestial Movies (ID)
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MzRjOGRhNmItM2ZmNi0zMGIwLWI1NTEtM2ViNjlhZmM2NWU0
#EXTVLCOPT:http-referrer=http://www.astro.com.my
https://av-live-cdn.mncnow.id/live/eds/CelestialMovie/sa_dash_vmx/CelestialMovie.mpd

#EXTINF:-1 tvg-id="WarnerTVAsia.us" ch-number="712" group-title="MOVIES" tvg-logo="https://i.ibb.co/sCSK6bx/wb-logo-new-shield-modified.png",Warner TV (MY)
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2605
https://linearjitp-playback.astro.com.my/dash-wv/linear/2605/default_primary.mpd

#EXTINF:-1 tvg-id="WarnerTVAsia.us" group-title="MOVIES" tvg-logo="https://i.ibb.co/sCSK6bx/wb-logo-new-shield-modified.png",Warner TV (ID)
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MzRjOGRhNmItM2ZmNi0zMGIwLWI1NTEtM2ViNjlhZmM2NWU0
#EXTVLCOPT:http-referrer=http://www.astro.com.my
https://av-live-cdn.mncnow.id/live/eds/WarnerTV/sa_dash_vmx/WarnerTV.mpd

#EXTINF:-1 tvg-id="KIX.hk" group-title="MOVIES" tvg-logo="https://i.ibb.co/fMmvZkN/images-5-modified.png" ch-number="705",KIX (MY)
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/607
# https://linearjitp-playback.astro.com.my/dash-wv/linear/607/default_primary.mpd

#EXTINF:-1 tvg-id="KIX.hk" group-title="MOVIES" tvg-logo="https://i.ibb.co/fMmvZkN/images-5-modified.png",KIX 
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha 
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=YWY0OTBlZjEtODAyNC0zZTA0LWFhYzMtY2ZmMGE4NjVjZjU1
#EXTVLCOPT:http-referrer=http://www.astro.com.my
https://av-live-cdn.mncnow.id/live/eds/KIX/sa_dash_vmx/KIX.mpd

#EXTINF:-1 tvg-id="AXNMalaysia.my" group-title="MOVIES" tvg-logo="https://i.ibb.co/9gKm3Fv/images-2-modified.png" ch-number="701",AXN (MY)
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2303
https://linearjitp-playback.astro.com.my/dash-wv/linear/2303/default.mpd

#EXTINF:-1 tvg-id="AXNIndonesia.id" group-title="MOVIES" tvg-logo="https://i.ibb.co/9gKm3Fv/images-2-modified.png",AXN (ID)
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha 
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=YWY0OTBlZjEtODAyNC0zZTA0LWFhYzMtY2ZmMGE4NjVjZjU1
#EXTVLCOPT:http-referrer=http://www.astro.com.my
https://av-live-cdn.mncnow.id/live/eds/AXN/sa_dash_vmx/AXN.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5049
#EXTINF:-1 tvg-id="PRIMEtime.my" tvg-logo="http://linear-poster.astro.com.my/prod/logo/PRIMEtime.png" group-title="MOVIES",Primetime 
http://linearjitp-playback.astro.com.my/dash-wv/linear/5049/default_primary.mpd

#EXTINF:-1 tvg-id="Thrill.hk" group-title="MOVIES" tvg-logo="https://i.ibb.co/7vfgMHb/images-modified.png",Thrill (ID)
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MzRjOGRhNmItM2ZmNi0zMGIwLWI1NTEtM2ViNjlhZmM2NWU0
https://av-live-cdn.mncnow.id/live/eds/Thrill/sa_dash_vmx/Thrill.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://linearjitp-playback-astro.astradamy.com/dash-ck/linear/1109/
#EXTINF:-1 tvg-id="129" ch-number="129" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/42_144.png" group-title="MOVIES",ART Movies ASTV
# https://linearjitp-playback.astro.com.my/dash-wv/linear/1109/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5054
#EXTINF:-1 tvg-id="ShowcaseMovies.my" tvg-logo="http://linear-poster.astro.com.my/prod/logo/ShowcaseMovies.png" group-title="MOVIES",Showcase Movies 
http://linearjitp-playback.astro.com.my/dash-wv/linear/5054/default_primary.mpd

#EXTINF:-1 tvg-id="HITS.sg" group-title="MOVIES" tvg-logo="https://i.ibb.co/ZVKPyrN/download-modified.png" ch-number="706",Hits (MY) 
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/606
http://linearjitp-playback.astro.com.my/dash-wv/linear/606/default_primary.mpd

#EXTINF:-1 tvg-id="HITS.sg" group-title="MOVIES" tvg-logo="https://i.ibb.co/ZVKPyrN/download-modified.png",Hits (ID)
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MzRjOGRhNmItM2ZmNi0zMGIwLWI1NTEtM2ViNjlhZmM2NWU0
#EXTVLCOPT:http-referrer=http://www.astro.com.my
https://av-live-cdn.mncnow.id/live/eds/HITS/sa_dash_vmx/HITS.mpd

#EXTINF:-1 tvg-id="HITSMovies.sg" ch-number="401" group-title="MOVIES" tvg-logo="https://i.ibb.co/5Mqnx0R/hits-png-modified.png",HITS Movies (MY)
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2305
http://linearjitp-playback.astro.com.my/dash-wv/linear/2305/default_primary.mpd

#EXTINF:-1 tvg-id="HITSMovies.sg" tvg-name="Hits Movies HD" group-title="MOVIES" tvg-logo="https://i.ibb.co/5Mqnx0R/hits-png-modified.png",Hits Movies (ID) 
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MzRjOGRhNmItM2ZmNi0zMGIwLWI1NTEtM2ViNjlhZmM2NWU0
#EXTVLCOPT:http-referrer=http://www.astro.com.my
https://av-live-cdn.mncnow.id/live/eds/HitsMovies/sa_dash_vmx/HitsMovies.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2407
#EXTINF:-1 tvg-id="Boo.my" tvg-logo="https://i.ibb.co/xs37yJ8/boo-removebg-preview-modified.png" group-title="MOVIES",Astro BOO
https://linearjitp-playback.astro.com.my/dash-wv/linear/2407/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5056
#EXTINF:-1 tvg-id="ParamountNetworkMalaysia.my" tvg-logo="https://i.ibb.co/zrxvFLV/images-6-modified.png" group-title="MOVIES",Paramount Network
http://linearjitp-playback.astro.com.my/dash-wv/linear/5056/default_primary.mpd

#EXTINF:-1 tvg-id="CinemaWorldHD" group-title="MOVIES" tvg-logo="http://playtv.unifi.com.my:7039/CPS/images/universal/film/logo/201907/20190716/20190716065916134bcf.png",CinemaWorld 
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MzRjOGRhNmItM2ZmNi0zMGIwLWI1NTEtM2ViNjlhZmM2NWU0
https://av-live-cdn.mncnow.id/live/eds/CinemaWorld/sa_dash_vmx/CinemaWorld.mpd

#EXTINF:-1 tvg-id="HBOAsia.sg" group-title="MOVIES" tvg-logo="https://i.ibb.co/yBkj4bt/download-1-modified.png",HBO (MY)
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2304
http://linearjitp-playback.astro.com.my/dash-wv/linear/2304/default_primary.mpd

#EXTINF:-1 tvg-id="HBOAsia.sg" tvg-name="HBO HD" group-title="MOVIES" tvg-logo="https://i.ibb.co/yBkj4bt/download-1-modified.png",HBO (ID)
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MjhkOWZkZjYtOGViOC0zNTkzLWFhOWEtNGFhMzJkMDk3NGE2
https://av-live-cdn.mncnow.id/live/eds/hbo-2/sa_dash_vmx/hbo-2.mpd

#EXTINF:-1 tvg-id="HBOHitsAsia.sg" ch-number="415" group-title="MOVIES" tvg-logo="https://i.ibb.co/hs4cYBj/hqdefault-modified-1.png",HBO Hits (MY)
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5055
https://linearjitp-playback.astro.com.my/dash-wv/linear/5055/default_primary.mpd

#EXTINF:-1 tvg-id="HBOHitsAsia.sg" tvg-name="HBO Hits" group-title="MOVIES" tvg-logo="https://i.ibb.co/hs4cYBj/hqdefault-modified-1.png",HBO Hits (ID)
#https://liveorigin01.hbogoasia.com:8443/origin/live/main/HITS/index.m3u8
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MzRjOGRhNmItM2ZmNi0zMGIwLWI1NTEtM2ViNjlhZmM2NWU0
#EXTVLCOPT:http-referrer=http://www.astro.com.my
https://live-cdn.mncnow.id/live/eds/HBOHits/sa_dash_vmx/HBOHits.mpd

#EXTINF:-1 tvg-id="HBOFamilyAsia.sg" ch-number="414" group-title="MOVIES" tvg-logo="https://i.ibb.co/hKf955K/hbo-family-modified.png",HBO Family (MY)
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5053
https://linearjitp-playback.astro.com.my/dash-wv/linear/5053/default_primary.mpd

#EXTINF:-1 tvg-id="HBOFamilyAsia.sg" tvg-name="HBO Family" group-title="MOVIES" tvg-logo="https://i.ibb.co/hKf955K/hbo-family-modified.png",HBO Family (ID)
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MzRjOGRhNmItM2ZmNi0zMGIwLWI1NTEtM2ViNjlhZmM2NWU0
EXTVLCOPT:http-referrer=http://www.astro.com.my
https://av-live-cdn.mncnow.id/live/eds/HBOFamily2/sa_dash_vmx/HBOFamily2.mpd

#EXTINF:-1 tvg-id="HBOSignatureAsia.sg" tvg-name="HBO Signature HD" group-title="MOVIES" tvg-logo="https://i.ibb.co/gt1RM6s/hbo-signature-modified.png",HBO Signature 
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MzRjOGRhNmItM2ZmNi0zMGIwLWI1NTEtM2ViNjlhZmM2NWU0
https://av-live-cdn.mncnow.id/live/eds/HBOSignature2/sa_dash_vmx/HBOSignature2.mpd
#https://liveorigin01.hbogoasia.com:8443/origin/live/main/SIG/index.m3u8

#EXTINF:-1 tvg-id="CinemaxAsia.sg" ch-number="412" ch-number:"Cinemax" group-title="MOVIES" tvg-logo="https://i.ibb.co/L0LsC1t/cinemax-modified.png",Cinemax (MY)
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/603
https://linearjitp-playback.astro.com.my/dash-wv/linear/603/default_primary.mpd

#EXTINF:-1 tvg-id="CinemaxAsia.sg" tvg-name="CINEMAX HD" group-title="MOVIES" tvg-logo="https://i.ibb.co/L0LsC1t/cinemax-modified.png",Cinemax (ID)
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MzRjOGRhNmItM2ZmNi0zMGIwLWI1NTEtM2ViNjlhZmM2NWU0
#EXTVLCOPT:http-referrer=http://www.astro.com.my
https://av-live-cdn.mncnow.id/live/eds/CinemaxHD2/sa_dash_vmx/CinemaxHD2.mpd
#https://liveorigin01.hbogoasia.com:8443/origin/live/main/MAX/index.m3u8

#EXTINF:-1 tvg-id="StarMoviesIndia.in" tvg-logo="https://i.ibb.co/PFpZHbS/6-Rbm-Dfm-modified.png" group-title="MOVIES",Star Movies
#EXTVLCOPT:http-user-agent=REDLINECLIENT
https://dukun.masuk.id/57337005c17a518a3cee71d5170f05210698fd0b11a8f77733c08de39ab09ac67652ce68-78a50d92c806e206e634451643a7d8bf-1660653338-1660642539/hiburan/starmo
http://line.premiumpowers.net:80/Bianca/1234567/282639

#EXTINF:-1 tvg-id="StarMoviesSelect.in" tvg-logo="https://i.ibb.co/2jh4NGh/starmovirs-modified-1.png" group-title="MOVIES",Star Movies Select
#EXTVLCOPT:http-user-agent=REDLINECLIENT
https://dukun.masuk.id/57337005c17a518a3cee71d5170f05210698fd0b11a8f77733c08de39ab09ac67652ce68-78a50d92c806e206e634451643a7d8bf-1660653338-1660642539/hiburan/starselect

#KODIPROP:inputstream.adaptive.manifest_type=mpd
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key=https://dukun.masuk.id/drm/result.php?keyid=ce17264b317db108f19cdc11aa1a9e66&key=a21188aee8fc5c56d016fcffcc6b2295
#EXTINF:-1 tvg-id="SonyPix.in" tvg-logo="http://live.flixhub.net/img/sonypixhd.jpg" tvg-id="" tvg-name="" group-title="MOVIES",Sony Pix 
https://cdn-01.toffeelive.com/origin-08/live-origin/smil:sony_pix_hd.smil/manifest.mpd

#EXTINF:-1 tvg-id="Andflix.in" tvg-logo="https://i.ibb.co/k1JJN2t/and-flix-hd-logo-300x300-modified.png" group-title="MOVIES",&Flix
#EXTVLCOPT:http-user-agent=zznszhhsfnsdx
https://dukun.masuk.id/57337005c17a518a3cee71d5170f05210698fd0b11a8f77733c08de39ab09ac67652ce68-78a50d92c806e206e634451643a7d8bf-1660653338-1660642539/hiburan/flix

#EXTINF:-1 tvg-id="AndpriveHD.in" tvg-logo="https://i.ibb.co/yqj6BMX/unnamed-19-modified.png" group-title="MOVIES",&Prive
#EXTVLCOPT:http-user-agent=zznszhhsfnsdx
http://kmkus.wanicelife.com:8880/live/12m0390043/17783455/1723.m3u8/54975.m3u8
# https://dukun.masuk.id/57337005c17a518a3cee71d5170f05210698fd0b11a8f77733c08de39ab09ac67652ce68-78a50d92c806e206e634451643a7d8bf-1660653338-1660642539/hiburan/prive

#EXTINF:-1 tvg-id="blueantext" group-title="MOVIES" tvg-logo="https://i.ibb.co/KLSyc92/Rock-Extreme.png", Rock Action
#EXTVLCOPT:http-user-agent=Lavf/56.15.102
http://210.210.155.37/session/e775987a-25f3-11ed-8ba5-85009179245a/dr9445/h/h15/01.m3u8
# http://210.210.155.35:80/dr9445/h/h16/02.m3u8 

#EXTINF:-1 tvg-id="MoviesNow.in" group-title="MOVIES" tvg-logo="https://i.ibb.co/JCjgTd5/Movies-Now.png",Movies Now
http://line.premiumpowers.net:80/Bianca/1234567/282651

#EXTINF:-1 tvg-id="MoviesNowPlus.in" group-title="MOVIES" tvg-logo="https://i.ibb.co/JCjgTd5/Movies-Now.png",Mn+
http://line.premiumpowers.net:80/Bianca/1234567/282649

#EXTINF:-1 tvg-id="MNX.in" group-title="MOVIES" tvg-logo="https://i.ibb.co/vsyWTvD/MNX-logo.png",Mnx
http://line.premiumpowers.net:80/Bianca/1234567/282650

#EXTINF:-1 tvg-id="mycinema.MACAN" tvg-logo="https://i.ibb.co/vDx82bx/Desain-tanpa-judul-71-modified.png" group-title="MOVIES", My Cinema
http://210.210.155.37/uq2663/h/h192/index.m3u8
http://210.210.155.35/uq2663/h/h192/index.m3u8?app_type=web&userid=50n13N0v14nd1&tkn=829341hrjhaq0q30q&chname=My_Cinema_HD

#EXTINF:-1 tvg-id="mycinemaasia.MACAN" tvg-logo="https://i.ibb.co/5L5Cq6b/Desain-tanpa-judul-70-modified.png" group-title="MOVIES", My Cinema Asia
http://210.210.155.35/uq2663/h/h193/index.m3u8
http://210.210.155.35/uq2663/h/h193/index.m3u8?app_type=web&userid=50n13N0v14nd1&tkn=829341hrjhaq0q30q&chname=My_Cinema_Asia

#EXTINF:-1 tvg-id="myfamilychannel.MACAN" tvg-logo="https://i.ibb.co/m59c58z/Desain-tanpa-judul-72-modified.png" group-title="MOVIES", My Cinema Family
http://210.210.155.35/x6bnqe/h/h194/index.m3u8
http://210.210.155.35/uq2663/h/h194/index.m3u8?app_type=web&userid=50n13N0v14nd1&tkn=829341hrjhaq0q30q&chname=My_Family_Channel_Trial-

#EXTINF:-1 tvg-id="mycinemaeurope.MACAN" tvg-logo="https://i.ibb.co/XWyYzk8/Desain-tanpa-judul-73-modified.png" group-title="MOVIES", My Cinema Europe
http://210.210.155.35:80/uq2663/h/h18/01.m3u8

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTINF:-1 tvg-id="Galaxy.id" tvg-logo="https://i.ibb.co/WxDMnJt/channel-13-modified.png" group-title="MOVIES",Galaxy
https://av-live-cdn.mncnow.id/live/eds/Galaxy-HD/sa_dash_vmx/Galaxy-HD.mpd

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTINF:-1 tvg-id="GalaxyPremium.id" tvg-logo="ttps://i.ibb.co/b7Nfx6X/channel-12-modified.png" group-title="MOVIES",Galaxy Premium
https://av-live-cdn.mncnow.id/live/eds/GalaxyPremium-HD/sa_dash_vmx/GalaxyPremium-HD.mpd

#EXTINF:-1 tvg-id="MNetMovies1EastAfrica.za" tvg-name="ZA: M-Net Movies 1" tvg-logo="http://s3.i3ns.net/portal/picon/2022-02/739bdaf1d13b2c9beb5faf1ce29c5173.jpg" group-title="MOVIES",M-Net Movies 1
#http://teeveetv.one:2052/syntax/MKlaiuUcj2/872400

#EXTINF:-1 tvg-id="MNetMovies2.za" tvg-name="ZA: M-Net Movies 2" tvg-logo="http://s3.i3ns.net/portal/picon/2021-06/174502bcec0def9e77692f2fd9fcd93a.png" group-title="MOVIES",M-Net Movies 2
#http://teeveetv.one:2052/syntax/MKlaiuUcj2/872401

#EXTINF:-1 tvg-id="MNetMovies3.za" tvg-name="ZA: M-Net Movies 3" tvg-logo="http://s3.i3ns.net/portal/picon/2022-05/c35ffa114923b79a40d27196b533220d.png" group-title="MOVIES",M-Net Movies 3
#http://teeveetv.one:2052/syntax/MKlaiuUcj2/872402

#EXTINF:-1 tvg-id="MNetMovies4.za" tvg-name="ZA: M-Net Movies 3" tvg-logo="http://s3.i3ns.net/portal/picon/2022-05/c35ffa114923b79a40d27196b533220d.png" group-title="MOVIES",M-Net Movies 4
#http://teeveetv.one:2052/syntax/MKlaiuUcj2/872403

#EXTINF:-1 tvg-id="SkyCinemaPremiereHD.uk" tvg-logo="https://i.ibb.co/Xb2VKDL/download-21-modified-1.png" group-title="MOVIES",Sky Cinema Premiere
https://dukun.masuk.id/57337005c17a518a3cee71d5170f05210698fd0b11a8f77733c08de39ab09ac67652ce68-78a50d92c806e206e634451643a7d8bf-1660653338-1660642539/hiburan/skypremier
http://kmkus.wanicelife.com:8880/live/12m0390043/17783455/1723.m3u8/28956.m3u8

#EXTINF:-1 tvg-id="SkyCinemaComedyHD.uk" tvg-logo="https://i.ibb.co/Xb2VKDL/download-21-modified-1.png" group-title="MOVIES",Sky Cinema Comedy
https://dukun.masuk.id/57337005c17a518a3cee71d5170f05210698fd0b11a8f77733c08de39ab09ac67652ce68-78a50d92c806e206e634451643a7d8bf-1660653338-1660642539/hiburan/skyspecialhttp://mxu03.wanicelife.com:8880/live/12mm630085/35185694/28760.m3u8

#EXTINF:-1 tvg-id="SkyCinemaActionHD.uk" tvg-logo="https://i.ibb.co/Xb2VKDL/download-21-modified-1.png" group-title="MOVIES",Sky Cinema Action
https://dukun.masuk.id/57337005c17a518a3cee71d5170f05210698fd0b11a8f77733c08de39ab09ac67652ce68-78a50d92c806e206e634451643a7d8bf-1660653338-1660642539/hiburan/skyaction
http://kmkus.wanicelife.com:8880/live/12m0390043/17783455/1723.m3u8/28892.m3u8

#EXTINF:-1 tvg-id="SkyCinemaThrillerHD.uk" tvg-logo="https://i.ibb.co/Xb2VKDL/download-21-modified-1.png" group-title="MOVIES",Sky Cinema Thriller
https://dukun.masuk.id/57337005c17a518a3cee71d5170f05210698fd0b11a8f77733c08de39ab09ac67652ce68-78a50d92c806e206e634451643a7d8bf-1660653338-1660642539/hiburan/skythiller
http://kmkus.wanicelife.com:8880/live/12m0390043/17783455/1723.m3u8/28914.m3u8

#EXTINF:-1 tvg-id="" tvg-name="Moviesphere Free" tvg-logo="https://images.samsung.com/is/image/samsung/assets/au/tvs/smart-tv/samsung-tv-plus/all-channels/Moviesphere-Free_SamsungAsset_Logo_1000x1000_C_White.png" group-title="MOVIES",Moviesphere Free
https://moviesphere-samsung-samsungus.amagi.tv/playlist.m3u8

#EXTINF:-1 tvg-id="" tvg-name="" tvg-logo="https://i.ibb.co/ykfcdXd/Logo-FLIX-TV.png" group-title="MOVIES",Family Flix
https://linear-137.frequency.stream/dist/localnow/137/hls/master/playlist.m3u8

#EXTINF:-1 tvg-id="USBA3000041ZP" tvg-name="The Movie Hub" tvg-logo="https://i.ibb.co/r6WS80p/download-1.png" group-title="MOVIES",Movies Hub
https://dje6yassknq8t.cloudfront.net/playlist.m3u8

#EXTINF:-1 tvg-id="USAJ4300010Y0" tvg-name="Dove Channel" tvg-logo="https://i.ibb.co/2PmscZM/87590-w-450-224.png" group-title="MOVIES",Dove TV
https://dai.google.com/linear/hls/event/dfbBGQhPQQqypdEAjpUGlA/master.m3u8

#EXTINF:-1 tvg-id="" tvg-name="" tvg-logo="https://i.ibb.co/58589WZ/99b1354d-8a98-478f-acb1-217f619405b4.jpg" group-title="MOVIES",My Time
https://mytime-tcl.amagi.tv/playlist.m3u

#EXTINF:-1 tvg-id="" tvg-name="" tvg-logo="https://i.ibb.co/F0Kr4tp/Sony-Crackle-RGB-Hero-BW-Large.jpg" group-title="MOVIES",Crackle
http://crackle-xumo.amagi.tv/playlist.m3u8

#EXTINF:0 tvg-country="" tvg-logo="https://i.ibb.co/nQgB05m/stirr-logo-500x143-color.png" group-title="MOVIES",Stirr Movie
https://dai.google.com/linear/hls/event/f-zA7b21Squ7M1_sabGfjA/master.m3u8

#EXTINF:0 tvg-country="" tvg-logo="https://i.ibb.co/09cb1Xp/unnamed.png" group-title="MOVIES",CineLife
https://dai.google.com/linear/hls/event/PFJ1Jhd6SsSMcu3qq86wzQ/master.m3u8?source:iptvmate.net

#EXTINF:0 tvg-id="GBAJ4900006TU" tvg-name="Action Movies - Rakuten TV" tvg-logo="https://i.ibb.co/Y7L31QJ/6038b24ab22ac-384x384.png" group-title="MOVIES",Rakuten TV
https://rakuten-actionmovies-1-gb.samsung.wurl.tv/3000.m3u8

#EXTINF:-1 group-title="MOVIES" tvg-id="1CHN" tvg-logo="https://i.ibb.co/B4xvBb8/600px-Douyu-TV-logo.png",Douyu TV Movies 
https://hlsa-akm.douyucdn.cn/live/20415rnWbjg6Ex1K_900/playlist.m3u8?wsAuth=014b39c4437d974e4d70045eb2d23e67&token=web-h5-0-20415-b6774b3b3249db179435e1a37410043c7827528d80fff5fe&logo=0&expire=0&did=c2d6f221fb67b0e8f4e820a300001601&ver=Douyu_221090605&pt=2&st=0&origin=tct&mix=0&isp=
#http://tx2play1.douyucdn.cn:80/live/dyliveflv3/20415rnWbjg6Ex1K_4000p.xs

#EXTINF:-1 tvg-id="" tvg-name="Flix Bus" tvg-logo="https://i.ibb.co/Srm8zWy/x.png" group-title="MOVIES",Flix Bus
http://hpull.kktv8.com/livekktv/128600025/playlist.m3u8

#EXTINF:-1 tvg-id="" tvg-name="Cloud Movie" tvg-logo="https://i.ibb.co/Yyz0xRB/download.png" group-title="MOVIES",Cloud Movie
http://117.148.179.176/PLTV/88888888/224/3221231565/index.m3u8

#EXTINF:-1 tvg-logo="https://planetdish.com/wp-content/uploads/2017/09/PixL-on-DISH.png" group-title="MOVIES", Pixl TV Movie Channel
https://frndlymsl.akamaized.net/hls/live/2006426/pixlmsl/pixlmsl/playlist.m3u8?hdnts=st=1606053234~exp=3216054041~acl=*~hmac=208d261d9f98d76a5ac30aa2ce51751f88ee50cfc24812b7cbea8b0397489a07

#EXTINF:-1 tvg-id="FMN.id" group-title="MOVIES" tvg-logo="https://i.ibb.co/XX7q7nQ/FMN-Forget-Me-Not-Channel.png", Fmn 
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=ZGFkZmZkZjItYzQ1Mi0zM2RiLTk0OWQtM2M2YmY1YzZjMDNi
https://live-cdn.mncnow.id/live/eds/FMN/sa_dash_vmx/FMN.mpd

#EXTINF:-1 tvg-id="USAJ40000072X" tvg-name="FilmRise Free Movies" tvg-logo="https://i.imgur.com/cQZdGc0.png" group-title="MOVIES",FilmRise 
https://dai.google.com/linear/hls/event/Va1QEor0SWO_x_SQNyaF0w/master.m3u8

#EXTINF:-1 tvg-id="USBB19000017U" tvg-name="Hallmark Movies & Mysteries" group-title="MOVIES" tvg-logo="https://i.ibb.co/b3RzPzC/Hallmark-Movies-Mysteries.png",Hallmark movies & Mysteries
https://frndlymsl.akamaized.net/hls/live/2006424/hallmarkmmsl/hallmarkmmsl/playlist.m3u8?hdnts=st=1606053234~exp=3216054041~acl=*~hmac=208d261d9f98d76a5ac30aa2ce51751f88ee50cfc24812b7cbea8b0397489a07

#EXTINF:-1 tvg-name="Hallmark Movies & More" tvg-name="Hallmark Movies & Mysteries" group-title="MOVIES" tvg-logo="https://i.ibb.co/b3RzPzC/Hallmark-Movies-Mysteries.png",Hallmark movies & More
https://dqvu8d0acm4xt.cloudfront.net/v1/master/3722c60a815c199d9c0ef36c5b73da68a62b09d1/HallmarkMovies-prod/playlist.m3u8?ads.device_did=%7BPSID%7D&ads.device_dnt=%7BTARGETOPT%7D&ads.us_privacy=1YNY&ads.app_domain=%7BAPP_DOMAIN%7D&ads.app_name=%7BAPP_NAME%7D

#EXTINF:-1 tvg-logo="https://i.imgur.com/nZEaSAb.png" group-title="MOVIES",Film Hub
http://dai2.xumo.com/amagi_hls_data_xumo1212A-redboxfilmhub/CDN/playlist.m3u8

#EXTINF:-1 tvg-logo="https://i.imgur.com/DkgjeAg.png" group-title="MOVIES",iFilm English
https://live1.presstv.ir/live/ifilmen.m3u8

#EXTINF:-1 tvg-logo="https://images.pluto.tv/channels/58e55b14ad8e9c364d55f717/colorLogoPNG.png" group-title="MOVIES",Flicks of Fury
https://service-stitcher.clusters.pluto.tv/stitch/hls/channel/58e55b14ad8e9c364d55f717/master.m3u8?terminate=false&deviceType=web&deviceMake=web&deviceModel=web&sid=112&deviceId=58e55b14ad8e9c364d55f717&deviceVersion=DNT&appVersion=DNT&deviceDNT=0&userId=&advertisingId=&deviceLat=&deviceLon=&app_name=&appName=web&buildVersion=&appStoreUrl=&architecture=&includeExtendedEvents=false&marketingRegion=US&serverSideAds=false&checkedby:hlscat.com

#EXTINF:-1 tvg-logo="https://cdn.tvpassport.com/image/station/100x100/movies.png" group-title="MOVIES",Movies!
https://v-ny.theus6tv.tk/hls/5.2/playlist.m3u8

#EXTINF:-1 tvg-logo="https://images.pluto.tv/channels/5f988934a507de00075d9ae7/colorLogoPNG.png" group-title="MOVIES",Showtime Selects
https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/5f988934a507de00075d9ae7/master.m3u8?advertisingId=channel&appName=rokuchannel&appVersion=1.0&bmodel=bm1&channel_id=channel&content=channel&content_rating=ROKU_ADS_CONTENT_RATING&content_type=livefeed&coppa=false&deviceDNT=1&deviceId=channel&deviceMake=rokuChannel&deviceModel=web&deviceType=rokuChannel&deviceVersion=1.0&embedPartner=rokuChannel&genre=ROKU_ADS_CONTENT_GENRE&is_lat=1&platform=web&rdid=channel&studio_id=viacom&tags=ROKU_CONTENT_TAGS

#EXTINF:-1 tvg-logo="https://logodownload.org/wp-content/uploads/2021/03/paramount-plus-logo.png" group-title="MOVIES",Paramount Plus Picks
https://service-stitcher.clusters.pluto.tv/stitch/hls/channel/5ff8c708653d080007361b14/master.m3u8?advertisingId=&appName=web&appStoreUrl=&appVersion=DNT&app_name=&architecture=&buildVersion=&deviceDNT=0&deviceId=5d14fc31252d35decbc4080b&deviceLat=&deviceLon=&deviceMake=web&deviceModel=web&deviceType=web&deviceVersion=DNT&includeExtendedEvents=false&marketingRegion=US&serverSideAds=false&sid=873&terminate=false&userId=

#EXTINF:-1 tvg-logo="https://i.imgur.com/WAs8vD1.png" group-title="MOVIES",RedBox Rush
https://rush-redbox.amagi.tv/hls/amagi_hls_data_redboxAAA-rush/CDN/playlist.m3u8

#EXTINF:-1 tvg-logo="https://i.imgur.com/KqjTIh8.png"  group-title="MOVIES",RedBox Spotlight
https://spotlight-redbox.amagi.tv/hls/amagi_hls_data_redboxAAA-spotlight/CDN/playlist.m3u8

#EXTINF:-1 tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/3/31/ION_Plus_logo.svg/1200px-ION_Plus_logo.svg.png" group-title="MOVIES",Ion Plus
https://ion-plus.samsung.wurl.com/manifest/playlist.m3u8

#EXTINF:-1 tvg-id="591105034c1806b47438342c" tvg-chno="115" tvg-logo="https://images.pluto.tv/channels/591105034c1806b47438342c/colorLogoPNG.png" group-title="MOVIES",The Asylum
http://service-stitcher.clusters.pluto.tv/stitch/hls/channel/591105034c1806b47438342c/master.m3u8?terminate=false&deviceType=web&deviceMake=web&deviceModel=web&sid=115&deviceId=591105034c1806b47438342c&deviceVersion=DNT&appVersion=DNT&deviceDNT=0&userId=&advertisingId=&deviceLat=&deviceLon=&app_name=&appName=web&buildVersion=&appStoreUrl=&architecture=&includeExtendedEvents=false&marketingRegion=US&serverSideAds=false






#######################################################################################################################################################################

#########################









#EXTINF:-1 tvg-id="CHN" tvg-name="" group-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="MOVIES_LIVE",SILA KLIK DAN BACA!!
https://tinyurl.com/sila-baca-la-oii

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="MOVIES_LIVE",VISIT MY SHOP 
https://tinyurl.com/visit-kedai-saya


#EXTINF:-1 tvg-id="CHN"  tvg-logo="https://i.ibb.co/K9NNn7y/5685269.png" group-title="MOVIES_LIVE",US| 24/7 BOX OFFICE 2022 1
http://line.premiumpowers.net:80/Bianca/1234567/924692

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/K9NNn7y/5685269.png" group-title="MOVIES_LIVE",US| 24/7 BOX OFFICE 2022 2
http://line.premiumpowers.net:80/Bianca/1234567/924693

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/K9NNn7y/5685269.png" group-title="MOVIES_LIVE",US| 24/7 BOX OFFICE 2022 3
http://line.premiumpowers.net:80/Bianca/1234567/924695

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/K9NNn7y/5685269.png" group-title="MOVIES_LIVE",US| 24/7 BOX OFFICE 2022 4
http://line.premiumpowers.net:80/Bianca/1234567/924696

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/K9NNn7y/5685269.png" group-title="MOVIES_LIVE",US| 24/7 BOX OFFICE 2022 5
http://line.premiumpowers.net:80/Bianca/1234567/924694

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/K9NNn7y/5685269.png" group-title="MOVIES_LIVE",US| 24/7 BOX OFFICE 2022 6
http://line.premiumpowers.net:80/Bianca/1234567/924697

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/nr6CWcx/hbo-logo-png-transparent.png" group-title="MOVIES_LIVE",US| 24/7 HBO MAX 1
http://line.premiumpowers.net:80/Bianca/1234567/924705

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/nr6CWcx/hbo-logo-png-transparent.png" group-title="MOVIES_LIVE",US| 24/7 HBO MAX A
http://line.premiumpowers.net:80/Bianca/1234567/924706

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/nr6CWcx/hbo-logo-png-transparent.png" group-title="MOVIES_LIVE",US| 24/7 HBO MAX B
http://line.premiumpowers.net:80/Bianca/1234567/924707

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/nr6CWcx/hbo-logo-png-transparent.png" group-title="MOVIES_LIVE",US| 24/7 HBO MAX C
http://line.premiumpowers.net:80/Bianca/1234567/924708

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/nr6CWcx/hbo-logo-png-transparent.png" group-title="MOVIES_LIVE",US| 24/7 HBO MAX D
http://line.premiumpowers.net:80/Bianca/1234567/924709

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/nr6CWcx/hbo-logo-png-transparent.png" group-title="MOVIES_LIVE",US| 24/7 HBO MAX E
http://line.premiumpowers.net:80/Bianca/1234567/924710

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/nr6CWcx/hbo-logo-png-transparent.png" group-title="MOVIES_LIVE",US| 24/7 HBO MAX F
http://line.premiumpowers.net:80/Bianca/1234567/924711

#EXTINF:-1 tvg-id="CHN" tvg-name="US| 24/7 NETFLIX 1" tvg-logo="http://logo.protv.cc/picons/logos/USA/NETFLIX.png" group-title="MOVIES_LIVE",US| 24/7 NETFLIX 1
http://line.premiumpowers.net:80/Bianca/1234567/924735

#EXTINF:-1 tvg-id="CHN" tvg-name="US| 24/7 NETFLIX 2" tvg-logo="http://logo.protv.cc/picons/logos/USA/NETFLIX.png" group-title="MOVIES_LIVE",US| 24/7 NETFLIX 2
http://line.premiumpowers.net:80/Bianca/1234567/924736

#EXTINF:-1 tvg-id="CHN" tvg-name="US| 24/7 NETFLIX 3" tvg-logo="http://logo.protv.cc/picons/logos/USA/NETFLIX.png" group-title="MOVIES_LIVE",US| 24/7 NETFLIX 3
http://line.premiumpowers.net:80/Bianca/1234567/924737

#EXTINF:-1 tvg-id="CHN" tvg-name="US| 24/7 NETFLIX 4" tvg-logo="http://logo.protv.cc/picons/logos/USA/NETFLIX.png" group-title="MOVIES_LIVE",US| 24/7 NETFLIX 4
http://line.premiumpowers.net:80/Bianca/1234567/924738

#EXTINF:-1 tvg-id="CHN" tvg-name="US| 24/7 NETFLIX 5" tvg-logo="http://logo.protv.cc/picons/logos/USA/NETFLIX.png" group-title="MOVIES_LIVE",US| 24/7 NETFLIX 5
http://line.premiumpowers.net:80/Bianca/1234567/924739

#EXTINF:-1 tvg-id="CHN" tvg-name="US| 24/7 NETFLIX 6" tvg-logo="http://logo.protv.cc/picons/logos/USA/NETFLIX.png" group-title="MOVIES_LIVE",US| 24/7 NETFLIX 6
http://line.premiumpowers.net:80/Bianca/1234567/924740

#EXTINF:-1 tvg-id="CHN" tvg-name="US| 24/7 SHOWTIME 1" tvg-logo="http://logo.protv.cc/picons/logos/USA/SHOWTIME.png" group-title="MOVIES_LIVE",US| 24/7 SHOWTIME 1
http://line.premiumpowers.net:80/Bianca/1234567/924741

#EXTINF:-1 tvg-id="CHN" tvg-name="US| 24/7 SHOWTIME 2" tvg-logo="http://logo.protv.cc/picons/logos/USA/SHOWTIME.png" group-title="MOVIES_LIVE",US| 24/7 SHOWTIME 2
http://line.premiumpowers.net:80/Bianca/1234567/924742

#EXTINF:-1 tvg-id="CHN" tvg-name="US| 24/7 SHOWTIME 3" tvg-logo="http://logo.protv.cc/picons/logos/USA/SHOWTIME.png" group-title="MOVIES_LIVE",US| 24/7 SHOWTIME 3
http://line.premiumpowers.net:80/Bianca/1234567/924743

#EXTINF:-1 tvg-id="CHN" tvg-name="US| 24/7 SHOWTIME 4" tvg-logo="http://logo.protv.cc/picons/logos/USA/SHOWTIME.png" group-title="MOVIES_LIVE",US| 24/7 SHOWTIME 4
http://line.premiumpowers.net:80/Bianca/1234567/924744

#EXTINF:-1 tvg-id="CHN" tvg-name="US| 24/7 SHOWTIME 5" tvg-logo="http://logo.protv.cc/picons/logos/USA/SHOWTIME.png" group-title="MOVIES_LIVE",US| 24/7 SHOWTIME 5
http://line.premiumpowers.net:80/Bianca/1234567/924745

#EXTINF:-1 tvg-id="CHN" tvg-name="US| 24/7 SHOWTIME 6" tvg-logo="http://logo.protv.cc/picons/logos/USA/SHOWTIME.png" group-title="MOVIES_LIVE",US| 24/7 SHOWTIME 6
http://line.premiumpowers.net:80/Bianca/1234567/924746

#EXTINF:-1 tvg-id="CHN" tvg-name="US| 24/7 SHOWTIME 7" tvg-logo="http://logo.protv.cc/picons/logos/USA/SHOWTIME.png" group-title="MOVIES_LIVE",US| 24/7 SHOWTIME 7
http://line.premiumpowers.net:80/Bianca/1234567/924747

#EXTINF:-1 tvg-id="CHN" tvg-name="US| 24/7 SHOWTIME 8" tvg-logo="http://logo.protv.cc/picons/logos/USA/SHOWTIME.png" group-title="MOVIES_LIVE",US| 24/7 SHOWTIME 8
http://line.premiumpowers.net:80/Bianca/1234567/924748

#EXTINF:-1 tvg-id="CHN" tvg-name="MARVEL| STUDIO CHANNEL 1 HD" tvg-logo="https://i.ibb.co/PFchfg5/new-marvel-studios-logo-debuted-marvelstudios-3.png" group-title="MOVIES_LIVE",MARVEL|STUDIO CHANNEL 1 HD
http://iptvglobal.site:25461/LionTv/r1942G22hz/155979

#EXTINF:-1 tvg-id="CHN" tvg-name="MARVEL| STUDIO CHANNEL 2 HD" tvg-logo="https://i.ibb.co/PFchfg5/new-marvel-studios-logo-debuted-marvelstudios-3.png" group-title="MOVIES_LIVE",MARVEL|STUDIO CHANNEL 2 HD
http://iptvglobal.site:25461/LionTv/r1942G22hz/155980

#EXTINF:-1 tvg-id="CHN" tvg-name="MARVEL| STUDIO CHANNEL 3 HD" tvg-logo="https://i.ibb.co/PFchfg5/new-marvel-studios-logo-debuted-marvelstudios-3.png" group-title="MOVIES_LIVE",MARVEL|STUDIO CHANNEL 3 HD
http://iptvglobal.site:25461/LionTv/r1942G22hz/155981

#EXTINF:-1 tvg-id="CHN" tvg-name="MARVEL| STUDIO CHANNEL 4 HD" tvg-logo="https://i.ibb.co/PFchfg5/new-marvel-studios-logo-debuted-marvelstudios-3.png" group-title="MOVIES_LIVE",MARVEL|STUDIO CHANNEL 4 HD
http://iptvglobal.site:25461/LionTv/r1942G22hz/155982

#EXTINF:-1 tvg-id="CHN" tvg-name="MARVEL| STUDIO CHANNEL 5 HD" tvg-logo="https://i.ibb.co/PFchfg5/new-marvel-studios-logo-debuted-marvelstudios-3.png" group-title="MOVIES_LIVE",MARVEL|STUDIO CHANNEL 5 HD
http://iptvglobal.site:25461/LionTv/r1942G22hz/155983

#EXTINF:-1 tvg-id="CHN" tvg-name="MARVEL| STUDIO CHANNEL 6 HD" tvg-logo="https://i.ibb.co/PFchfg5/new-marvel-studios-logo-debuted-marvelstudios-3.png" group-title="MOVIES_LIVE",MARVEL|STUDIO CHANNEL 6 HD
http://iptvglobal.site:25461/LionTv/r1942G22hz/155984

#EXTINF:-1 tvg-id="CHN" tvg-name="MARVEL| STUDIO CHANNEL 7 HD" tvg-logo="https://i.ibb.co/PFchfg5/new-marvel-studios-logo-debuted-marvelstudios-3.png" group-title="MOVIES_LIVE",MARVEL|STUDIO CHANNEL 7 HD
http://iptvglobal.site:25461/LionTv/r1942G22hz/155985

#EXTINF:-1 tvg-id="CHN" tvg-name="MARVEL| STUDIO CHANNEL 8 HD" tvg-logo="https://i.ibb.co/PFchfg5/new-marvel-studios-logo-debuted-marvelstudios-3.png" group-title="MOVIES_LIVE",MARVEL|STUDIO CHANNEL 8 HD
http://iptvglobal.site:25461/LionTv/r1942G22hz/155986

#EXTINF:-1 tvg-id="CHN" tvg-name="MARVEL| STUDIO CHANNEL 9 HD" tvg-logo="https://i.ibb.co/PFchfg5/new-marvel-studios-logo-debuted-marvelstudios-3.png" group-title="MOVIES_LIVE",MARVEL|STUDIO CHANNEL 9 HD
http://iptvglobal.site:25461/LionTv/r1942G22hz/155987

#EXTINF:-1 tvg-id="CHN" tvg-name="MARVEL| STUDIO CHANNEL 10 HD" tvg-logo="https://i.ibb.co/PFchfg5/new-marvel-studios-logo-debuted-marvelstudios-3.png" group-title="MOVIES_LIVE",MARVEL|STUDIO CHANNEL 10 HD
http://iptvglobal.site:25461/LionTv/r1942G22hz/155988




#######################################################################################################################################################################

#########################



#EXTINF:-1 tvg-id="CHN" tvg-name="" group-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="DOUYU_MOVIES",SILA KLIK DAN BACA!!
https://tinyurl.com/sila-baca-la-oii

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="DOUYU_MOVIES",VISIT MY SHOP 
https://tinyurl.com/visit-kedai-saya

#EXTINF:-1 tvg-id="CHN" tvg-name="DOUYU" tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 2 (C)
http://epg.112114.xyz/douyu/122402

#EXTINF:-1 tvg-id="CHN" tvg-name="DOUYU" tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 3 (C.)
http://epg.112114.xyz/douyu/6763930

#EXTINF:-1 tvg-id="CHN" tvg-name="DOUYU" tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 4 (P)
http://epg.112114.xyz/douyu/2436390

#EXTINF:-1 tvg-id="CHN" tvg-name="DOUYU" tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 5 (P)
http://epg.112114.xyz/douyu/4332

#EXTINF:-1 tvg-id="CHN" tvg-name="DOUYU" tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 6 (P)
http://epg.112114.xyz/douyu/413573

#EXTINF:-1 tvg-id="CHN" tvg-name="DOUYU" tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 7 (P)
http://epg.112114.xyz/douyu/747764

#EXTINF:-1 tvg-id="CHN" tvg-name="DOUYU" tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 8 (P)
http://epg.112114.xyz/douyu/252802

#EXTINF:-1 tvg-id="CHN" tvg-name="DOUYU" tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 9 (P)
http://epg.112114.xyz/douyu/36337

#EXTINF:-1 tvg-id="CHN" tvg-name="DOUYU" tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 10 (P)
http://epg.112114.xyz/douyu/8814650

#EXTINF:-1 tvg-id="CHN" tvg-name="DOUYU" tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 11 (P.M)
http://epg.112114.xyz/douyu/9651304

#EXTINF:-1 tvg-id="CHN" tvg-name="DOUYU" tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 12 (P.M)
http://epg.112114.xyz/douyu/2793084

#EXTINF:-1 tvg-id="CHN" tvg-id= tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 13 (C.)
http://huanqiuzhibo.cn/manifest/douyu.php?id=6566671

#EXTINF:-1 tvg-id="CHN" tvg-id= tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 14 (C.)
http://huanqiuzhibo.cn/manifest/douyu.php?id=310926

#EXTINF:-1 tvg-id="CHN" tvg-id= tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 15 (C)
http://huanqiuzhibo.cn/manifest/douyu.php?id=3637778

#EXTINF:-1 tvg-id="CHN" tvg-id= tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 17 (C)
http://huanqiuzhibo.cn/manifest/douyu.php?id=3637765

#EXTINF:-1 tvg-id="CHN" tvg-id= tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 18 (C.S)
http://huanqiuzhibo.cn/manifest/douyu.php?id=122402

#EXTINF:-1 tvg-id="CHN" tvg-id= tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 19 (C)
http://huanqiuzhibo.cn/manifest/douyu.php?id=85894

#EXTINF:-1 tvg-id="CHN" tvg-id= tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 20 (P)
http://huanqiuzhibo.cn/manifest/douyu.php?id=1504768

#EXTINF:-1 tvg-id="CHN" tvg-id= tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 21 (C.)
http://huanqiuzhibo.cn/manifest/douyu.php?id=9650887

#EXTINF:-1 tvg-id="CHN" tvg-id= tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 22 (C.)
http://huanqiuzhibo.cn/manifest/douyu.php?id=310926

#EXTINF:-1 tvg-id="CHN" tvg-id= tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 23 (C.F)
http://huanqiuzhibo.cn/manifest/douyu.php?id=315457

#EXTINF:-1 tvg-id="CHN" tvg-id= tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 24 (C.H)
http://huanqiuzhibo.cn/manifest/douyu.php?id=5033502

#EXTINF:-1 tvg-id="CHN" tvg-id= tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 25 (C.)
http://huanqiuzhibo.cn/manifest/douyu.php?id=5423

#EXTINF:-1 tvg-id="CHN" tvg-id= tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 26 (C.)
http://huanqiuzhibo.cn/manifest/douyu.php?id=9275635

#EXTINF:-1 tvg-id="CHN" tvg-id= tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 27 (C.J)
http://huanqiuzhibo.cn/manifest/douyu.php?id=6763930

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 28 (C.)
http://huanqiuzhibo.cn/manifest/douyu.php?id=7253343

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 29 (C.)
http://huanqiuzhibo.cn/manifest/douyu.php?id=8603174

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 30 (C.H)
http://huanqiuzhibo.cn/manifest/douyu.php?id=7356023

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 31 (P)
http://huanqiuzhibo.cn/manifest/douyu.php?id=8945323

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 32 (P.I.M)
http://huanqiuzhibo.cn/manifest/douyu.php?id=252802

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 33 (P.)
http://huanqiuzhibo.cn/manifest/douyu.php?id=4332

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 34 (P)
http://huanqiuzhibo.cn/manifest/douyu.php?id=263824

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 35 (P)
http://huanqiuzhibo.cn/manifest/douyu.php?id=20415

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 36 (P)
http://huanqiuzhibo.cn/manifest/douyu.php?id=1504768

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 37 (P.J.B)
http://huanqiuzhibo.cn/manifest/douyu.php?id=9292499

#EXTINF:-1 tvg-id= tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 38 (P)
http://huanqiuzhibo.cn/manifest/douyu.php?id=7882691

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 39 (P)
http://huanqiuzhibo.cn/manifest/douyu.php?id=248753

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/K6nmVFp/download-2.png" group-title="DOUYU_MOVIES",MOVIES MIX 40 (P)
http://huanqiuzhibo.cn/manifest/douyu.php?id=7575350




#######################################################################################################################################################################

#########################






#EXTINF:-1 tvg-id="CHN" tvg-name="" group-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="DOCUMENTARY",SILA KLIK DAN BACA!!
https://tinyurl.com/sila-baca-la-oii

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="DOCUMENTARY",VISIT MY SHOP 
https://tinyurl.com/visit-kedai-saya




#EXTINF:-1 tvg-id="AnimalPlanetMalaysia.my" group-title="DOCUMENTARY" tvg-logo="https://api.discovery.com/v1/images/5bc91c366b66d1494068339e?aspectRatio=1x1&width=192&key=3020a40c2356a645b4b4" ch-number="556",Animal Planet (MY)
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2710
http://linearjitp-playback.astro.com.my/dash-wv/linear/2710/default_primary.mpd

#EXTINF:-1 tvg-id="AnimalPlanetSoutheastAsia.sg" group-title="DOCUMENTARY" tvg-logo="https://api.discovery.com/v1/images/5bc91c366b66d1494068339e?aspectRatio=1x1&width=192&key=3020a40c2356a645b4b4",Animal Planet (ID)
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MzRjOGRhNmItM2ZmNi0zMGIwLWI1NTEtM2ViNjlhZmM2NWU0
#EXTVLCOPT:http-referrer=http://www.astro.com.my
https://av-live-cdn.mncnow.id/live/eds/AnimalPlanet/sa_dash_vmx/AnimalPlanet.mpd

#EXTINF:-1 tvg-id="DiscoveryChannelIndonesia.id" group-title="DOCUMENTARY" tvg-logo="https://i.postimg.cc/PxgShYg2/Discovery-White.png" ch-number="552",Discovery Channel (MY)
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2510
http://linearjitp-playback.astro.com.my/dash-wv/linear/2510/default_primary.mpd

#EXTINF:-1 tvg-id="DiscoveryChannelIndonesia.id" group-title="DOCUMENTARY" tvg-logo="https://api.discovery.com/v1/images/5ca22512d1b3ee5361260d00?aspectRatio=1x1&width=192&key=3020a40c2356a645b4b4",Discovery Channel (ID)
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MzRjOGRhNmItM2ZmNi0zMGIwLWI1NTEtM2ViNjlhZmM2NWU0
#EXTVLCOPT:http-referrer=http://www.astro.com.my
https://av-live-cdn.mncnow.id/live/eds/Discovery/sa_dash_vmx/Discovery.mpd

#EXTINF:-1 tvg-id="DiscoveryTurboUK.uk" tvg-logo="https://s6.gifyu.com/images/imagecd8ecb4abf754cde.png" group-title="DOCUMENTARY", Discovery Turbo 
https://cdn-apse1-prod.tsv2.amagi.tv/linear/amg01448-samsungin-turboin-samsungin/f4af20b4-be04-4f91-b4e0-33b7b43b2f7e/2.m3u8
http://jessicatv.site:8080/one-day-test-89fc/54CbToqS2c/1114

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ar.tvgratis.live/arkey/Discovery_Science.json
#EXTINF:-1 tvg-id="DiscoveryScienceUK.uk" tvg-logo="https://www.lyngsat.com/logo/tv/dd/discovery-science-europe-us.png" group-title="DOCUMENTARY",Discovery Science
https://cdn.cvattv.com.ar/live/c6eds/Discovery_Science/SA_Live_dash_enc_2A/Discovery_Science.mpd
# http://jessicatv.site:8080/one-day-test-89fc/54CbToqS2c/713

#EXTINF:-1 tvg-id="DiscoveryAsia.sg" group-title="DOCUMENTARY" tvg-logo="https://user-images.githubusercontent.com/85995579/130942415-16993653-9ed9-4c56-97fd-d92dc328b31f.png" ch-number="553",Discovery Asia
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/501
https://linearjitp-playback.astro.com.my/dash-wv/linear/501/default_ott.mpd

#EXTINF:-1 tvg-id="HistoryAsia.us" group-title="DOCUMENTARY" tvg-logo="https://poster.starhubgo.com/Linear_channels2/401_1920x1080_HTV.png" ch-number="555",History (MY)
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/604
http://linearjitp-playback.astro.com.my/dash-wv/linear/604/default_ott.mpd

#EXTINF:-1 tvg-id="HistoryAsia.us" group-title="DOCUMENTARY" tvg-logo="https://poster.starhubgo.com/Linear_channels2/401_1920x1080_HTV.png",History (ID)
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MzRjOGRhNmItM2ZmNi0zMGIwLWI1NTEtM2ViNjlhZmM2NWU0
#EXTVLCOPT:http-referrer=http://www.astro.com.my
https://av-live-cdn.mncnow.id/live/eds/History/sa_dash_vmx/History.mpd

#EXTINF:-1 tvg-id="CrimePlusInvestigationAsia.sg" group-title="DOCUMENTARY" tvg-logo="https://poster.starhubgo.com/Linear_channels2/403_1920x1080_HTV.png" ch-number="714",Crime & Investigation (MY)
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2111
https://linearjitp-playback.astro.com.my/dash-wv/linear/2111/default_ott.mpd

#EXTINF:-1 tvg-id="CrimePlusInvestigationAsia.sg" tvg-name="CGTN" group-title="DOCUMENTARY" tvg-logo="https://poster.starhubgo.com/Linear_channels2/403_1920x1080_HTV.png",Crime & Investigation (ID)
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MzRjOGRhNmItM2ZmNi0zMGIwLWI1NTEtM2ViNjlhZmM2NWU0
#EXTVLCOPT:http-referrer=http://www.astro.com.my
https://av-live-cdn.mncnow.id/live/eds/CrimeInvestigation/sa_dash_vmx/CrimeInvestigation.mpd

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTINF:-1 tvg-id="CGTNDocumentary.cn" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/d/d6/CGTN_Documentary_logo.png" group-title="DOCUMENTARY",Cgtn Documentary (ID)
https://av-live-cdn.mncnow.id/live/eds/CGTN_Doc/sa_dash_vmx/CGTN_Doc.mpd

#EXTINF:-1 tvg-id="BBCEarthAsia.uk" group-title="DOCUMENTARY" tvg-logo="http://playtv.unifi.com.my:7039/CPS/images/universal/film/logo/201907/20190716/2019071606454895082c.png" ch-number="554",BBC Earth (MY)
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5051
https://linearjitp-playback.astro.com.my/dash-wv/linear/5051/default_primary.mpd

#EXTINF:-1 tvg-id="BBCEarthAsia.uk" group-title="DOCUMENTARY" tvg-logo="http://playtv.unifi.com.my:7039/CPS/images/universal/film/logo/201907/20190716/2019071606454895082c.png",BBC Earth (ID)
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTVLCOPT:http-referrer=http://www.astro.com.my
https://av-live-cdn.mncnow.id/live/eds/BBCEarth-HD/sa_dash_vmx/BBCEarth-HD.mpd

#EXTINF:-1 tvg-id="BBCLifestyleAsia.uk" ch-number="717" group-title="DOCUMENTARY" tvg-logo="http://playtv.unifi.com.my:7039/CPS/images/universal/film/logo/201907/20190716/20190716064944437peu.png",BBC Lifestyle (MY)
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5050
https://linearjitp-playback.astro.com.my/dash-wv/linear/5050/default_primary.mpd

#EXTINF:-1 tvg-id="717" group-title="DOCUMENTARY" tvg-logo="http://playtv.unifi.com.my:7039/CPS/images/universal/film/logo/201907/20190716/20190716064944437peu.png",BBC Lifestyle (VN)
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36 Edge/12.246
https://livecdn.fptplay.net/sdb/bbclifestyle_2000.stream/chunklist_b2500000.m3u8

#EXTINF:-1 tvg-id="502" tvg-name="Love Nature HD" group-title="DOCUMENTARY" tvg-logo="https://poster.starhubgo.com/Linear_channels2/416_1920x1080_HTV.png",Love Nature 
http://bamus-eng-roku.amagi.tv/playlist720lp.m3u8?checkedby:iptvcat.com

#EXTINF:-1 tvg-logo="https://i.ibb.co/kMSqd9f/504-5041014-transparent-background-wild-earth-calligraphy-hd-png-download.png" group-title="DOCUMENTARY",Wild Earth
https://wildearth-roku.amagi.tv/masterR1080p.m3u8

#EXTINF:-1 tvg-id="NationalGeographicMalaysia.my" group-title="DOCUMENTARY" tvg-logo="http://aqfad.xtgem.com/images/NatGeo.png" ch-number="551",National Geographic (MY)
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/600
http://linearjitp-playback.astro.com.my/dash-wv/linear/600/default_primary.mpd

#EXTINF:-1 tvg-id="NationalGeographicIndonesia.id" tvg-name="National Geographic HD" group-title="DOCUMENTARY" tvg-logo="http://playtv.unifi.com.my:7039/CPS/images/universal/film/logo/201907/20190716/20190716065651397ki2.png",National Geographic (ID)
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTVLCOPT:http-referrer=http://www.astro.com.my
https://av-live-cdn.mncnow.id/live/eds/NatGeoChannel/sa_dash_vmx/NatGeoChannel.mpd

#EXTINF:-1 tvg-id="NationalGeographicWildMalaysia.my" group-title="DOCUMENTARY" tvg-logo="http://aqfad.xtgem.com/images/NatGeoWild.png" ch-number="550",National Geographic Wild (MY)
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2103
http://linearjitp-playback.astro.com.my/dash-wv/linear/2103/default_primary.mpd

#EXTINF:-1 tvg-id="NationalGeographicWildIndonesia.id" tvg-name="Nat Geo Wild HD" group-title="DOCUMENTARY" tvg-logo="http://tvmalaysia.cc:80/images/974fd3251e5b8259b967eacd5d21f59d.png",National Geographic Wild (ID)
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTVLCOPT:http-referrer=http://www.astro.com.my
https://av-live-cdn.mncnow.id/live/eds/NatGeoWild/sa_dash_vmx/NatGeoWild.mpd

#EXTINF:-1 tvg-id="" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/7/75/OC_Logo2017_Primary_REV.svg/revision/latest/scale-to-width-down/185?cb=20170428060444" group-title="DOCUMENTARY",Outdoor Channel
https://outdoorchannel-samsungau.amagi.tv/playlist720p.m3u8

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTINF:-1 tvg-id="NHKWorldJapan.jp" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/8/8d/NHK_World-Japan_TV.svg/1280px-NHK_World-Japan_TV.svg.png" group-title="DOCUMENTARY",NHK World Japan
https://av-live-cdn.mncnow.id/live/eds/NHKWorldTV/sa_dash_vmx/NHKWorldTV.mpd

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTINF:-1 tvg-id="NHKWorldPremium.jp" tvg-logo="https://nhkworldpremium.com/img/common/logo.png" group-title="DOCUMENTARY",NHK World Premium
https://av-live-cdn.mncnow.id/live/eds/NHKWorldPremium/sa_dash_vmx/NHKWorldPremium.mpd

#EXTINF:-1 tvg-logo="https://i.imgur.com/CzsBnvf.png" group-title="DOCUMENTARY",Horizon Sports
https://a.jsrdn.com/broadcast/20dc4269f3/+0000/high/c.m3u8

#EXTINF:-1 tvg-logo="https://i.imgur.com/DkvWWbE.png" group-title="DOCUMENTARY",Hunt Channel
https://1111296894.rsc.cdn77.org/LS-ATL-56868-1/index.m3u8

#EXTINF:-1 tvg-id="SmithsonianChannelUK.uk" group-title="DOCUMENTARY" tvg-logo="https://i.ibb.co/3BJwhpH/Smithsonian-Channel.png",Smithsonian Channel
https://smithsonianaus-samsungau.amagi.tv/playlist.m3u8

#EXTINF:-1 tvg-id="TravelXP(src07).in(m3u4u)" tvg-name="Travel XP" tvg-logo="https://i.imgur.com/a0aXk2W.png" group-title="DOCUMENTARY",Travel XP 

#EXTINF:-1 tvg-logo="https://i.ibb.co/VYzpvDJ/Nature-81157-2.png" group-title="DOCUMENTARY", Nature TV
https://stmv1.srvif.com/nattv/nattv/playlist.m3u8

#EXTINF:-1 tvg-logo="https://i.ibb.co/VYzpvDJ/Nature-81157-2.png" group-title="DOCUMENTARY", Viasat explore
http://iptv.prosto.tv:7000/ch85/video.m3u8

#EXTINF:-1 tvg-logo="https://i.ibb.co/7bJfM5w/good-time-cookies-logo-BECAD41-A66-seeklogo-com.png" group-title="DOCUMENTARY", Goodtime

#EXTINF:-1 tvg-logo="https://i.ibb.co/vQD6c8t/1200px-VIASAT-official-png.png" group-title="DOCUMENTARY", Viasat Nature
http://iptv.prosto.tv:7000/ch84/video.m3u8

#EXTINF:-1 tvg-logo="https://i.ibb.co/WcNZGCM/png-transparent-computer-icons-natural-environment-nature-natural-resource-coral-collection-leaf-han.png" group-title="DOCUMENTARY", Naturescape
https://stirr.ott-channels.stingray.com/naturescape/master.m3u8

#EXTINF:-1 tvg-logo="https://i.ibb.co/tCjk1hc/natural-planet-logo.png" group-title="DOCUMENTARY", Nature Live
https://stitcheraws.unreel.me/wse-node02.powr.com/live/5c9537b8932c837b49397343/playlist.m3u8




#######################################################################################################################################################################

###########################






#EXTINF:-1 tvg-id="CHN" tvg-name="" group-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="FAMILY_KIDS",SILA KLIK DAN BACA!!
https://tinyurl.com/sila-baca-la-oii

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="FAMILY_KIDS",VISIT MY SHOP 
https://tinyurl.com/visit-kedai-saya


#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=edf1a715de9748638dd2fad75a419af2:2f5a3199b26e9b693ae881af7ff864cf
#EXTINF:-1 tvg-id="AnimaxAsia.sg" tvg-name="Animax" group-title="FAMILY_KIDS" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/6/65/Animaxlogo-20160701.png",Animax (MY)
https://tglmp01.akamaized.net/out/v1/de55fad9216e4fe7ad8d2eed456ba1ec/manifest.mpd

#EXTINF:-1 tvg-id="AnimaxAsia.sg" group-title="FAMILY_KIDS" tvg-logo="https://www.animax-asia.com/sites/animax-asia.com/files/logos/animax-logo_0.png",Animax (ID)
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MzRjOGRhNmItM2ZmNi0zMGIwLWI1NTEtM2ViNjlhZmM2NWU0
#EXTVLCOPT:http-referrer=http://www.astro.com.my
https://av-live-cdn.mncnow.id/live/eds/Animax/sa_dash_vmx/Animax.mpd

#EXTVLCOPT:http-user-agent=Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTINF:-1 tvg-id="Aniplus.id" tvg-name="" group-title="FAMILY_KIDS" tvg-logo="https://i.ibb.co/98rWW4t/Aniplus-Asia-Logo.png", Aniplus
# http://axcestv.vip:8080/@harris/utEYY7kAGj/549
http://210.210.155.35/session/5a96d1bc-6a30-11e9-afe2-91cea6c769ee/dr9445/h/h02/02.m3u8
# http://jessicatv.site:8080/one-day-test-89fc/54CbToqS2c/157611

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/ypx71fv/download-3.png" group-title="FAMILY_KIDS",ConTV Anime
https://contvanime.cinedigm.com/conapp-ssai/amagi_hls_data_xumo-host-contvanime-junction/CDN/master.m3u8

#EXTINF:-1 tvg-id="AnimeAllDay.us" tvg-name="Anime All Day" tvg-logo="https://i.ibb.co/SKvN1BM/Anime-Unlimited-Logo-1200x.png" group-title="FAMILY_KIDS",Anime Alldays
https://service-stitcher.clusters.pluto.tv/stitch/hls/channel/5812b7d3249444e05d09cc49/master.m3u8?deviceId=0&deviceVersion=0&appVersion=0&deviceType=0&deviceMake=0&sid=dd4b&deviceDNT=0&deviceModel=0

#EXTINF:-1 tvg-id="5f7790b3ed0c88000720b241" tvg-name="One Piece" tvg-logo="https://i.ibb.co/qm2Qz2b/945-9451491-one-piece-official-logo.png" group-title="FAMILY_KIDS",One Piece
http://stitcher-ipv4.pluto.tv/v1/stitch/embed/hls/channel/5f7790b3ed0c88000720b241/master.m3u8?deviceType=samsung-tvplus&deviceMake=samsung&deviceModel=samsung&deviceVersion=unknown&appVersion=unknown&deviceLat=0&deviceLon=0&deviceDNT=%7BTARGETOPT%7D&deviceId=%7BPSID%7D&advertisingId=%7BPSID%7D&us_privacy=1YNY&samsung_app_domain=%7BAPP_DOMAIN%7D&samsung_app_name=%7BAPP_NAME%7D&profileLimit=&profileFloor=&embedPartner=samsung-tvplus

#EXTINF:-1 tvg-id="5da0c85bd2c9c10009370984" tvg-name="Naruto" tvg-logo="https://i.ibb.co/k89NQ92/Naruto-logo-svg.png" group-title="FAMILY_KIDS",Naruto 
http://stitcher-ipv4.pluto.tv/v1/stitch/embed/hls/channel/5da0c85bd2c9c10009370984/master.m3u8?deviceType=samsung-tvplus&deviceMake=samsung&deviceModel=samsung&deviceVersion=unknown&appVersion=unknown&deviceLat=0&deviceLon=0&deviceDNT=%7BTARGETOPT%7D&deviceId=%7BPSID%7D&advertisingId=%7BPSID%7D&us_privacy=1YNY&samsung_app_domain=%7BAPP_DOMAIN%7D&samsung_app_name=%7BAPP_NAME%7D&profileLimit=&profileFloor=&embedPartner=samsung-tvplus

#EXTINF:-1 tvg-id="5f4ec10ed9636f00089b8c89" tvg-name="Yu-Gi-Oh" tvg-logo="https://i.ibb.co/zfnjNg1/YGOSevenslogo.png" group-title="FAMILY_KIDS",YU-GI-OH
http://stitcher-ipv4.pluto.tv/v1/stitch/embed/hls/channel/5f4ec10ed9636f00089b8c89/master.m3u8?deviceType=samsung-tvplus&deviceMake=samsung&deviceModel=samsung&deviceVersion=unknown&appVersion=unknown&deviceLat=0&deviceLon=0&deviceDNT=%7BTARGETOPT%7D&deviceId=%7BPSID%7D&advertisingId=%7BPSID%7D&us_privacy=1YNY&samsung_app_domain=%7BAPP_DOMAIN%7D&samsung_app_name=%7BAPP_NAME%7D&profileLimit=&profileFloor=&embedPartner=samsung-tvplus

#EXTINF:-1 tvg-id="5c3f8f12a93c2d61b9990a4e" tvg-name="TokuSHOUTsu" tvg-logo="https://i.ibb.co/Ld66Qxj/STS-Logo-Final-Wamp-Red-Texture.png" group-title="FAMILY_KIDS",Tokushoutsu
http://stitcher-ipv4.pluto.tv/v1/stitch/embed/hls/channel/5c3f8f12a93c2d61b9990a4e/master.m3u8?deviceType=samsung-tvplus&deviceMake=samsung&deviceModel=samsung&deviceVersion=unknown&appVersion=unknown&deviceLat=0&deviceLon=0&deviceDNT=%7BTARGETOPT%7D&deviceId=%7BPSID%7D&advertisingId=%7BPSID%7D&us_privacy=1YNY&samsung_app_domain=%7BAPP_DOMAIN%7D&samsung_app_name=%7BAPP_NAME%7D&profileLimit=&profileFloor=&embedPartner=samsung-tvplus

#EXTINF:-1 tvg-id="AstroCeria.my" group-title="FAMILY_KIDS" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/7/76/Astro_Ceria_%282019%29.png/revision/latest?cb=20201018231230", Astro Ceria 
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2606
http://linearjitp-playback.astro.com.my/dash-wv/linear/2606/default_primary.mpd

#EXTINF:-1 tvg-id="AstroTutorTVUPSR.my" group-title="FAMILY_KIDS" tvg-logo="https://linear-poster.astro.com.my/prod/logo/Astro_TTV_SK.png",Astro Tutor TV SK
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5070
http://linearjitp-playback.astro.com.my/dash-wv/linear/5070/default_primary.mpd

#EXTINF:-1 tvg-id="AstroTutorTVSPM.my" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/127_144.png" group-title="FAMILY_KIDS" ch-number="602",Astro Tutor TV SPM
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/313
# http://linearjitp-playback.astro.com.my/dash-wv/linear/313/default_primary.mpd

#EXTINF:-1 tvg-id="AstroTutorTVSMK.my" tvg-logo="http://linear-poster.astro.com.my/prod/logo/Astro_TTV_SMK_v1.png" group-title="FAMILY_KIDS",Astro Tutor TV SMK
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5071
https://linearjitp-playback.astro.com.my/dash-wv/linear/5071/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=612eb711dfb444f7a194c5e20d7f7048:b6226449b9ed5066542e6d6ad5ecb346
#EXTINF:-1 group-title="FAMILY_KIDS" tvg-id="oktolidays.sg" tvg-NAME="oktolidays" tvg-logo="https://i.imgur.com/Dt0kA7e.png",oktolidays
https://tglmp03.akamaized.net/out/v1/be732843b7d24bada23e13810282e55f/manifest.mpd

#EXTINF:-1  tvg-id="ext" group-title="FAMILY_KIDS" tvg-logo="https://i.dlpng.com/static/png/6916208_preview.png",Spongebob
http://stitcher-ipv4.pluto.tv/v1/stitch/embed/hls/channel/5d00e8adaab96b5635b2a005/master.m3u8?deviceType=samsung-tvplus&deviceMake=samsung&deviceModel=samsung&deviceVersion=unknown&appVersion=unknown&deviceLat=0&deviceLon=0&deviceDNT={TARGETOPT}&deviceId={PSID}&advertisingId={PSID}&us_privacy=1YNY&samsung_app_domain={APP_DOMAIN}&samsung_app_name={APP_NAME}&profileLimit=&profileFloor=&embedPartner=samsung-tvplus

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5024
#EXTINF:-1 tvg-id="TADAA.my" tvg-logo="http://linear-poster.astro.com.my/prod/logo/TA-DAA!.png" group-title="FAMILY_KIDS",Ta-daa!
http://linearjitp-playback.astro.com.my/dash-wv/linear/5024/default_primary.mpd

#EXTINF:-1 tvg-id="Dreamworks.id" tvg-name="Dreamworks.id" tvg-logo="https://i.ibb.co/VtkJWrB/IMG-20220310-184548-327.png" group-title="FAMILY_KIDS",Dreamworks
http://hotz.vip:2082/live/haziqdanial/abc12345/438.m3u8

#EXTINF:-1 tvg-id="TotallyTurtles.us" tvg-name="TOTALLY TURTLES" tvg-logo="https://i.ibb.co/LpzDYR5/large-125783-ufrfla3cqxzase0mme6hh0jdw.jpg"  group-title="FAMILY_KIDS",Nick Totally Turtle
https://siloh.pluto.tv/lilo/production/Nick/02/master.m3u8

#EXTINF:-1 tvg-id="DoraTV.us" tvg-name="Dora TV" tvg-logo="https://i.ibb.co/QMx7GPR/Dora-the-Explorer-logo-svg.png"  group-title="FAMILY_KIDS",Nick Jr Dora Tv
https://siloh.pluto.tv/lilo/production/Nick/03/master.m3u8

#EXTINF:-1 tvg-id="MoonbugKids.uk" group-title="FAMILY_KIDS" tvg-logo="https://linear-poster.astro.com.my/prod/logo/MoonbugKids.png" ch-number="618",Moonbug Kids
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5067
http://linearjitp-playback.astro.com.my/dash-wv/linear/5067/default_primary.mpd
#https://moonbug-rokuus.amagi.tv/playlist.m3u8

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTINF:0 tvg-id="MiaoMi.hk" tvg-name="Miao Mi" tvg-logo="http://dusktill.masuk.web.id/img/miaomi.png" group-title="FAMILY_KIDS",Miaomi
https://av-live-cdn.mncnow.id/live/eds/MiaoMi/sa_dash_vmx/MiaoMi.mpd

#EXTINF:-1 tvg-id="BabyTV.uk" tvg-name="Baby TV Asia" group-title="FAMILY_KIDS" tvg-logo="https://poster.starhubgo.com/Linear_channels2/302_1920x1080_HTV.png",Baby TV HD
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MzRjOGRhNmItM2ZmNi0zMGIwLWI1NTEtM2ViNjlhZmM2NWU0
#EXTVLCOPT:http-referrer=http://www.astro.com.my
https://av-live-cdn.mncnow.id/live/eds/BabyTV-NewHD/sa_dash_vmx/BabyTV-NewHD.mpd

#EXTINF:-1 tvg-id="KidsTV.id" tvg-name="Kids TV" group-title="FAMILY_KIDS" tvg-logo="https://www.dropbox.com/s/xp3wfmhhfx8vfc4/Kids_TV_(2020).png?dl=1",Kids TV HD
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MzRjOGRhNmItM2ZmNi0zMGIwLWI1NTEtM2ViNjlhZmM2NWU0
https://av-live-cdn.mncnow.id/live/eds/KidsChannel/sa_dash_vmx/KidsChannel.mpd

#EXTINF:-1 tvg-id="CBeebiesAsia.uk" tvg-name="CBeebies Asia" group-title="FAMILY_KIDS" tvg-logo="https://poster.starhubgo.com/Linear_channels2/303_1920x1080_HTV.png",CBeebies HD
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MzRjOGRhNmItM2ZmNi0zMGIwLWI1NTEtM2ViNjlhZmM2NWU0
https://av-live-cdn.mncnow.id/live/eds/Cbeebies/sa_dash_vmx/Cbeebies.mpd

#EXTINF:-1 tvg-id="NickJrAsia.sg" group-title="FAMILY_KIDS" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/392_144.png" ch-number="617",Nick Jr (MY)
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/9982
http://linearjitp-playback.astro.com.my/dash-wv/linear/9982/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=ZWQ0NjNlZDctNzI1Yy0zY2JlLTg3N2UtOGQ0MTU5MTc0Y2Nh
#EXTINF:-1 tvg-id="NickJrAsia.sg" group-title="FAMILY_KIDS" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/392_144.png" ch-number="617",Nick Jr (ID)
https://av-live-cdn.mncnow.id/live/eds/NickJr-HDD/sa_dash_vmx/NickJr-HDD.mpd

#EXTINF:-1 tvg-id="NickelodeonAsia.sg" group-title="FAMILY_KIDS" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/370_144.png" ch-number="616",Nickelodeon (MY)
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2511
http://linearjitp-playback.astro.com.my/dash-wv/linear/2511/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=ZWQ0NjNlZDctNzI1Yy0zY2JlLTg3N2UtOGQ0MTU5MTc0Y2Nh
#EXTINF:-1 tvg-id="NickelodeonAsia.sg" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/370_144.png" group-title="FAMILY_KIDS",Nickelodeon (ID)
https://av-live-cdn.mncnow.id/live/eds/Nickelodeon/sa_dash_vmx/Nickelodeon.mpd

#EXTINF:-1 tvg-id="BoomerangSoutheastAsia.us" group-title="FAMILY_KIDS" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/430_144.png",Boomerang (MY)
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2408
http://linearjitp-playback.astro.com.my/dash-wv/linear/2408/default_primary.mpd

#EXTINF:-1 tvg-id="BoomerangSoutheastAsia.us" group-title="FAMILY_KIDS" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/430_144.png",Boomerang (ID)
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MzRjOGRhNmItM2ZmNi0zMGIwLWI1NTEtM2ViNjlhZmM2NWU0
#EXTVLCOPT:http-referrer=http://www.astro.com.my
https://av-live-cdn.mncnow.id/live/eds/Boomerang/sa_dash_vmx/Boomerang.mpd

#EXTINF:-1 tvg-logo="https://i.ibb.co/MPfHYmZ/Happy-Kids-logo-2004.png" group-title="FAMILY_KIDS",HappyKids
https://happykids-roku.amagi.tv/playlist404pl.m3u8

#EXTINF:-1 tvg-logo="https://i.ibb.co/m5b65Xh/1280px-Junior-Logo-svg.png" group-title="FAMILY_KIDS",HappyKids Junior
https://happykidsjunior-vizio.amagi.tv/playlist480p.m3u8

#EXTINF:-1 tvg-logo="https://i.ibb.co/82P2sDm/channel-tg-0-3.png" group-title="FAMILY_KIDS",Toon Googles
https://dai2.xumo.com/amagi_hls_data_xumo1212A-redboxtoongoggles/CDN/640x360_700000/index.m3u8

#EXTINF:-1 tvg-id="CartoonNetworkEast.us" tvg-name="Rick and Morty" tvg-logo="https://upload.wikimedia.org/wikipedia/en/3/32/Rick_and_Morty_opening_credits.jpeg" group-title="FAMILY_KIDS", Rick and Morty TV
https://adultswim-vodlive.cdn.turner.com/live/rick-and-morty/stream.m3u8

#EXTINF:-1 tvg-id="" tvg-name="tes" tvg-logo="https://d21tktytfo9riy.cloudfront.net/wp-content/uploads/2021/05/27151240/AB_RELOADED_202105_780x800_CharactersAndLogo-1.png" group-title="FAMILY_KIDS", Angry Bird
https://stream-us-east-1.getpublica.com/playlist.m3u8?network_id=547

#EXTINF:-1 tvg-id="ATX.jp" tvg-name="AT-X" tvg-country="JP" tvg-language="Japanese" tvg-logo="https://www.at-x.com/favicon_android.png" group-title="FAMILY_KIDS",AT-X
https://sub2.neetball.net/live/neet.m3u8

#EXTINF:-1 tvg-id="CartoonNetworkAsia.sg" group-title="FAMILY_KIDS" tvg-logo="https://poster.starhubgo.com/Linear_channels2/316_1920x1080_HTV.png",Cartoon Network (MY)
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/509
http://linearjitp-playback.astro.com.my/dash-wv/linear/509/default_primary.mpd

#EXTINF:-1 tvg-id="CartoonNetworkAsia.sg" group-title="FAMILY_KIDS" tvg-logo="https://poster.starhubgo.com/Linear_channels2/316_1920x1080_HTV.png",Cartoon Network (ID)
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MzRjOGRhNmItM2ZmNi0zMGIwLWI1NTEtM2ViNjlhZmM2NWU0
#EXTVLCOPT:http-referrer=http://www.astro.com.my
https://av-live-cdn.mncnow.id/live/eds/CartoonNetwork/sa_dash_vmx/CartoonNetwork.mpd

#EXTINF:-1 tvg-id="tiny.pop.gb" tvg-name="Tiny POP" tvg-logo="https://i.ibb.co/1QVNzk4/unnamed.png" group-title="FAMILY_KIDS",Baby Shark Tv
https://newidco-babysharktv-1-us.roku.wurl.tv/4300.m3u8

#EXTINF:-1 tvg-logo="https://i.ibb.co/gZmhhv7/images.png" group-title="FAMILY_KIDS", Lego
https://legochannel-roku.amagi.tv/playlist404-p.m3u8

#EXTINF:-1 tvg-logo="https://i.imgur.com/VFhZ3Pl.png" group-title="FAMILY_KIDS",PBS Kids
https://2-fss-2.streamhoster.com/pl_140/amlst:200914-1298290/playlist.m3u8?DVR
https://livestream.pbskids.org/out/v1/1e3d77b418ad4a819b3f4c80ac0373b5/est_127.m3u8

#EXTINF:-1 tvg-id="DisneyChannelMENA.uk" tvg-name="" tvg-logo="https://i.ibb.co/W0m2Mm9/e9f9ec56fff1032b8beb3fb84ad3e8e5.png" group-title="FAMILY_KIDS",Disney Channel
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=YWY0OTBlZjEtODAyNC0zZTA0LWFhYzMtY2ZmMGE4NjVjZjU1
#http://208.86.19.13:81/14.stream/index.m3u8 

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ar.tvgratis.live/arkey/DisneyChannelHD.json
#EXTINF:-1 tvg-id="DisneyChannelMENA.uk" tvg-logo="https://i.ibb.co/W0m2Mm9/e9f9ec56fff1032b8beb3fb84ad3e8e5.png" group-title="FAMILY_KIDS", Disney Channel
http://185.59.223.102:8080/disney/index.m3u8

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ar.tvgratis.live/arkey/DisneyJr.json
#EXTINF:-1 tvg-id="DisneyJuniorSouthAfrica.za" tvg-logo="https://i.ibb.co/yVKvfKb/1200px-Disney-Junior-svg.png" group-title="FAMILY_KIDS", Disney Junior
http://us1-external-sources.iptvserver.tv:80/kkkrkDp2a9KNwAwGzpb/QT94uK5NNQw4r4Qs/513

#EXTINF:-1 tvg-id="DisneyXD.us" tvg-name="" tvg-logo="https://i.ibb.co/QNCq51D/Logo-Disney-XD.png" group-title="FAMILY_KIDS",Disney XD
http://us1-external-sources.iptvserver.tv:80/kkkrkDp2a9KNwAwGzpb/QT94uK5NNQw4r4Qs/514

#EXTINF:-1 tvg-id="ZooMoo.sg" tvg-name="MY: ZooMoo Kids HD" tvg-logo="http://s3.i3ns.net/portal/picon/2021-12/46b7a315e1b7055504f680fd33058da5.jpg" group-title="FAMILY_KIDS",ZooMoo Kids 
https://zoomoo-samsungau.amagi.tv/playlist.m3u8





#######################################################################################################################################################################

##################




#EXTINF:-1 tvg-id="CHN" tvg-name="" group-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="NEWS",SILA KLIK DAN BACA!!
https://tinyurl.com/sila-baca-la-oii

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="NEWS",VISIT MY SHOP 
https://tinyurl.com/visit-kedai-saya

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5025
#EXTINF:-1 tvg-id="AstroAwani.my" ch-number:"AstroAwani" group-title="NEWS" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/84_144.png",Astro Awani 
http://linearjitp-playback.astro.com.my/dash-wv/linear/5025/default_ott.mpd

#EXTINF:-1 tvg-id="BernamaTV.my" ch-number="502" group-title="NEWS" tvg-logo="https://astrocontent.s3.amazonaws.com/Images/ChannelLogo/Pos/502.png",Bernama
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/1114
http://linearjitp-playback.astro.com.my/dash-wv/linear/1114/default_primary.mpd

#EXTINF:-1 tvg-id="RTMK05" tvg-name="BERITA RTM" group-title="NEWS" tvg-logo="https://berita.rtm.gov.my/images/logobes.jpg",Berita RTM
#EXTVLCOPT:http-referrer=https://rtmklik.rtm.gov.my
https://d25tgymtnqzu8s.cloudfront.net/smil:berita/chunklist_b4596000_slENG.m3u8?id=5

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=7cb90b341f444e4ca3fb60de2ed3d6e5:5640220b78729773fbeaabc19a502b50
#EXTINF:-1 group-title="NEWS" tvg-id="CNA.sg" tvg-chno="1002" tvg-logo="https://static.togglestatic.com/shain/v1/dataservice/ResizeImage/$value?Format=%27png%27&Quality=85&ImageId=%27956283%27&EntityType=%27Item%27&EntityId=%2797072%27&Width=150&Height=150&ImageUrl=%27956283.png%27&device=%27web_browser%27&subscriptions=%27Registered%27&segmentationTags=%27all%27&ResizeAction=%27fill%27&HorizontalAlignment=%27center%27&VerticalAlignment=%27top%27",Media Corp CNA
#https://tglmp03.akamaized.net/out/v1/435d5ae6f4734fde963642147a852bfb/manifest.mpd

#EXTINF:-1 tvg-id="ABCAustralia.au" group-title="NEWS" tvg-logo="https://playtv.unifi.com.my:7041/CPS/images/universal/film/logo/201907/20190716/20190716073533638c35.png" ch-number="518",ABC Australia 
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://linearjitp-playback-astro.astradamy.com/dash-ck/linear/904
https://linearjitp-playback.astro.com.my/dash-wv/linear/904/default_primary.mpd

#EXTINF:-1 tvg-id="BBCWorldNewsAsiaPacific.uk" tvg-name="BBC World News HD group-title="NEWS" tvg-logo="http://playtv.unifi.com.my:7039/CPS/images/universal/film/logo/201910/20191017/20191017092229933nmy.png",BBC World News HD
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MzRjOGRhNmItM2ZmNi0zMGIwLWI1NTEtM2ViNjlhZmM2NWU0
https://av-live-cdn.mncnow.id/live/eds/BBCWorldNews/sa_dash_vmx/BBCWorldNews.mpd

#EXTINF:-1 tvg-id="BBCWorldNewsAsiaPacific.uk" group-title="NEWS" tvg-logo="http://playtv.unifi.com.my:7039/CPS/images/universal/film/logo/201910/20191017/20191017092229933nmy.png" ch-number="512",BBC World News 
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://linearjitp-playback-astro.astradamy.com/dash-ck/linear/1008
https://linearjitp-playback.astro.com.my/dash-wv/linear/1008/default_primary.mpd

#EXTINF:-1 tvg-id="CNA" tvg-name="CNA HD" group-title="NEWS" tvg-logo="https://poster.starhubgo.com/Linear_channels2/106_1920x1080_HTV.png",Channel NewsAsia
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=ZGFkZmZkZjItYzQ1Mi0zM2RiLTk0OWQtM2M2YmY1YzZjMDNi
#https://liveanevia.mncnow.id/live/eds/ChannelNewsAsia/sa_dash_vmx/ChannelNewsAsia.mpd
#https://akamai.mncnow.id/live/eds/ChannelNewsAsia/sa_dash_vmx/ChannelNewsAsia.mpd

#EXTINF:-1 tvg-id="CNA.sg" group-title="NEWS" tvg-logo="https://poster.starhubgo.com/Linear_channels2/106_1920x1080_HTV.png" ch-number="515",CNA 
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://linearjitp-playback-astro.astradamy.com/dash-ck/linear/605
https://linearjitp-playback.astro.com.my/dash-wv/linear/605/default_primary.mpd

#EXTINF:-1 tvg-id="CNNInternationalAsiaPacific.hk" tvg-name="CNN HD" group-title="NEWS" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/336_144.png",CNN
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MzRjOGRhNmItM2ZmNi0zMGIwLWI1NTEtM2ViNjlhZmM2NWU0
#EXTVLCOPT:http-referrer=http://www.astro.com.my
#https://liveanevia.mncnow.id/live/eds/CNNInternational/sa_dash_vmx/CNNInternational.mpd

#EXTINF:-1 tvg-id="CNNInternationalAsiaPacific.hk" ch-number="511" group-title="NEWS" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/336_144.png",CNN 
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2503
http://linearjitp-playback.astro.com.my/dash-wv/linear/2503/default_primary.mpd

#EXTINF:-1 tvg-id="FoxNewsChannel.us" group-title="NEWS" tvg-logo="https://poster.starhubgo.com/Linear_channels2/702_1920x1080_HTV.png",Fox News Channel
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MzRjOGRhNmItM2ZmNi0zMGIwLWI1NTEtM2ViNjlhZmM2NWU0
https://av-live-cdn.mncnow.id/live/eds/FoxNews/sa_dash_vmx/FoxNews.mpd 

#EXTINF:-1 tvg-id="CNBCAsia.sg" group-title="NEWS" tvg-logo="https://i.postimg.cc/76CXD57r/CNBCAsia.png" ch-number="516",CNBC Asia 
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/900
http://linearjitp-playback.astro.com.my/dash-wv/linear/900/default_primary.mpd

#EXTINF:-1 tvg-id="CNBCAsia.sg" tvg-name="CNBC Asia" group-title="NEWS" tvg-logo="https://poster.starhubgo.com/Linear_channels2/707_1920x1080_HTV.png",CNBC Asia
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MzRjOGRhNmItM2ZmNi0zMGIwLWI1NTEtM2ViNjlhZmM2NWU0
https://av-live-cdn.mncnow.id/live/eds/CNBC/sa_dash_vmx/CNBC.mpd

#EXTINF:-1 tvg-id="Euronews" group-title="NEWS" tvg-logo="http://playtv.unifi.com.my:7039/CPS/images/universal/film/logo/201907/20190716/20190716073656571ojy.png",Euronews
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=ZGFkZmZkZjItYzQ1Mi0zM2RiLTk0OWQtM2M2YmY1YzZjMDNi
https://av-live-cdn.mncnow.id/live/eds/EuroNews/sa_dash_vmx/EuroNews.mpd

#EXTINF:-1 tvg-id="DWEnglish.de" tvg-name="DW English" group-title="NEWS" tvg-logo="http://playtv.unifi.com.my:7039/CPS/images/universal/film/logo/201907/20190716/201907160734540687tu.png",DW
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=ZGFkZmZkZjItYzQ1Mi0zM2RiLTk0OWQtM2M2YmY1YzZjMDNi
EXTVLCOPT:http-referrer=http://www.astro.com.my
https://av-live-cdn.mncnow.id/live/eds/DW/sa_dash_vmx/DW.mpd

#EXTINF:-1 tvg-id="France24English.fr" tvg-name="France24" group-title="NEWS" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/6/65/FRANCE_24_logo.svg/240px-FRANCE_24_logo.svg.png",France 24
EXTVLCOPT:http-referrer=http://www.astro.com.my
https://mediahomes.github.io/assets/yt/france24.m3u8|Referer=https://www.youtube.com

#EXTINF:-1 tvg-id="BloombergTVAsia.hk" tvg-name="Bloomberg TV HD" group-title="NEWS" tvg-logo="https://poster.starhubgo.com/Linear_channels2/708_1920x1080_HTV.png",Bloomberg 
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=ZGFkZmZkZjItYzQ1Mi0zM2RiLTk0OWQtM2M2YmY1YzZjMDNi
#EXTVLCOPT:http-referrer=http://www.astro.com.my
#https://liveanevia.mncnow.id/live/eds/Bloomberg/sa_dash_vmx/Bloomberg.mpd
#https://akamai.mncnow.id/live/eds/Bloomberg/sa_dash_vmx/Bloomberg.mpd
#https://cdn-videos.akamaized.net/btv/desktop/fastly/asia/live/primary.m3u8

#EXTINF:-1 tvg-id="BloombergTVAsia.hk" group-title="NEWS" tvg-logo="https://poster.starhubgo.com/Linear_channels2/708_1920x1080_HTV.png" ch-number="517",Bloomberg 
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://linearjitp-playback-astro.astradamy.com/dash-ck/linear/5020
https://linearjitp-playback.astro.com.my/dash-wv/linear/5020/default_primary.mpd

#EXTINF:-1 tvg-id="CGTN.cn" ch-number="503" group-title="NEWS" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/8/81/CGTN.svg/2560px-CGTN.svg.png",CGTN 
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5019
http://linearjitp-playback.astro.com.my/dash-wv/linear/5019/default_primary.mpd
#https://live.cgtn.com/1000/prog_index.m3u8

#EXTINF:-1 tvg-id="SkyNews.uk" group-title="NEWS" tvg-logo="https://poster.starhubgo.com/Linear_channels2/703_1920x1080_HTV.png" ch-number="514",Sky News
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2102
http://linearjitp-playback.astro.com.my/dash-wv/linear/2102/default_primary.mpd
#https://skynews2-plutolive-vo.akamaized.net/cdhlsskynewsamericas/1013/latest.m3u8

#EXTINF:-1 tvg-id="TRTWorld" group-title="NEWS" tvg-logo="https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/TRT_World_logo.svg/800px-TRT_World_logo.svg.png",TRT World
https://tv-trtworld.live.trt.com.tr/master_720.m3u8

#EXTINF:-1 tvg-id="AlJazeeraEnglish.qa" group-title="NEWS" tvg-logo="https://astrocontent.s3.amazonaws.com/Images/ChannelLogo/Pos/533.png" ch-number="513",Al Jazeera English 
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2110
https://linearjitp-playback.astro.com.my/dash-wv/linear/2110/default_primary.mpd
#https://live-hls-web-aje.getaj.net/AJE/02.m3u8





#######################################################################################################################################################################

######################



#EXTINF:-1 tvg-id="CHN" tvg-name="" group-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="RELAXING",SILA KLIK DAN BACA!!
https://tinyurl.com/sila-baca-la-oii

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="RELAXING",VISIT MY SHOP 
https://tinyurl.com/visit-kedai-saya

#EXTINF:-1 tvg-id="CHN"  tvg-logo="https://i.ibb.co/Ks5pZ54/669-6691661-new-travel-peeps-travel-agency-logo-png-transparent.jpg" group-title="RELAXING",Beaches Live
https://stitcheraws.unreel.me/wse-node02.powr.com/live/5c95396f932c837b49397360/playlist.m3u8

#EXTINF:-1 tvg-id="CHN"  tvg-logo="https://i.ibb.co/Ks5pZ54/669-6691661-new-travel-peeps-travel-agency-logo-png-transparent.jpg" group-title="RELAXING",Mountains Live
https://stitcheraws.unreel.me/wse-node02.powr.com/live/5c95387b932c837b49397357/playlist.m3u8

#EXTINF:-1 tvg-id="CHN"  tvg-logo="https://i.ibb.co/Ks5pZ54/669-6691661-new-travel-peeps-travel-agency-logo-png-transparent.jpg" group-title="RELAXING",Rivers Live
https://stitcheraws.unreel.me/wse-node02.powr.com/live/5c95388f932c837b4939735a/playlist.m3u8

#EXTINF:-1 tvg-id="CHN"  tvg-logo="https://i.ibb.co/Ks5pZ54/669-6691661-new-travel-peeps-travel-agency-logo-png-transparent.jpg" group-title="RELAXING",Tropics Live
https://stitcheraws.unreel.me/wse-node02.powr.com/live/5c9538b9932c837b4939735c/playlist.m3u8

#EXTINF:-1 tvg-id="CHN"  tvg-logo="https://i.ibb.co/Ks5pZ54/669-6691661-new-travel-peeps-travel-agency-logo-png-transparent.jpg" group-title="RELAXING",Lakes Live
https://stitcheraws.unreel.me/wse-node02.powr.com/live/5c95385c932c837b49397356/playlist.m3u8

#EXTINF:-1 tvg-id="CHN"  tvg-logo="https://i.ibb.co/Ks5pZ54/669-6691661-new-travel-peeps-travel-agency-logo-png-transparent.jpg" group-title="RELAXING",Animals Live
https://stitcheraws.unreel.me/wse-node02.powr.com/live/5c9537b8932c837b49397343/playlist.m3u8

#EXTINF:-1 tvg-id="CHN"  tvg-logo="https://i.ibb.co/Ks5pZ54/669-6691661-new-travel-peeps-travel-agency-logo-png-transparent.jpg" group-title="RELAXING",Forests Live
https://stitcheraws.unreel.me/wse-node02.powr.com/live/5c953836932c837b49397355/playlist.m3u8

#EXTINF:-1 tvg-id="CHN"  tvg-logo="https://i.ibb.co/Ks5pZ54/669-6691661-new-travel-peeps-travel-agency-logo-png-transparent.jpg" group-title="RELAXING",Sunsets Live
https://stitcheraws.unreel.me/wse-node02.powr.com/live/5c9538a5932c837b4939735b/playlist.m3u8

#EXTINF:-1 tvg-id="CHN"  tvg-logo="https://i.ibb.co/Ks5pZ54/669-6691661-new-travel-peeps-travel-agency-logo-png-transparent.jpg" group-title="RELAXING",Aurora Live
https://stitcheraws.unreel.me/wse-node02.powr.com/live/5c953819932c837b49397345/playlist.m3u8

#EXTINF:-1 tvg-id="CHN"  tvg-logo="https://i.ibb.co/Ks5pZ54/669-6691661-new-travel-peeps-travel-agency-logo-png-transparent.jpg" group-title="RELAXING",Nature
http://185.57.68.33:8091/232/tracks-v1a1/index.m3u8




#######################################################################################################################################################################

#######################




#EXTINF:-1 tvg-id="CHN" tvg-name="" group-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="🏆 AFF MITSUBISHI CUP 2022",SILA KLIK DAN BACA!!
https://tinyurl.com/sila-baca-la-oii

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="🏆 AFF MITSUBISHI CUP 2022",VISIT MY SHOP 
https://tinyurl.com/visit-kedai-saya


#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/results.php?keyid=f5158194cc4044e699d0df01772f2212&key=072e611a383a2d1e3d4d8ea19e016a71
#EXTINF:-1 tvg-ID="SoccerChannel.id" group-title="🏆 AFF MITSUBISHI CUP 2022" tvg-logo="https://i.ibb.co/6BP7TRZ/AFF-Cup-2022-logo-svg.png",AFF CH01
https://tglmp04.akamaized.net/out/v1/6ec3ff8c3b5649249f9c8a6e2651195a/manifest.mpd

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTINF:-1 tvg-ID="SoccerChannel.id" group-title="🏆 AFF MITSUBISHI CUP 2022" tvg-logo="https://i.ibb.co/6BP7TRZ/AFF-Cup-2022-logo-svg.png",AFF CH02
https://av-live-cdn.mncnow.id/live/eds/soccerchannel-HD/sa_dash_vmx/soccerchannel-HD.mpd

#EXTINF:-1 tvg-ID="SoccerChannel.id" group-title="🏆 AFF MITSUBISHI CUP 2022" tvg-logo="https://i.ibb.co/6BP7TRZ/AFF-Cup-2022-logo-svg.png",AFF CH03
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/results.php?keyid=607b7d22565c4bc3b95ff6c33ce65425&key=28cc5367df666c44be4382e64af64d57
https://tglmp02.akamaized.net/out/v1/5081e069e08140c9b95f89a1659cf4dd/manifest.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5057
#EXTINF:-1 tvg-id="AstroArena2.my" tvg-logo="https://i.ibb.co/6BP7TRZ/AFF-Cup-2022-logo-svg.png" group-title="🏆 AFF MITSUBISHI CUP 2022", AFF CH04
#EXTVLCOPT:http-referrer=https://astrogo.astro.com.my
http://iptv12k.com:35461/live/80203091402/213445/13547.m3u8







#######################################################################################################################################################################

#######################





#EXTINF:-1 tvg-id="CHN" tvg-name="" group-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="SPORTS",SILA KLIK DAN BACA!!
https://tinyurl.com/sila-baca-la-oii

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="SPORTS",VISIT MY SHOP 
https://tinyurl.com/visit-kedai-saya

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="SPORTS",INFO PENGGUNAAN DNS CHANGER
#https://tinyurl.com/Guna-DNS-Changer

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://aqfadtv.xyz/clearkey/results.php?keyid=cdb834a4f2fd413a8e50d1a7170701d2&key=3d6ae85b34e8aac7488c780cea215306
#EXTINF:-1 tvg-id="CHN" group-title="SPORTS" tvg-logo="https://i.ibb.co/yq8zZwR/unnamed.png",MediaCorp MeWatch
https://tglmp04.akamaized.net/out/v1/6b351c6bf46a43d998e3f86b69cbce4f/manifest.mpd

#EXTINF:-1 tvg-id="RTMK04" tvg-name="SUKAN RTM" group-title="SPORTS" tvg-logo="https://i.ibb.co/HphXBMH/Sukan-RTM-1-April-removebg-preview.png",Sukan RTM
https://d25tgymtnqzu8s.cloudfront.net/smil:sukan/chunklist_b4596000_slENG.m3u8?id=4

#EXTINF:-1 tvg-id="AstroArena.my" tvg-name="Astro Arena HD" group-title="SPORTS" ch-number="801" tvg-logo="https://i.ibb.co/H79rWh4/arena-Telecast4-Web-modified.png",Astro Arena 
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2604
http://linearjitp-playback.astro.com.my/dash-wv/linear/2604/default_primary.mpd
# http://51.79.82.208:16058 

#KODIPROP:inputstreamaddon=inputstream.adaptive
#EXTHTTP:{"authorization":"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ3bXZlciI6Miwid21pZGZtdCI6ImFzY2lpIiwid21pZHR5cCI6MSwid21rZXl2ZXIiOjEsIndtaWRsZW4iOjUxMiwid21pZCI6Ill6QmhNekEwTmprdE9XWTNZeTAwTW1JekxUZzBPR0l0TVRKaE5UQmtPV1F3Wm1RMyIsIndtb3BpZCI6MzIsImV4cCI6MTY3MjMxOTQxMCwiaWF0IjoxNjcyMTQ2NjEwfQ.Gue6lPcwE45s7CaopTkPVetD3DDceuwW5KBHr8vLtZA"}
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/sooka/arena2/
#EXTINF:-1 group-logo="https://telegra.ph/file/5231dea66798aba2c94b7.png" tvg-id="AstroArena2.my" group-title="SPORTS" tvg-logo="https://iili.io/1NzHut.png",Astro Arena 2 ⁽ˢᵉʳᵛᵉʳ ¹⁾
http://iptv12k.com:35461/live/80203091402/213445/13547.m3u8
# https://d2ekjg3g3mxanc.cloudfront.net/CH1/masterCH1.mpd

#EXTINF:-1 group-logo="https://telegra.ph/file/5231dea66798aba2c94b7.png" tvg-id="AstroArena2.my" group-title="SPORTS" tvg-logo="https://iili.io/1NzHut.png",Astro Arena 2 ⁽ˢᵉʳᵛᵉʳ ²⁾
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
http://kmkus.wanicelife.com:8880/live/12m0390043/17783455/1723.m3u8/71102.m3u8
# http://abc123.digital:8080/langley.es@gmail.com/5mjLL7evXh/485573
# https://dukuntv.my.id/57337005c17a518a3cee71d5170f05210698fd0b11a8f77733c08de39ab09ac67652ce68-78a50d92c806e206e634451643a7d8bf-1660653338-1660642539/olahraga/astroarena2

#EXTINF:-1 tvg-id="AstroSuperSport.my" tvg-name="Astro SuperSport HD" group-title="SPORTS" tvg-logo="https://i.ibb.co/FKbFB4W/Desain-tanpa-judul-4-modified.png",Astro SuperSport 1 ⁽ˢᵉʳᵛᵉʳ ¹⁾
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/601
https://staging-linearjitp-playback.astro.com.my/dash-wv/linear/601/default_primary.mpd
# http://139.99.96.163:2095/live/User39281/UDnAlgqObgx/149.ts

#EXTINF:-1 tvg-id="AstroSuperSport.my" tvg-name="Astro SuperSport HD" group-title="SPORTS" tvg-logo="https://i.ibb.co/FKbFB4W/Desain-tanpa-judul-4-modified.png",Astro SuperSport 1 ⁽ˢᵉʳᵛᵉʳ ²⁾
https://webdi.openhd.lol/ddy1/premium123/index.m3u8|referer=https://streamservicehd.click/

#EXTINF:-1 tvg-id="AstroSuperSport.my" tvg-name="Astro SuperSport HD" group-title="SPORTS" tvg-logo="https://i.ibb.co/FKbFB4W/Desain-tanpa-judul-4-modified.png",Astro SuperSport 1 ⁽ˢᵉʳᵛᵉʳ ³⁾
http://31.220.3.170/play/live.php?mac=00:1a:79:b2:b7:90&stream=115615&extension=ts

#EXTINF:-1 tvg-id="AstroSuperSport2.my" tvg-name="Astro SuperSport 2 HD" group-title="SPORTS" tvg-logo="https://i.ibb.co/RCTSn6n/Desain-tanpa-judul-5-modified.png",Astro SuperSport 2 ⁽ˢᵉʳᵛᵉʳ ¹⁾
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2104
https://linearjitp-playback.astro.com.my/dash-wv/linear/2104/default_ott.mpd
https://aqfadtv.xyz/live/supersport2/index.mpd

#EXTINF:-1 tvg-id="AstroSuperSport2.my" tvg-name="Astro SuperSport 2 HD" group-title="SPORTS" tvg-logo="https://i.ibb.co/RCTSn6n/Desain-tanpa-judul-5-modified.png",Astro SuperSport 2 ⁽ˢᵉʳᵛᵉʳ ²⁾
https://webdi.openhd.lol/ddy1/premium124/index.m3u8|referer=https://streamservicehd.click/

#EXTINF:-1 tvg-id="AstroSuperSport2.my" tvg-name="Astro SuperSport 2 HD" group-title="SPORTS" tvg-logo="https://i.ibb.co/RCTSn6n/Desain-tanpa-judul-5-modified.png",Astro SuperSport 2 ⁽ˢᵉʳᵛᵉʳ ³⁾
http://server.sibfungold.info:8080/naasiptv/gutNC1gKgm/52860

#EXTINF:-1 tvg-id="AstroSuperSport3.my" tvg-name="Astro SuperSport 3 HD" group-title="SPORTS" tvg-logo="https://i.ibb.co/N9BVfKB/Desain-tanpa-judul-6-modified.png",Astro SuperSport 3 ⁽ˢᵉʳᵛᵉʳ ¹⁾
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2701
https://linearjitp-playback.astro.com.my/dash-wv/linear/2701/default_ott.mpd
# https://aqfadtv.xyz/live/supersport3/index.mpd

#EXTINF:-1 tvg-id="AstroSuperSport3.my" tvg-name="Astro SuperSport 3 HD" group-title="SPORTS" tvg-logo="https://i.ibb.co/N9BVfKB/Desain-tanpa-judul-6-modified.png",Astro SuperSport 3 ⁽ˢᵉʳᵛᵉʳ ²⁾
https://webdi.openhd.lol/ddy1/premium125/index.m3u8|referer=https://streamservicehd.click/

#EXTINF:-1 tvg-id="AstroSuperSport3.my" tvg-name="Astro SuperSport 3 HD" group-title="SPORTS" tvg-logo="https://i.ibb.co/N9BVfKB/Desain-tanpa-judul-6-modified.png",Astro SuperSport 3 ⁽ˢᵉʳᵛᵉʳ ³⁾
http://server.sibfungold.info:8080/naasiptv/gutNC1gKgm/52861

#EXTINF:-1 tvg-id="AstroSuperSport4.my" tvg-name="Astro SuperSport 4 HD" group-title="SPORTS" tvg-logo="https://i.ibb.co/tKj8ZG9/Desain-tanpa-judul-7-modified.png",Astro SuperSport 4 ⁽ˢᵉʳᵛᵉʳ ¹⁾
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2506
https://linearjitp-playback.astro.com.my/dash-wv/linear/2506/default_ott.mpd
# https://aqfadtv.xyz/live/supersport4/index.mpd

#EXTINF:-1 tvg-id="AstroSuperSport4.my" tvg-name="Astro SuperSport 4 HD" group-title="SPORTS" tvg-logo="https://i.ibb.co/tKj8ZG9/Desain-tanpa-judul-7-modified.png",Astro SuperSport 4 ⁽ˢᵉʳᵛᵉʳ ²⁾
https://webdi.openhd.lol/ddy1/premium126/index.m3u8|referer=https://streamservicehd.click/

#EXTINF:-1 tvg-id="AstroSuperSport4.my" tvg-name="Astro SuperSport 4 HD" group-title="SPORTS" tvg-logo="https://i.ibb.co/tKj8ZG9/Desain-tanpa-judul-7-modified.png",Astro SuperSport 4 ⁽ˢᵉʳᵛᵉʳ ³⁾
http://server.sibfungold.info:8080/naasiptv/gutNC1gKgm/52862

#KODIPROP:inputstreamaddon=inputstream.adaptive
#EXTHTTP:{"authorization":"Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ3bXZlciI6Miwid21pZGZtdCI6ImFzY2lpIiwid21pZHR5cCI6MSwid21rZXl2ZXIiOjEsIndtaWRsZW4iOjUxMiwid21pZCI6Ill6QmhNekEwTmprdE9XWTNZeTAwTW1JekxUZzBPR0l0TVRKaE5UQmtPV1F3Wm1RMyIsIndtb3BpZCI6MzIsImV4cCI6MTY3MjMxOTQxMCwiaWF0IjoxNjcyMTQ2NjEwfQ.Gue6lPcwE45s7CaopTkPVetD3DDceuwW5KBHr8vLtZA"}
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={ "keys":[ { "kty":"oct", "k":"x56Rb533occYBeOc2jDZOw", "kid":"n5n/otJ6TPugW4O5HbhG3w" } ], "type":"temporary" }
#EXTINF:-1 group-logo="https://i.ibb.co/dGvfNvs/Desain-tanpa-judul-8-modified.png" tvg-id="AstroSuperSport5.my" group-title="SPORTS" tvg-logo="https://iili.io/1N10rP.png",Astro Supersport 5 ⁽ˢᵉʳᵛᵉʳ ¹⁾
https://d3j4fjrwclc3o8.cloudfront.net/CH3/masterCH3.mpd

#EXTINF:-1 tvg-id="AstroSuperSport5.my" tvg-name="Astro SuperSport 5 HD" tvg-logo="https://i.ibb.co/dGvfNvs/Desain-tanpa-judul-8-modified.png" group-title="SPORTS",Astro Supersport 5 ⁽ˢᵉʳᵛᵉʳ ²⁾ 
#EXTVLCOPT:http-referrer=https://widevine.licenses4.me/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webdi.openhd.lol/lb/premium43/index.m3u8

#EXTINF:-1 tvg-id="AstroSuperSport5.my" tvg-name="Astro SuperSport 5 HD" tvg-logo="https://i.ibb.co/dGvfNvs/Desain-tanpa-judul-8-modified.png" group-title="SPORTS",Astro Supersport 5 ⁽ˢᵉʳᵛᵉʳ ³⁾
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:101.0) Gecko/20100101 Firefox/101.0
https://anon.devds.site/link.php?hash=aHR0cDovL2VzdjUubmV0OjgwL2xpdmUvVGNvbGUxLzEyMzQ1Njc4OS84NzI5OC50cw==

#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={ "keys":[ { "kty":"oct", "k":"eupDzZPCSqmDTstJhPf9Wg", "kid":"IvvvHBzXJek5fsFkVfCCEA" } ], "type":"temporary" }
#EXTINF:-1 tvg-id="AstroUHD.my" tvg-name="Astro UHD" group-title="SPORTS" group-logo="https://telegra.ph/file/ed0787b99b8153874c7e1.png" tvg-logo="https://telegra.ph/file/b9cd859a14c1c4ba3c9e8.png",Astro Supersport UHD 
https://linearjitp-playback.astro.com.my/dash-wv/linear/1601/default.mpd

#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={ "keys":[ { "kty":"oct", "k":"473tG0sQVZqoUYfT8Q7j5Q", "kid":"zvSjslnxOys/SiV06IsCEA" } ], "type":"temporary" }
#EXTINF:-1 tvg-id="AstroUHD.my" tvg-name="ASSP UHD 2" group-title="AstroGO" group-logo="https://telegra.ph/file/ed0787b99b8153874c7e1.png" tvg-logo="https://telegra.ph/file/b9cd859a14c1c4ba3c9e8.png", (OFF) Astro Supersport UHD 
# https://linearjitp-playback.astro.com.my/dash-wv/linear/1602/default.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/9989
#EXTINF:-1 tvg-name="AOTGLive1" ch-number="806" group-title="SPORTS" tvg-logo="https://i.ibb.co/xJ2dQxX/png-transparent-astro-box-office-malaysia-television-logo-tariffs-canada-purple-television-violet.png",Astro GO Live Event 1 
https://linearjitp-playback.astro.com.my/dash-wv/linear/9989/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/9988
#EXTINF:-1 tvg-name="AOTGLive2" ch-number="807" group-title="SPORTS" tvg-logo="https://i.ibb.co/xJ2dQxX/png-transparent-astro-box-office-malaysia-television-logo-tariffs-canada-purple-television-violet.png",Astro GO Live Event 2 
https://linearjitp-playback.astro.com.my/dash-wv/linear/9988/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/9987
#EXTINF:-1 tvg-name="AOTGLive3" ch-number="808" group-title="SPORTS" tvg-logo="https://i.ibb.co/xJ2dQxX/png-transparent-astro-box-office-malaysia-television-logo-tariffs-canada-purple-television-violet.png",Astro Go Live Event 3 
https://linearjitp-playback.astro.com.my/dash-wv/linear/9987/default_primary.mpd

#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2504
#EXTINF:-1 tvg-id="AstroCricket.my" tvg-name="Astro Cricket HD" group-title="SPORTS" group-logo="https://telegra.ph/file/ed0787b99b8153874c7e1.png" tvg-logo="https://iili.io/1Nz0AP.png",Astro Cricket 
https://linearjitp-playback.astro.com.my/dash-wv/linear/2504/default.mpd

#EXTINF:-1 tvg-name="Unifi Sports 1" tvg-id="live1.id" group-title="SPORTS" tvg-logo="https://i.ibb.co/ygy2s59/1280px-Unifi-logo-2017.png",Unifi Sports 1
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTVLCOPT:http-referrer=http://www.unifi_en.com.my
https://unifi-live05.secureswiftcontent.com/UnifiHD/live11.mpd

#EXTINF:-1 tvg-name="Unifi Sports 2" tvg-id="live1.id" group-title="SPORTS" tvg-logo="https://i.ibb.co/ygy2s59/1280px-Unifi-logo-2017.png",Unifi Sports 2
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTVLCOPT:http-referrer=http://www.unifi_en.com.my
https://unifi-live05.secureswiftcontent.com/UnifiHD/live12.mpd

#EXTINF:-1 tvg-id="live1.id" tvg-name="ESPN" group-title="SPORTS" tvg-logo="https://i.imgur.com/4zbQAOF.png", Espn 1
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","kid":"3u8YkCg2Qyq4F9gDysKCzw","k":"hnR8vkUi6d40SemeZSk36w"}]}
https://cdsvideolive3.solocoo.tv/blueskycdslive7dash/blueespn/Manifest.mpd|User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0"

#EXTINF:-1 tvg-id="live1.id" tvg-name="ESPN2" group-title="SPORTS" tvg-logo="https://i.imgur.com/OHR99lF.png", Espn 2
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","kid":"UuL4gVTLTb2gi0bjnUCHOw","k":"vLmElGNndf_YHACNulyNrg"}]}
https://cdsvideolive3.solocoo.tv/blueskycdslive7dash/blueespn2/Manifest.mpd|User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0"

#EXTINF:-1 tvg-id="live1.id" tvg-name="ESPN3" group-title="SPORTS" tvg-logo="https://i.imgur.com/Nwk5HID.png", Espn 3
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","kid":"ZZ38nxVrTZmi1s9nd79o_g","k":"Kvoqg1lA6le3KlCpYvGf2w"}]}
https://cdsvideolive3.solocoo.tv/blueskycdslive7dash/blueespn3/Manifest.mpd|User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0"

#EXTINF:-1 tvg-id="DAZN1Spain.es" group-title="SPORTS" tvg-logo="https://i.ibb.co/j60Nb0p/DAZN-sports-modified.png", Dazn 1 Es
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 6.3; WOW64; rv:31.0) Gecko/20011101 Firefox/31.0
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=cfb5e2b73bef4f3c878f25ab86a7451f:0d6712bf2a84edcc93d001a9613f6fec
https://dce-fs-live-dazn-cdn.dazn.com/dashdrm/dazn-linear-037/stream.mpd

#EXTINF:-1 tvg-id="DAZN2Spain.es" group-title="SPORTS" tvg-logo="https://i.ibb.co/j60Nb0p/DAZN-sports-modified.png", Dazn 2 Es
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 6.3; WOW64; rv:31.0) Gecko/20011101 Firefox/31.0
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=cfb5e2b73bef4f3c878f25ab86a7451f:0d6712bf2a84edcc93d001a9613f6fec
https://dce-fs-live-dazn-cdn.dazn.com/dashdrm/dazn-linear-038/stream.mpd

#EXTINF:-1 tvg-id="DAZNF1.es" group-title="SPORTS" tvg-logo="https://i.ibb.co/j60Nb0p/DAZN-sports-modified.png", Dazn F1 Es
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 6.3; WOW64; rv:31.0) Gecko/20011101 Firefox/31.0
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=cfb5e2b73bef4f3c878f25ab86a7451f:0d6712bf2a84edcc93d001a9613f6fec
https://dce-fs-live-dazn-cdn.dazn.com/dashdrm/dazn-linear-016/stream.mpd

#EXTINF:-1 tvg-id="DAZN3Spain.es" group-title="SPORTS" tvg-logo="https://i.ibb.co/j60Nb0p/DAZN-sports-modified.png",Dazn La Liga
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","k":"DWcSvyqE7cyT0AGpYT9v7A","kid":"z7XitzvvTzyHjyWrhqdFHw"}],"type":"temporary"}
https://dce-fs-live-dazn-cdn.dazn.com/dashdrm/dazn-linear-043/stream.mpd|User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0"

#EXTINF:-1 tvg-id="DAZN4Spain.es" group-title="SPORTS" tvg-logo="https://i.ibb.co/j60Nb0p/DAZN-sports-modified.png", Zona Dazn 
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","kid":"z7XitzvvTzyHjyWrhqdFHw","k":"DWcSvyqE7cyT0AGpYT9v7A"}]}
https://dce-fs-live-dazn-cdn.dazn.com/dashdrm/dazn-linear-024/stream.mpd|User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0"

#EXTINF:-1 tvg-id="DAZN1Germany.de" group-title="SPORTS" tvg-logo="https://i.ibb.co/j60Nb0p/DAZN-sports-modified.png", Dazn 1 De
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 6.3; WOW64; rv:31.0) Gecko/20011101 Firefox/31.0
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=cfb5e2b73bef4f3c878f25ab86a7451f:0d6712bf2a84edcc93d001a9613f6fec
https://dce-fs-live-dazn-cdn.dazn.com/dashdrm/dazn-linear-017/stream.mpd

#EXTINF:-1 tvg-id="DAZN2.de" group-title="SPORTS" tvg-logo="https://i.ibb.co/j60Nb0p/DAZN-sports-modified.png", Dazn 2 De
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 6.3; WOW64; rv:31.0) Gecko/20011101 Firefox/31.0
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=cfb5e2b73bef4f3c878f25ab86a7451f:0d6712bf2a84edcc93d001a9613f6fec
https://dce-fs-live-dazn-cdn.dazn.com/dashdrm/dazn-linear-018/stream.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2100
#EXTINF:-1 tvg-id="EurosportAsia.fr" tvg-logo="https://i.ibb.co/0sDKNYn/Desain-tanpa-judul-46-modified.png" group-title="SPORTS",Eurosport Asia
http://linearjitp-playback.astro.com.my/dash-wv/linear/2100/default_primary.mpd

#EXTINF:-1 tvg-id="Eurosport1.fr" group-title="SPORTS" tvg-logo="https://i.ibb.co/0sDKNYn/Desain-tanpa-judul-46-modified.png", Eurosport 1
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 6.3; WOW64; rv:31.0) Gecko/20011101 Firefox/31.0
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=cfb5e2b73bef4f3c878f25ab86a7451f:0d6712bf2a84edcc93d001a9613f6fec
https://dce-fs-live-dazn-cdn.dazn.com/dashdrm/dazn-linear-027/stream.mpd

#EXTINF:-1 tvg-id="Eurosport2.fr" group-title="SPORTS" tvg-logo="https://i.ibb.co/0sDKNYn/Desain-tanpa-judul-46-modified.png", Eurosport 2
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 6.3; WOW64; rv:31.0) Gecko/20011101 Firefox/31.0
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=cfb5e2b73bef4f3c878f25ab86a7451f:0d6712bf2a84edcc93d001a9613f6fec
https://dce-fs-live-dazn-cdn.dazn.com/dashdrm/dazn-linear-028/stream.mpd

#EXTINF:-1 tvg-id="PrimaSport1.ro" group-title="SPORTS" tvg-logo="https://i.imgur.com/7WLvHlS.png", Prima Sports 1 
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","kid":"oCg7JaBzTHKVsnW7Qq9fWg","k":"71qFVyEgFS4GTPuGJ617_g"}]}
https://m7rovideolive.solocoo.tv/blueskylivedash/bluelookplus/Manifest.mpd|User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0"

#EXTINF:-1 tvg-id="PrimaSport2.ro" group-title="SPORTS" tvg-logo="https://i.imgur.com/7WLvHlS.png", Prima Sports 2 
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","kid":"ZCeWlctvT6enGPSig8ykmw","k":"7gmZOAktoBawJuH53Dj59A"}]}
https://m7rovideolive.solocoo.tv/blueskylivedash/bluelooksport/Manifest.mpd|User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0"

#EXTINF:-1 tvg-id="PrimaSport3.ro" group-title="SPORTS" tvg-logo="https://i.imgur.com/7WLvHlS.png", Prima Sports 3 
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","kid":"8pnvm2Z2T5Kn8cR1dZ-z0A","k":"AP4q2HTk07IgXEzLDGUGyw"}]}
https://m7rovideolive.solocoo.tv/blueskylive2dash/bluelooksport3ro/Manifest.mpd|User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0"

#EXTINF:-1 tvg-id="PrimaSport4.ro" group-title="SPORTS" tvg-logo="https://i.imgur.com/7WLvHlS.png", Prima Sports 4 
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","kid":"NtxA4MrbQ46sHx9_Ic9PYQ","k":"uukDyDKMpkYiTrs8FsJZ4Q"}]}
https://m7rovideolive.solocoo.tv/blueskylive2dash/bluelooksport2ro/Manifest.mpd|User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0"

#EXTINF:-1 tvg-ID="SkySportsPremierLeague.uk" tvg-name="Sky Sports Premier League" tvg-logo="https://i.ibb.co/88CjXqT/Desain-tanpa-judul-56-modified.png" group-title="SPORTS",Sky Sports Premier league
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webdi.openhd.lol/lb/premium130/index.m3u8?|referer=https://widevine.licenses4.me/&User-agent=REDLINECLIENT

#EXTINF:-1 tvg-ID="SkySportsF1.uk" tvg-name="Sky Sports F1" tvg-logo="https://i.ibb.co/88XwF6F/Desain-tanpa-judul-32-modified.png" group-title="SPORTS",Sky Sports Formula One
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webdi.openhd.lol/lb/premium60/index.m3u8?|referer=https://widevine.licenses4.me/&User-agent=REDLINECLIENT

#EXTINF:-1 tvg-id="SkySportMotoGP.it" tvg-logo="https://i.ibb.co/dBhDFM7/Desain-tanpa-judul-2022-07-14-T133351-399-modified.png" group-title="SPORTS",Sky Sports MotoGP
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 6.3; WOW64; rv:31.0) Gecko/20011101 Firefox/31.0
# https://dukuntv.my.id/57337005c17a518a3cee71d5170f05210698fd0b11a8f77733c08de39ab09ac67652ce68-78a50d92c806e206e634451643a7d8bf-1660653338-1660642539/olahraga/skygp

#EXTINF:-1 tvg-ID="SkySportsFootball.uk" tvg-name="Sky Sports Football" tvg-logo="https://i.ibb.co/WPL9Gpw/Desain-tanpa-judul-28-modified-1.png" group-title="SPORTS",Sky Sports Football
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webdi.openhd.lol/lb/premium35/index.m3u8?|referer=https://widevine.licenses4.me/&User-agent=REDLINECLIENT

#EXTINF:-1 tvg-ID="SkySportsRacing.uk" tvg-name="Sky Sports Football" tvg-logo="https://i.ibb.co/6v398mJ/Desain-tanpa-judul-35-modified.png" group-title="SPORTS",Sky Sports Racing
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webdi.openhd.lol/lb/premium554/index.m3u8?|referer=https://widevine.licenses4.me/&User-agent=REDLINECLIENT

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5058
#EXTINF:-1 tvg-id="SPOTV.kr" tvg-logo="https://i.ibb.co/C5gD7th/file-7408e006-5492-4b54-aa54-581581b2d87b-modified.png" group-title="SPORTS",Spotv 1 
http://linearjitp-playback.astro.com.my/dash-wv/linear/5058/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5079
#EXTINF:-1 tvg-id="SPOTV2.kr" tvg-name="SPOTV2" group-title="SPORTS" tvg-logo="https://i.ibb.co/N7LpgDN/channel-428-modified.png",Spotv 2 
https://linearjitp-playback.astro.com.my/dash-wv/linear/5079/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#EXTINF:-1 tvg-id="SPOTV.kr" group-title="SPORTS" tvg-logo="https://i.ibb.co/C5gD7th/file-7408e006-5492-4b54-aa54-581581b2d87b-modified.png", Spotv 1 Asia
https://bcovlive-a.akamaihd.net/99545824f51f4c1592b35314c6ece3b0/ap-northeast-1/6271486521001/profile_1/chunklist.m3u8

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#EXTINF:-1 tvg-id="SPOTV2.kr" group-title="SPORTS" tvg-logo="https://i.ibb.co/N7LpgDN/channel-428-modified.png", Spotv 2 Asia
https://bcovlive-a.akamaihd.net/48eee16919834d3b97df1082a649bcfa/ap-northeast-1/6271486521001/profile_1/chunklist.m3u8
https://rebrand.ly/ch5691r

#EXTINF:-1 tvg-id="CHN" group-title="SPORTS" tvg-logo="https://i.ibb.co/Zx2gQb0/unnamed.png", Spotv Now 1
https://bcovlive-a.akamaihd.net/7376a505249549cc89769a2115f20846/ap-northeast-1/6271486521001/playlist.m3u8

#EXTINF:-1 tvg-id="CHN" group-title="SPORTS" tvg-logo="https://i.ibb.co/Zx2gQb0/unnamed.png", Spotv Now 2
https://bcovlive-a.akamaihd.net/88ed787ac7a249bf9a4135156d9f1781/ap-northeast-1/6271486521001/playlist.m3u8

#EXTINF:-1 tvg-id="CHN" group-title="SPORTS" tvg-logo="https://i.ibb.co/Zx2gQb0/unnamed.png", Spotv Now 3
https://bcovlive-a.akamaihd.net/f210a9077e364c959f45e56990e8aeef/ap-northeast-1/6271486521001/playlist.m3u8

#EXTINF:-1 tvg-id="CHN" group-title="SPORTS" tvg-logo="https://i.ibb.co/Zx2gQb0/unnamed.png", Spotv Now 4
https://bcovlive-a.akamaihd.net/c9053e496b884f45806493074da15f6e/ap-northeast-1/6271486521001/playlist.m3u8

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/408
#EXTINF:-1 tvg-id="beINSports.qa" tvg-logo="http://linear-poster.astro.com.my/prod/logo/beIN_Sports_v1.png" group-title="SPORTS",BeIN Sports
http://linearjitp-playback.astro.com.my/dash-wv/linear/408/default_primary.mpd

#EXTINF:-1 tvg-id="beINSports1Indonesia.id" group-title="SPORTS" tvg-logo="https://i.ibb.co/d55Yhf3/Desain-tanpa-judul-11-modified.png",beIN Sports 1 
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#https://av-live-cdn.mncnow.id/live/eds/MrBein1/sa_dash_vmx/MrBein1.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5066
#EXTINF:-1 tvg-id="beINSports2.qa" tvg-logo="https://i.ibb.co/d55Yhf3/Desain-tanpa-judul-11-modified.png" group-title="SPORTS",beIN Sports 2
http://linearjitp-playback.astro.com.my/dash-wv/linear/5066/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2705
#EXTINF:-1 tvg-id="beINSports3Indonesia.id" group-title="SPORTS" tvg-logo="https://i.ibb.co/CQTcfYT/Desain-tanpa-judul-13-modified.png",beIN Sports 3
http://linearjitp-playback.astro.com.my/dash-wv/linear/2705/default_primary.mpd

#EXTINF:-1 tvg-id="beINSportsXtra1.qa" tvg-logo="https://i.ibb.co/t8xJLsf/Xtra-modified.png" group-title="SPORTS",BeIN Sports Extra
https://siloh.pluto.tv/lilo/production/bein/1/master.m3u8

#EXTINF:-1 tvg-id="beINSportsPremium1.qa" group-title="SPORTS" tvg-logo="https://i.ibb.co/fGGJn68/Desain-tanpa-judul-39-modified.png",Bein Sports Premium 1 
#EXTVLCOPT:http-referrer=https://olacast.live/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 6.3; WOW64; rv:31.0) Gecko/20011101 Firefox/31.0
http://62.182.82.104/L_1_PREMIUM/index.m3u8?token=test&v=697229347
# https://webudi.openhd.lol/lb/premium98/index.m3u8

#EXTINF:-1 tvg-id="beINSportsPremium2.qa" group-title="SPORTS" tvg-logo="https://i.ibb.co/9hRWGp2/Desain-tanpa-judul-40-modified-1.png",Bein Sports Premium 2 
#EXTVLCOPT:http-referrer=https://olacast.live/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 6.3; WOW64; rv:31.0) Gecko/20011101 Firefox/31.0
http://62.182.82.104/L_2_PREMIUM/index.m3u8?token=test&v=697229347
# https://webudi.openhd.lol/lb/premium99/index.m3u8

#EXTINF:-1 tvg-id="beINSportsPremium3.qa" group-title="SPORTS" tvg-logo="https://i.ibb.co/T2qGK1k/Desain-tanpa-judul-41-modified.png",Bein Sports Premium 3 
#EXTVLCOPT:http-referrer=https://olacast.live/
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 6.3; WOW64; rv:31.0) Gecko/20011101 Firefox/31.0
http://62.182.82.104/L_3_PREMIUM/index.m3u8?token=test&v=697229347
# https://webudi.openhd.lol/lb/premium100/index.m3u8

#EXTINF:-1 tvg-id="beINSportsEnglish1.qa" tvg-name="beIN SPORTS1 ENGLISH" group-title="SPORTS" tvg-logo="https://i.ibb.co/YfkCfwq/Desain-tanpa-judul-36-modified.png", beIN Sports English 1 
https://webdi.openhd.lol/ddy1/premium61/index.m3u8|referer=https://streamservicehd.click/
http://golive.yn.lt/live/epl/23.m3u8

#EXTINF:-1 tvg-id="beINSportsEnglish2.qa" tvg-name="beIN SPORTS2 ENGLISH" group-title="SPORTS" tvg-logo="https://i.ibb.co/F8NHsWC/Desain-tanpa-judul-38-modified.png", beIN Sports English 2  
https://webdi.openhd.lol/ddy1/premium90/index.m3u8|referer=https://streamservicehd.click/
http://warkop.cf/80/bein/12.m3u8

#EXTINF:-1 tvg-id="beINSportsEnglish3.qa" tvg-name="beIN SPORTS3 ENGLISH" group-title="SPORTS" tvg-logo="https://i.ibb.co/4jmb5ws/Desain-tanpa-judul-37-modified.png", beIN Sports English 3  
https://webdi.openhd.lol/ddy1/premium46/index.m3u8|referer=https://streamservicehd.click/
http://warkop.cf/80/bein/13.m3u8

#EXTINF:-1 tvg-id="TruePremierFootball1.th" tvg-logo="https://i.imgur.com/qVKmmzl.png" group-title="SPORTS",True Premier Football 1
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
#EXTVLCOPT:http-referrer=https://www.youdooball.com/
https://youdooball.livedoomovies.com:4432/02_PremierHD1_720p/chunklist.m3u8

#EXTINF:-1 tvg-id="TruePremierFootball2.th" tvg-logo="https://i.imgur.com/WOCQXij.png" group-title="SPORTS",True Premier Football 2
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
#EXTVLCOPT:http-referrer=https://www.youdooball.com/
https://youdooball.livedoomovies.com:4432/02_PremierHD2_720p/chunklist.m3u8

#EXTINF:-1 tvg-id="TruePremierFootball3.th" tvg-logo="https://i.imgur.com/eiST92o.png" group-title="SPORTS",True Premier Football 3
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
#EXTVLCOPT:http-referrer=https://www.youdooball.com/
https://youdooball.livedoomovies.com:4432/02_PremierHD3_720p/chunklist.m3u8

#EXTINF:-1 tvg-id="TruePremierFootball4.th" tvg-logo="https://i.imgur.com/bGAde1k.png" group-title="SPORTS",True Premier Football 4
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
#EXTVLCOPT:http-referrer=https://www.youdooball.com/
https://youdooball.livedoomovies.com:4432/02_PremierHD4_720p/chunklist.m3u8

#EXTINF:-1 tvg-id="TruePremierFootball5.th" tvg-logo="https://i.imgur.com/bWsMF2O.png" group-title="SPORTS",True Premier Football 5
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
#EXTVLCOPT:http-referrer=https://www.youdooball.com/
https://youdooball.livedoomovies.com:4432/02_PremierHD5_720p/chunklist.m3u8

#EXTINF:-1 tvg-id="TrueSport1.th" tvg-logo="https://i.imgur.com/lPFAHMo.png" group-title="SPORTS",True Sports 1
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
#EXTVLCOPT:http-referrer=https://www.youdooball.com/
https://youdooball.livedoomovies.com:4432/02_2sporthd1_720p/chunklist.m3u8

#EXTINF:-1 tvg-id="TrueSports2.th" tvg-logo="https://i.imgur.com/KuyXSJP.png" group-title="SPORTS",True Sports 2
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
#EXTVLCOPT:http-referrer=https://www.youdooball.com/
https://youdooball.livedoomovies.com:4432/02_2sporthd2_720p/chunklist.m3u8

#EXTINF:-1 tvg-id="TrueSports3.th" tvg-logo="https://i.imgur.com/di5ZKNb.png" group-title="SPORTS",True Sports 3
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
#EXTVLCOPT:http-referrer=https://www.youdooball.com/
https://youdooball.livedoomovies.com:4432/02_2sporthd3_720p/chunklist.m3u8

#EXTINF:-1 tvg-id="TrueSports4.th" tvg-logo="https://i.imgur.com/qod0wkC.png" group-title="SPORTS",True Sports 4
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
#EXTVLCOPT:http-referrer=https://www.youdooball.com/
https://youdooball.livedoomovies.com:4432/02_2sporthd1_720p/chunklist.m3u8

#EXTINF:-1 tvg-id="TrueSports5.th" tvg-logo="https://i.imgur.com/PJDN6vS.png" group-title="SPORTS",True Sports 5
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
#EXTVLCOPT:http-referrer=https://www.youdooball.com/
https://youdooball.livedoomovies.com:4432/02_sport5_480p/chunklist.m3u8

#EXTINF:-1 tvg-id="TrueSports7.th" tvg-logo="https://i.imgur.com/u6it1az.png" group-title="SPORTS",True Sports 7
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.79 Safari/537.36 Maxthon/5.2.7.3000
#EXTVLCOPT:http-referrer=https://www.youdooball.com/
https://youdooball.livedoomovies.com:4432/02_2sporthd7_720p/chunklist.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://raw.githubusercontent.com/yonatand1230/tv/master/logos/sport1.png" group-title="SPORTS", Sport 1 
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webdi.openhd.lol/lb/premium140/index.m3u8?|referer=https://widevine.licenses4.me/&User-agent=REDLINECLIENT

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://raw.githubusercontent.com/yonatand1230/tv/master/logos/sport1.png" group-title="SPORTS", Sport 2 
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webdi.openhd.lol/lb/premium141/index.m3u8?|referer=https://widevine.licenses4.me/&User-agent=REDLINECLIENT

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://raw.githubusercontent.com/yonatand1230/tv/master/logos/sport1.png" group-title="SPORTS", Sport 3 
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webdi.openhd.lol/lb/premium142/index.m3u8?|referer=https://widevine.licenses4.me/&User-agent=REDLINECLIENT

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://raw.githubusercontent.com/yonatand1230/tv/master/logos/sport1.png" group-title="SPORTS", Sport 4 
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webdi.openhd.lol/lb/premium143/index.m3u8?|referer=https://widevine.licenses4.me/&User-agent=REDLINECLIENT

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://raw.githubusercontent.com/yonatand1230/tv/master/logos/sport1.png" group-title="SPORTS", Sport 5 
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webdi.openhd.lol/lb/premium144/index.m3u8?|referer=https://widevine.licenses4.me/&User-agent=REDLINECLIENT

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://raw.githubusercontent.com/yonatand1230/tv/master/logos/5plus.png" group-title="SPORTS",Sport 5 Plus
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webdi.openhd.lol/lb/premium145/index.m3u8?|referer=https://widevine.licenses4.me/&User-agent=REDLINECLIENT

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://raw.githubusercontent.com/yonatand1230/tv/master/logos/5live.png" group-title="SPORTS", Sport 5 Live  
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webdi.openhd.lol/lb/premium146/index.m3u8?|referer=https://widevine.licenses4.me/&User-agent=REDLINECLIENT

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://raw.githubusercontent.com/yonatand1230/tv/master/logos/5star.png" group-title="SPORTS", Sport 5 Stars 
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webdi.openhd.lol/lb/premium147/index.m3u8?|referer=https://widevine.licenses4.me/&User-agent=REDLINECLIENT

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://raw.githubusercontent.com/yonatand1230/tv/master/logos/5gold.png" group-title="SPORTS", Sport 5 Gold 
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36
https://webdi.openhd.lol/lb/premium148/index.m3u8?|referer=https://widevine.licenses4.me/&User-agent=REDLINECLIENT

#EXTINF:-1 tvg-id="LFCTV.uk" tvg-logo="https://thumbor.prod.vidiocdn.com/WNbrafkmcf64UM-5pniUG-xObcI=/230x230/filters:quality(70)/vidio-web-prod-livestreaming/uploads/livestreaming/square_image/7916/1439f9.png" group-title="SPORTS",Liverpool FC TV
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=cfb5e2b73bef4f3c878f25ab86a7451f:0d6712bf2a84edcc93d001a9613f6fec
https://dce-fs-live-dazn-cdn.dazn.com/dashdrm/dazn-linear-034/stream.mpd

#EXTINF:-1 tvg-id="MUTV.uk" tvg-name="MUTV" tvg-logo="https://i.ibb.co/MMb4NGr/download-15-modified.png" group-title="SPORTS",Man United TV
https://bcovlive-a.akamaihd.net/r2d2c4ca5bf57456fb1d16255c1a535c8/eu-west-1/6058004203001/playlist.m3u8
# http://jessicatv.site:8080/one-day-test-89fc/54CbToqS2c/1102

#EXTINF:-1 tvg-id="MilanTV.es" tvg-name="MilanTV" tvg-logo="https://i.ibb.co/z5w78Jp/A-C-Milan-Logo-wine.png" group-title="SPORTS", Ac Milan TV
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","kid":"z7XitzvvTzyHjyWrhqdFHw","k":"DWcSvyqE7cyT0AGpYT9v7A"}]}
https://dce-fs-live-dazn-cdn.dazn.com/dashdrm/dazn-linear-025/stream.mpd|User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0"

#EXTINF:-1 tvg-id="InterDeMilanTV.es" tvg-name="MilanTV" tvg-logo="https://i.ibb.co/7rQ5Lw3/Inter-FC-logo-A600-D6151-E-seeklogo-com.png" group-title="SPORTS", Inter de Milan TV
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","kid":"z7XitzvvTzyHjyWrhqdFHw","k":"DWcSvyqE7cyT0AGpYT9v7A"}]}
https://dce-fs-live-dazn-cdn.dazn.com/dashdrm/dazn-linear-033/stream.mpd|User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0"

#EXTINF:-1 tvg-id="BarcaTV.es" tvg-name="MilanTV" tvg-logo="https://i.ibb.co/cbQ28VW/584a9b3bb080d7616d298777.png" group-title="SPORTS", Barca TV
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","kid":"x1-gd_MYXkiZpcCEWP_41w","k":"vYgX5wDnI70DZv2CtdAqRQ"},{"kty":"oct","kid":"U_REmizjXByRostr1Gfipg","k":"_FIgdiAjiAaMz-GpYfOr0Q"},{"kty":"oct","kid":"VR26yQDaU_OyswtYnl-5mQ","k":"HG3xpqXKiqoWoA9Ij6ADIg"}]}
https://tvup-live.secure.footprint.net/barcatv/barcatv.mpd|User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0"

#EXTINF:-1 tvg-id="RealMadridTV.es"tvg-logo="https://img.sport-tv-guide.live/images/tv-station-real-madrid-tv-871.png" group-title="SPORTS",Real Madrid TV
https://rmtv-canela.amagi.tv/playlist.m3u8

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/1003
#EXTINF:-1 tvg-id="GolfChannelMalaysia.my" tvg-logo="http://linear-poster.astro.com.my/prod/logo/Golf_v1.png" group-title="SPORTS",NBC Golf 
http://linearjitp-playback.astro.com.my/dash-wv/linear/1003/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=cfc32f4dc3dac49b34708ded20364610:025dcec778861dd1e40cce4dd35e73a4
#EXTINF:0 tvg-logo="https://i.postimg.cc/sDwWMtCY/Rugby-Pass-TVWhite.png" group-title="SPORTS",Rugby Pass
https://linearjitp-playback.astro.com.my/dash-wv/linear/2601/default_ott.mpd

#EXTINF:-1 tvg-id="UseeSports.dukun" tvg-logo="https://i.ibb.co/wcyS6n2/Desain-tanpa-judul-82-modified.png" group-title="SPORTS", Usee Sports 1
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:101.0) Gecko/20100101 Firefox/101.0
http://iptvid.my.id/hmm/useetl1.m3u8

#EXTINF:-1 tvg-id="UseeSports2.dukun" tvg-logo="https://i.ibb.co/TwbSJyb/Desain-tanpa-judul-83-modified.png" group-title="SPORTS", Usee Sports 2
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:101.0) Gecko/20100101 Firefox/101.0
http://iptvid.my.id/hmm/useetl2.m3u8

#EXTINF:-1 tvg-logo="https://highschoolfootballamerica.com/wp-content/uploads/2019/08/stadium-logo-640.jpg" group-title="SPORTS",Stadium Sports
https://dai2.xumo.com/amagi_hls_data_xumo1234A-stadiumsports/CDN/master.m3u8

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTINF:-1 tvg-ID="SoccerChannel.id" group-title="SPORTS" tvg-logo="https://i.ibb.co/WWXMgf4/channel-101-modified.png",Soccer Channel
https://av-live-cdn.mncnow.id/live/eds/soccerchannel-HD/sa_dash_vmx/soccerchannel-HD.mpd

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTINF:-1 tvg-ID="SoccerChannelNonLiga.id" group-title="SPORTS" tvg-logo="https://www.mncvision.id/userfiles/image/channel/channel_101.png",Soccer Channel Non Liga
# https://av-live-cdn.mncnow.id/live/eds/soccerchannel-NonLiga1/sa_dash_vmx/soccerchannel-NonLiga1.mpd

#EXTINF:-1 tvg-ID="" tvg-name="TVRI" tvg-logo="https://i.ibb.co/HPXJx3S/download-8-modified.png" group-title="SPORTS",TVRI Sport
http://wpc.d1627.nucdn.net/80D1627/o-tvri/Content/HLS/Live/Channel(TVRI4)/Stream(03)/index.m3u8

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTINF:-1 tvg-id="MNCSports.id" tvg-logo="https://i.ibb.co/Ry2WGHd/channel-102-modified.png" group-title="SPORTS",MNC Sport 1
https://av-live-cdn.mncnow.id/live/eds/MNCSports-HD/sa_dash_vmx/MNCSports-HD.mpd

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTINF:-1 tvg-id="MNCSports2.id" tvg-logo="https://i.ibb.co/5n3jwct/channel-98-modified.png" group-title="SPORTS",,MNC Sports 2
https://av-live-cdn.mncnow.id/live/eds/MNCSports2-HD/sa_dash_vmx/MNCSports2-HD.mpd

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTINF:-1 tvg-id="MNCSports3.id" tvg-logo="https://i.ibb.co/LZf6Lf1/channel-99-modified.png" group-title="SPORTS",MNC Sports 3
https://av-live-cdn.mncnow.id/live/eds/Soccer-2/sa_dash_vmx/Soccer-2.mpd

#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 6.3; WOV64; rv:31.0) Gecko/20101201 Firefox/31.0
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://dukun.masuk.id/drm/tv1
#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/9WhthSV/slazzer-edit-image-modified.png" group-title="SPORTS",Champions TV World Cup 1
#https://prod-drm-vidio-com-ctv-worldcup1.akamaized.net/out/v1/39d65abedd7c448c81463429b73288a0/index.mpd

#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 6.3; WOV64; rv:31.0) Gecko/20101201 Firefox/31.0
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://dukun.masuk.id/drm/tv2
#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/J7rtjtc/slazzer-edit-image-1-modified.png" group-title="SPORTS",Champions TV World Cup 2
#https://prod-drm-vidio-com-ctv-worldcup2.akamaized.net/out/v1/c8e8c362328d4b0fa97b2c3a8b934114/index.mpd

#EXTINF:-1 tvg-id="ChampionsTV1.id" tvg-logo="https://thumbor.prod.vidiocdn.com/uPRFvIIkgDkbWnzmPaUTTEBdbQU=/230x230/filters:quality(70)/vidio-web-prod-livestreaming/uploads/livestreaming/square_image/6685/5add43.png" group-title="SPORTS",Champions TV 1
https://anon.devds.site/link.php?hash=aHR0cDovLzE3Mi4xMDcuOTQuMjQzOjkwMDAvbGl2ZS9wcmVtaXVtL2ZyZWUvMTg2ODYudHM= 
https://etus.link/ds_championtv

#EXTINF:-1 tvg-id="ChampionsTV2.id" tvg-logo="https://thumbor.prod.vidiocdn.com/czBGyoVEbdU5E64ZH88sgEfmWXg=/230x230/filters:quality(70)/vidio-web-prod-livestreaming/uploads/livestreaming/square_image/6686/14270d.png" group-title="SPORTS",Champions TV 2
https://anon.devds.site/link.php?hash=aHR0cDovLzE3Mi4xMDcuOTQuMjQzOjkwMDAvbGl2ZS9wcmVtaXVtL2ZyZWUvMTg2ODcudHM=
https://etus.link/ds_championtv2

#EXTINF:-1 tvg-id="ChampionsTV3.id" tvg-logo="https://thumbor.prod.vidiocdn.com/RoE6gTfzYNnm1APnwvK_Bi7j_-Y=/230x230/filters:quality(70)/vidio-web-prod-livestreaming/uploads/livestreaming/square_image/6786/d2ebc5.png" group-title="SPORTS",Champions TV 3
https://etus.link/ds_championtv3

#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 6.3; VOW64; rv:31.0) Gecko/zhzsonsznsdd Firefox/31.0
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://dukun.masuk.id/drm/champ4
#EXTINF:-1 tvg-id="ChampionsTV4.id" tvg-logo="https://thumbor.prod.vidiocdn.com/BNvg3XY4KhCt9r85x8k72XQHV1k=/112x112/filters:quality(70)/vidio-web-prod-livestreaming/uploads/livestreaming/square_image/7953/448640.png" group-title="SPORTS"",Champions TV 4
https://production-drm-vidio-com-event-4.akamaized.net/out/v1/f5e1e4dc70e54d2eb4020b7af8eeb925/index.mpd

#EXTINF:-1 tvg-id="ChampionsTVGoal.id" tvg-logo="https://thumbor.prod.vidiocdn.com/LleNBdFSjLeakChDVn7zYWPf87k=/230x230/filters:quality(70)/vidio-web-prod-livestreaming/uploads/livestreaming/square_image/9045/1ef303.png" group-title="SPORTS",Champions TV Goal
https://etus.link/ds_championtv4

#EXTINF:-1 tvg-id="SuperSportLaLiga.za" tvg-logo="https://i.ibb.co/64tqpW0/unnamed-3-modified-1.png" group-title="SPORTS",Supersport La Liga
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36
https://webdi.openhd.lol/lb/premium415/index.m3u8|referer=https://widevine.licenses4.me/

#EXTINF:-1 tvg-id="SuperSportMaximo1.za" tvg-logo="https://i.ibb.co/64tqpW0/unnamed-3-modified-1.png" group-title="SPORTS",Supersport Maximo 1
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36
https://webdi.openhd.lol/lb/premium572/index.m3u8|referer=https://widevine.licenses4.me/

#EXTINF:-1 tvg-id="SuperSportPSL.za" tvg-logo="https://i.ibb.co/64tqpW0/unnamed-3-modified-1.png" group-title="SPORTS",Supersport PSL
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36
https://webdi.openhd.lol/lb/premium413/index.m3u8|referer=https://widevine.licenses4.me/

#EXTINF:-1 tvg-id="SuperSportPremierLeague.za" tvg-logo="https://i.ibb.co/64tqpW0/unnamed-3-modified-1.png" group-title="SPORTS",Supersport Premier League
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36
https://webdi.openhd.lol/lb/premium414/index.m3u8|referer=https://widevine.licenses4.me/

#EXTINF:-1 tvg-id="SuperSportFootball.za" tvg-logo="https://i.ibb.co/64tqpW0/unnamed-3-modified-1.png" group-title="SPORTS",Supersport Football
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36
https://webdi.openhd.lol/lb/premium56/index.m3u8|referer=https://widevine.licenses4.me/

#EXTINF:-1 tvg-id="SuperSportMotorsport.za" tvg-logo="https://i.ibb.co/64tqpW0/unnamed-3-modified-1.png" group-title="SPORTS",Supersport Motorsport
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36
https://webdi.openhd.lol/lb/premium424/index.m3u8|referer=https://widevine.licenses4.me/

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2601
#EXTINF:-1 tvg-id="PremierSports1Asia.ie" tvg-logo="http://linear-poster.astro.com.my/prod/logo/PremierSports.png" group-title="SPORTS",Premier Sport
http://linearjitp-playback.astro.com.my/dash-wv/linear/2601/default_primary.mpd

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2603
#EXTINF:-1 tvg-id="WWENetwork.us" tvg-logo="http://linear-poster.astro.com.my/prod/logo/WWE_v1.png" group-title="SPORTS",WWE Network
http://linearjitp-playback.astro.com.my/dash-wv/linear/2603/default_primary.mpd

#EXTINF:-1 tvg-id="TnaWrestling.us" tvg-logo="https://www.wrestlingnewsworld.com/.image/c_limit%2Ccs_srgb%2Cq_auto:good%2Cw_640/MTU3NDA1OTgyMzYwMjgyMzE0/tna-wrestling.png" group-title="SPORTS",TNA Wrestling
https://stream-us-east-1.getpublica.com/playlist.m3u8?network_id=509

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1
#EXTINF:0 tvg-id="FightSports.us" tvg-name="" tvg-logo="https://i.ibb.co/XsDyNYM/cbd69886-bb5-removebg-preview-modified.png" group-title="SPORTS",Fight Sports
https://av-live-cdn.mncnow.id/live/eds/FightSports/sa_dash_vmx/FightSports.mpd

#EXTINF:-1 tvg-id="ImpactWrestling.us" tvg-logo="https://i.ibb.co/1n9FTzM/w-modified-removebg-preview-modified.png" group-title="SPORTS",IMPACT! Wrestling
#https://dukun.masuk.id/57337005c17a518a3cee71d5170f05210698fd0b11a8f77733c08de39ab09ac67652ce68-78a50d92c806e206e634451643a7d8bf-1660653338-1660642538/olahraga/wwe.m3u8
https://d2p372oxiwmcn1.cloudfront.net/hls/main.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/JjT9VsD/download-22-modified-1.png" group-title="SPORTS",MMA TV
https://stream.ads.ottera.tv/playlist.m3u8?network_id=819&livestream=1&live=1&app_bundle=com.plexapp.android&did=62274240-07e7-5d94-8dc8-ef68cf19e175&app_domain=app.plex.tv&app_name=plex&h=&w=&custom4=plex&gdpr=0&device_make=&device_model=&coppa=1&us_privacy=1---&custom_6=Rs19sdFRTfJdn9Wyxa4f&custom_7=60ecb878ebef9d002c4d0a11&is_lat=0

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/W3tf9Fr/unnamed-8-modified.png" group-title="SPORTS",Fite TV
#https://dukun.masuk.id/57337005c17a518a3cee71d5170f05210698fd0b11a8f77733c08de39ab09ac67652ce68-78a50d92c806e206e634451643a7d8bf-1660653338-1660642538/olahraga/fite.m3u8
https://cdn-cf.fite.tv/linear/fite247/playlist.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/cJ3gNBF/download-23-modified.png" group-title="SPORTS",Hard Knocks
#https://dukun.masuk.id/57337005c17a518a3cee71d5170f05210698fd0b11a8f77733c08de39ab09ac67652ce68-78a50d92c806e206e634451643a7d8bf-1660653338-1660642538/olahraga/hard.m3u8
http://jessicatv.site:8080/one-day-test-89fc/54CbToqS2c/282286

#EXTINF:-1 tvg-id="BoxNation.uk" tvg-logo="https://i.ibb.co/kHXB452/boxnation-modified.png" group-title="SPORTS",Box Nation
#https://dukun.masuk.id/57337005c17a518a3cee71d5170f05210698fd0b11a8f77733c08de39ab09ac67652ce68-78a50d92c806e206e634451643a7d8bf-1660653338-1660642538/olahraga/boxnation
http://jessicatv.site:8080/one-day-test-89fc/54CbToqS2c/4719

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.ibb.co/SnFRPsp/boxing-tv-thumbnail-modified.png" group-title="SPORTS",Boxing TV
#https://dukun.masuk.id/57337005c17a518a3cee71d5170f05210698fd0b11a8f77733c08de39ab09ac67652ce68-78a50d92c806e206e634451643a7d8bf-1660653338-1660642538/olahraga/boxing.m3u8

#EXTINF:-1 tvg-id="SportTV1.pt" tvg-logo="https://i.ibb.co/xJKC2Mh/qpyqws1470407526.png" group-title="SPORTS", Sport TV 1
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0
https://ptstream.livechymde.xyz/hls/pt_sporttv1/livehd/pt_sporttv1_level1/chunks.m3u8?|referer=https://aesport.tv/

#EXTINF:-1 tvg-id="SportTV2.pt"  tvg-logo="https://i.ibb.co/wKRttLH/vpwuyu1470409212.png" group-title="SPORTS", Sport TV 2
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0
https://ptstream.livechymde.xyz/hls/pt_sporttv2/livehd/pt_sporttv2_level1/chunks.m3u8?|referer=https://aesport.tv/&e=.m3u8

#EXTINF:0 group-title="SPORTS" tvg-logo="https://i.imgur.com/9U5nFna.png",Sport TV 3
#http://163.172.100.183:2052/live/portugal@hdhevc@pro2/9804235480@izu@!!/1585.m3u8
 
#EXTINF:0 group-title="SPORTS" tvg-logo="https://i.imgur.com/iq5MRT8.png",Sport TV 4
#http://163.172.100.183:2052/live/portugal@hdhevc@pro2/9804235480@izu@!!/1580.m3u8 

#EXTINF:0 group-title="SPORTS" tvg-logo="https://i.imgur.com/GgJrV2p.png",Sport TV 5
#http://163.172.100.183:2052/live/portugal@hdhevc@pro2/9804235480@izu@!!/3788.m3u8 

#EXTINF:-1 tvg-id="ext" tvg-logo="https://i.ibb.co/XjjmZ8S/Bt3.png" group-title="SPORTS",Billiard TV
https://1621590671.rsc.cdn77.org/HLS/BILLIARDTV_SCTE.m3u8

#EXTINF:-1 tvg-id="RedBullTV.us" group-title="SPORTS" tvg-logo="https://i.ibb.co/zxvTqGK/download-5-modified-1.png",RedBull TV
https://rbmn-live.akamaized.net/hls/live/590964/BoRB-AT/master_3360.m3u8

#EXTINF:-1 tvg-logo="https://deifoexkvnt11.cloudfront.net/assets/article/2019/09/17/venn-logo-blue-patternfill-horizontal_feature.png" group-title="SPORTS", Venn
https://venntv-samsungau.amagi.tv/playlist.m3u8

#EXTINF:-1 tvg-id="ESReSportsNetwork.us" tvg-name="ESR eSports Network" tvg-country="US" tvg-language="English" tvg-logo="https://f9q4g5j6.ssl.hwcdn.net/605d2f4c46818164091e1fd4" group-title="SPORTS",ESR eSports Network 
https://eyeonesports.com/ES2RA-628g.m3u8

#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/2602
#EXTINF:-1 tvg-id="eGGNetwork.my" tvg-logo="https://i.ibb.co/FgTYk4t/egg-modified.png" group-title="SPORTS",eGG Network
http://linearjitp-playback.astro.com.my/dash-wv/linear/2602/default_primary.mpd

#EXTINF:-1 tvg-id="GinXesportstv.uk" tvg-name="Ginx eSports TV" tvg-logo="http://vizyonbox.link:2086/images/0c2c07ddff48a1f10a24585b42523832.png" group-title="SPORTS",Ginx eSports TV
#EXTVLCOPT:http-user-agent=MxExoPlayerLib/2.8.4
http://jessicatv.site:8080/one-day-test-89fc/54CbToqS2c/15913

#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key=https://dukun.masuk.id/drm/result.php?keyid=ce17264b317db108f19cdc11aa1a9e66&key=a21188aee8fc5c56d016fcffcc6b2295
#EXTINF:-1 tvg-id="SonySix.in" tvg-logo="https://i.ibb.co/KyYVc6h/Desain-tanpa-judul-52-modified.png" group-title="SPORTS",Sony Six
https://cdn-01.toffeelive.com/origin-08/live-origin/smil:sony_six_hd.smil/manifest.mpd

#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key=https://dukun.masuk.id/drm/result.php?keyid=ce17264b317db108f19cdc11aa1a9e66&key=a21188aee8fc5c56d016fcffcc6b2295
#EXTINF:-1 tvg-id="SonyTen1.in" tvg-logo="https://i.ibb.co/dGXMK2m/Desain-tanpa-judul-53-modified.png" group-title="SPORTS",Sony Ten 1
https://cdn-01.toffeelive.com/origin-09/live-origin/smil:sony_ten1_hd.smil/manifest.mpd

#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key=https://dukun.masuk.id/drm/result.php?keyid=ce17264b317db108f19cdc11aa1a9e66&key=a21188aee8fc5c56d016fcffcc6b2295
#EXTINF:-1 tvg-id="SonyTen2.in" tvg-logo="https://i.ibb.co/vcvx0yL/Desain-tanpa-judul-54-modified.png" group-title="SPORTS",Sony Ten 2
https://cdn-01.toffeelive.com/origin-09/live-origin/smil:sony_ten2_hd.smil/manifest.mpd

#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key=https://dukun.masuk.id/drm/result.php?keyid=ce17264b317db108f19cdc11aa1a9e66&key=a21188aee8fc5c56d016fcffcc6b2295
#EXTINF:-1 tvg-id="SonyTen3.in" tvg-logo="https://i.ibb.co/MBC88gg/Desain-tanpa-judul-55-modified.png" group-title="SPORTS",Sony Ten 3
https://cdn-01.toffeelive.com/origin-09/live-origin/smil:sony_ten3_hd.smil/manifest.mpd

#EXTINF:-1 tvg-id="ksport1hd" group-title="SPORTS" tvg-logo="http://logo.vagroup.pw/97.png", K Plus Sport 1 
#KODIPROP:inputstream.adaptive.manifest_type=mpd #KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha 
#KODIPROP:inputstream.adaptive.license_key=https://kplus.live.ott.irdeto.com/Widevine/GetLicense?CrmId=kplus&AccountId=kplus&ContentId=400000017&SessionId=14C0F1BB9A14154D&Ticket=F75ECCDF30FDD78A|Accept-Language=vi&Content-Type=application%2Foctet-stream&Host=kplus.live.ott.irdeto.com&Origin=https%3A%2F%2Fxem.kplus.vn&User-Agent=Mozilla%2F5.0+%28Windows+NT+10.0%3B+Win64%3B+x64%29+AppleWebKit%2F537.36+%28KHTML%2C+like+Gecko%29+Chrome%2F92.0.4515.159+Safari%2F537.36|R{{SSM}} 
#https://ottlivevng.kplus.vn/live/prod_kplus_pm_hd_fps/prod_kplus_pm_hd_fps.isml/prod_kplus_pm_hd_fps.mpd 

#EXTINF:-1 tvg-id="ksport2hd" group-title="SPORTS" tvg-logo="http://logo.vagroup.pw/98.png", K Plus Sport 2
#KODIPROP:inputstream.adaptive.manifest_type=mpd #KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha 
#KODIPROP:inputstream.adaptive.license_key=https://kplus.live.ott.irdeto.com/Widevine/GetLicense?CrmId=kplus&AccountId=kplus&ContentId=400000018&SessionId=B3A30136DB4CCE5E&Ticket=8B2100CB60332994|Accept-Language=vi&Content-Type=application%2Foctet-stream&Host=kplus.live.ott.irdeto.com&Origin=https%3A%2F%2Fxem.kplus.vn&User-Agent=Mozilla%2F5.0+%28Windows+NT+10.0%3B+Win64%3B+x64%29+AppleWebKit%2F537.36+%28KHTML%2C+like+Gecko%29+Chrome%2F92.0.4515.159+Safari%2F537.36|R{{SSM}} 
#https://ottlivevng.kplus.vn/live/prod_kplus_pc_hd_fps/prod_kplus_pc_hd_fps.isml/prod_kplus_pc_hd_fps.mpd 

#EXTINF:-1 tvg-id="vtvcab3hd" tvg-logo="https://mytv.com.vn/upload/channel/phpLhy8IQ_613966bf6fda5.png" group-title="SPORTS",OnSports
https://e3.endpoint.cdn.sctvonline.vn/hls/vtvcab3/index.m3u8|Referer=http://sctvonline.vn/

#EXTINF:-1 tvg-id="vtvcab6hd" tvg-logo="https://mytv.com.vn/upload/channel/phpLhy8IQ_613966bf6fda5.png" group-title="SPORTS",ONSports+
https://e3.endpoint.cdn.sctvonline.vn/hls/vtvcab6/index.m3u8|Referer=http://sctvonline.vn/

#EXTINF:-1 tvg-id="vtvcab16hd" tvg-logo="https://mytv.com.vn/upload/channel/phpLhy8IQ_613966bf6fda5.png" group-title="SPORTS",OnFootball
https://e3.endpoint.cdn.sctvonline.vn/hls/vtvcab16/sd2/index.m3u8|Referer=http://sctvonline.vn/

#EXTINF:1 tvg-id="ESPN.mx" tvg-logo="https://i.ibb.co/hskn1LW/ESPN-wordmark-svg.png" group-title="SPORTS", ESPN
#KODIPROP:inputstream.adaptive.manifest_type=mpd
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://gowv.izzigo.tv:8063/?deviceId=MzcwM2FjMDQtY2UxOS0zMDk3LTkzMTYtZWM2MWM5NmI5NTYw
https://live1-ott.izzigo.tv/out/u/dash/ESPN-HD/dash/default.mpd

#EXTINF:1 tvg-id="ESPN2.mx" tvg-logo="https://i.ibb.co/hskn1LW/ESPN-wordmark-svg.png" group-title="SPORTS", ESPN 2
#KODIPROP:inputstream.adaptive.manifest_type=mpd
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://gowv.izzigo.tv:8063/?deviceId=MzcwM2FjMDQtY2UxOS0zMDk3LTkzMTYtZWM2MWM5NmI5NTYw
https://live1-ott.izzigo.tv/out/u/dash/ESPN-2-HD/dash/default.mpd

#EXTINF:1 tvg-id="ESPN3.mx" tvg-logo="https://i.ibb.co/hskn1LW/ESPN-wordmark-svg.png" group-title="SPORTS", ESPN 3
#KODIPROP:inputstream.adaptive.manifest_type=mpd
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://gowv.izzigo.tv:8063/?deviceId=MzcwM2FjMDQtY2UxOS0zMDk3LTkzMTYtZWM2MWM5NmI5NTYw
https://live1-ott.izzigo.tv/out/u/dash/ESPN-3-HD/dash/default.mpd

#EXTINF:1 tvg-id="ESPNEXTRA.mx" tvg-logo="https://i.ibb.co/0FJtHkm/ESPN-Xtra-logo-svg.png" group-title="SPORTS", ESPN Extra
#KODIPROP:inputstream.adaptive.manifest_type=mpd
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://gowv.izzigo.tv:8063/?deviceId=MzcwM2FjMDQtY2UxOS0zMDk3LTkzMTYtZWM2MWM5NmI5NTYw
https://live1-ott.izzigo.tv/out/u/dash/ESPN-PLUS-HD/dash/default.mpd

#EXTINF:1 tvg-id="FOXSports.mx" tvg-logo="https://i.ibb.co/3Y0hm3f/Fox-Sports-Netherlands-Logo.png" group-title="SPORTS", Fox Sports
#KODIPROP:inputstream.adaptive.manifest_type=mpd
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://gowv.izzigo.tv:8063/?deviceId=MzcwM2FjMDQtY2UxOS0zMDk3LTkzMTYtZWM2MWM5NmI5NTYw
https://live1-ott.izzigo.tv/out/u/dash/FOX-SPORTS-HD/dash/default.mpd

#EXTINF:1 tvg-id="FoxSports2.mx" tvg-logo="https://i.ibb.co/3Y0hm3f/Fox-Sports-Netherlands-Logo.png" group-title="SPORTS", Fox Sports 2
#KODIPROP:inputstream.adaptive.manifest_type=mpd
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://gowv.izzigo.tv:8063/?deviceId=MzcwM2FjMDQtY2UxOS0zMDk3LTkzMTYtZWM2MWM5NmI5NTYw
https://live4-ott.izzigo.tv/out/u/dash/FOX-SPORTS-2-HD/default.mpd

#EXTINF:1 tvg-id="FoxSports3.mx" tvg-logo="https://i.ibb.co/3Y0hm3f/Fox-Sports-Netherlands-Logo.png" group-title="SPORTS", Fox Sports 3
#KODIPROP:inputstream.adaptive.manifest_type=mpd
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://gowv.izzigo.tv:8063/?deviceId=MzcwM2FjMDQtY2UxOS0zMDk3LTkzMTYtZWM2MWM5NmI5NTYw
https://live1-ott.izzigo.tv/out/u/dash/FOX-SPORTS-3-HD/dash/default.mpd

#EXTINF:1 tvg-id="TUDN.mx" tvg-logo="https://i.ibb.co/vzYmfzz/TUDN-Logo-svg.png" group-title="SPORTS", TUDN
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:101.0) Gecko/20100101 Firefox/101.0
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://gowv.izzigo.tv:8063/?deviceId=MzcwM2FjMDQtY2UxOS0zMDk3LTkzMTYtZWM2MWM5NmI5NTYw
https://live1-ott.izzigo.tv/out/u/dash/TUDN-HD/default.mpd  

#EXTINF:-1 tvg-id="Eleven1Portugal.pt" group-title="SPORTS" tvg-logo="https://i.imgur.com/5ZmH1y8.png", Eleven Sports 1
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","kid":"FxZ5lxLHRBmOGhydNU3abQ","k":"oUjlXlU1u_t9wkwiTSaD5A"}],"type":"temporary"}
https://tvvvideolive3.solocoo.tv/blueskytvvlive7dash/blueelevenproleague1nl/Manifest.mpd|User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0"

#EXTINF:1 tvg-id="Match.ru" tvg-logo="https://i.ibb.co/DWDfrT3/Match-TV-logo.png" group-title="SPORTS", Матч! 
#EXTVLCOPT:http-user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0
https://bl.uma.media/live/407384/HLS/6307840_7,4280320/2/1/playlist.m3u8

#EXTINF:-1 tvg-id="CHN" group-title="SPORTS" tvg-logo="https://i.imgur.com/jREfsES.png", Sports Digital
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","kid":"z7XitzvvTzyHjyWrhqdFHw","k":"DWcSvyqE7cyT0AGpYT9v7A"}],"type":"temporary"}
https://dce-fs-live-dazn-cdn.dazn.com/dashdrm/dazn-linear-022/stream.mpd|User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0"

#EXTINF:-1 tvg-id="ZiggoSportVoetbal.nl" tvg-logo="https://i.ibb.co/SrTd4yV/tv-station-ziggo-voetbal-286-modified.png" group-title="SPORTS",Ziggo Voetbal
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=9c0b24d5e9e2456c93f8fae2e913182c:e06339c46258a695fc8a2e8bfb394b6a
https://cdsvideolive3.solocoo.tv/blueskycdslive7dash/blueziggosportvoetbal/Manifest.mpd

#EXTINF:-1 tvg-id="ZiggoSportSelect.nl" tvg-logo="https://i.ibb.co/SrTd4yV/tv-station-ziggo-voetbal-286-modified.png" group-title="SPORTS", Ziggo Sports Select
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","k":"5REMwNI+asLnqIUD5oEhpA","kid":"Y4qeI20DRNiBfOgVIrEX1g"}]}
https://cdsvideolive3.solocoo.tv/blueskycdslive7dash/blueziggosportselect/Manifest.mpd|User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0"

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.imgur.com/Z9Jaid7.png" group-title="SPORTS", V Sports Premium
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","k":"1byekvIU13Ugq3+qHsrRCw","kid":"y9E7eog+U+mNXH800AE76A"}],"type":"temporary"}
https://director.streaming.telia.com/tvm-packager-prod/group1/60896c3647a23d7f115cd57a/manifest.mpd|User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0"

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.imgur.com/wWVPVAX.png" group-title="SPORTS", V Sports Xtra
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","kid":"vJcjgvBMUxmDt6q2v2Qq2A","k":"3f0hJoDriRt1VhDqxb7PhQ"}]}
https://director.streaming.telia.com/tvm-packager-prod/group3/60ae4f5e1522bd739f6959a1/manifest.mpd

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.imgur.com/wWVPVAX.png" group-title="SPORTS", V Sports Football
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","kid":"zjfiA3TlW-a7TSaDevJ2BQ","k":"UsxTL3SPy_K4BtrUKJv4TA"}]}
https://director.streaming.telia.com/tvm-packager-prod/group1/60896dfd47a23d7c065cd68c/manifest.mpd

#EXTINF:-1 tvg-id="CHN" tvg-logo="https://i.postimg.cc/Y0P81ZTw/ziggo.png" group-title="SPORTS", C More Fotbol
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","kid":"wcZXqhYMWzKPHnZ0dTS5Ew","k":"eF4Hc-nVNKAPRhkxVnTvfw"}],"type":"temporary"}
https://lbs-usp-dash-live.cmore.se/tvm-packager-prod/group3/60ae452e1522bdf301694494/manifest.mpd|User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0"

#EXTINF:-1 tvg-id="" tvg-name="DIGI SPORT 1" tvg-logo="https://static.wixstatic.com/media/0e2b3e_353a02b12dea4fdeb128d63b82f31938~mv2.png" group-title="SPORTS",Digi Sport 1
http://ip.opentv.ma/play/live.php?mac=00:1a:79:35:f3:94&stream=179647&extension=ts&play_token=xWWYLznPFN

#EXTINF:-1 tvg-id="" tvg-name="DIGI SPORT 2" tvg-logo="https://static.wixstatic.com/media/0e2b3e_f94ad20ec697442fbc4d5c4c437e61c7~mv2.png" group-title="SPORTS",Digi Sport 2
http://ip.opentv.ma/play/live.php?mac=00:1a:79:35:f3:94&stream=179648&extension=ts&play_token=JHGdrlPpyW

#EXTINF:-1 tvg-id="" tvg-name="DIGI SPORT 3" tvg-logo="https://static.wixstatic.com/media/0e2b3e_6b6f4d2d431e4ce1881f65c308270c09~mv2.jpg" group-title="SPORTS",Digi Sport 3
http://ip.opentv.ma/play/live.php?mac=00:1a:79:35:f3:94&stream=179649&extension=ts&play_token=ml4YlX4Zsh

#EXTINF:-1 tvg-id="" tvg-name="DIGI SPORT 4" tvg-logo="https://static.wixstatic.com/media/0e2b3e_f6bb104e1b204d1e98f4814ceff31000~mv2.png" group-title="SPORTS",Digi Sport 4
http://ip.opentv.ma/play/live.php?mac=00:1a:79:35:f3:94&stream=179650&extension=ts&play_token=hWELDyzhOB

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/qJx1Hbx/TNT-Sports-Logo-Vertical-2017.png" group-title="SPORTS",TNT Sports 1
https://glxlmn026c.singularcdn.net.br/playout_01/playlist-720p.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/qJx1Hbx/TNT-Sports-Logo-Vertical-2017.png" group-title="SPORTS",TNT Sports 2
https://glxlmn026c.singularcdn.net.br/playout_02/playlist-720p.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/qJx1Hbx/TNT-Sports-Logo-Vertical-2017.png" group-title="SPORTS",TNT Sports 3
https://glxlmn026c.singularcdn.net.br/playout_03/playlist-720p.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/qJx1Hbx/TNT-Sports-Logo-Vertical-2017.png" group-title="SPORTS",TNT Sports 4
https://glxlmn026c.singularcdn.net.br/playout_04/playlist-720p.m3u8

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/qJx1Hbx/TNT-Sports-Logo-Vertical-2017.png" group-title="SPORTS",TNT Sports 5
https://glxlmn026c.singularcdn.net.br/playout_05/playlist-720p.m3u8

#EXTINF:-1 tvg-id="SportKlub1Croatia.hr" group-title="SPORTS" tvg-logo="https://i.ibb.co/QpFxWKq/1280px-Sportklub-Logo-svg.png",Sport Klub 1
https://webdi.openhd.lol/ddy1/premium101/index.m3u8|referer=https://streamservicehd.click/

#EXTINF:-1 tvg-id="SportKlub1Croatia.hr" group-title="SPORTS" tvg-logo="https://i.ibb.co/QpFxWKq/1280px-Sportklub-Logo-svg.png",Sport Klub 2
https://webdi.openhd.lol/ddy1/premium102/index.m3u8|referer=https://streamservicehd.click/

#EXTINF:-1 tvg-id="SportKlub3.rs" group-title="SPORTS" tvg-logo="https://i.ibb.co/QpFxWKq/1280px-Sportklub-Logo-svg.png",Sport Klub 3
https://webdi.openhd.lol/ddy1/premium103/index.m3u8|referer=https://streamservicehd.click/

#EXTINF:-1 tvg-id="SportKlub4.rs" group-title="SPORTS" tvg-logo="https://i.ibb.co/QpFxWKq/1280px-Sportklub-Logo-svg.png",Sport Klub 4
https://webdi.openhd.lol/ddy1/premium104/index.m3u8|referer=https://streamservicehd.click/

#EXTINF:-1 tvg-id="Eleven1Portugal.pt" group-title="SPORTS" tvg-logo="https://i.ibb.co/fnsnZ5r/Desain-tanpa-judul-85-modified.png", Eleven Sports 1
http://he11o.akadatel.com/iptv/47PC7ECLXZM7EV/2531/index.m3u8

#EXTINF:-1 tvg-id="Eleven2Portugal.ptt" group-title="SPORTS" tvg-logo="https://i.ibb.co/D8SDX57/Desain-tanpa-judul-86-modified.png", Eleven Sports 2
http://he11o.akadatel.com/iptv/47PC7ECLXZM7EV/2532/index.m3u8 

#EXTINF:-1 tvg-id="Eleven3Portugal.pt" group-title="SPORTS" tvg-logo="https://i.ibb.co/YXXvXWY/Desain-tanpa-judul-87-modified.png", Eleven Sports 3
http://he11o.akadatel.com/iptv/47PC7ECLXZM7EV/2533/index.m3u8 

#EXTINF:-1 tvg-id="Eleven4Portugal.pt" group-title="SPORTS" tvg-logo="https://i.ibb.co/CwsBxRn/Desain-tanpa-judul-88-modified.png", Eleven Sports 4
http://he11o.akadatel.com/iptv/47PC7ECLXZM7EV/2534/index.m3u8 

#EXTINF:-1 tvg-id="Eleven5Portugal.pt" group-title="SPORTS" tvg-logo="https://i.ibb.co/BVM2jj3/Desain-tanpa-judul-89-modified.png", Eleven Sports 5
#http://213.13.19.35/shls/LIVE$Eleven_Sports_5_HD/index.m3u8?device=ANDROID_Live&start=LIVE&end=END

#EXTINF:-1 tvg-id="Eleven6Portugal.pt" group-title="SPORTS" tvg-logo="https://i.ibb.co/WzTfxx7/Desain-tanpa-judul-90-modified.png", Eleven Sports 6
#http://213.13.19.35/shls/LIVE$Eleven_Sports_6_HD/index.m3u8?device=ANDROID_Live&start=LIVE&end=END

#EXTINF:-1 tvg-ID="" tvg-name="ABU DHABI SPORTS 1" tvg-logo="https://i.ibb.co/85Tpwp6/LF-Portfolio-ADSports-Logo-2-modified.png" group-title="SPORTS",Abu Dhabi Sports 1
https://admdn1.cdn.mangomolo.com/adsports1/smil:adsports1.stream.smil/chunklist_b4000000_t64MTA4MHA=.m3u8   

#EXTINF:-1 tvg-ID="" tvg-name="ABU DHABI SPORTS 2" tvg-logo="https://i.ibb.co/85Tpwp6/LF-Portfolio-ADSports-Logo-2-modified.png" group-title="SPORTS",Abu Dhabi Sports 2
https://admdn5.cdn.mangomolo.com/adsports2/smil:adsports2.stream.smil/chunklist_b4000000_t64MTA4MHA=.m3u8

#EXTINF:-1 tvg-ID="" tvg-name="ABU DHABI SPORTS 3" tvg-logo="https://i.ibb.co/85Tpwp6/LF-Portfolio-ADSports-Logo-2-modified.png" group-title="SPORTS",Abu Dhabi Sports 3
http://admdn3.cdn.mangomolo.com/adsports3/smil:adsports3.stream.smil/chunklist_b4000000_t64MTA4MHA=.m3u8

#EXTINF:-1  tvg-id="DubaiSports1.ae" tvg-logo="https://i.ibb.co/s3VLky1/download-24-modified-1.png" group-title="SPORTS",Dubai Sports 1
https://dmitnthvll.cdn.mangomolo.com/dubaisports/smil:dubaisports.smil/chunklist_b1600000.m3u8

#EXTINF:-1  tvg-id="DubaiSports2.ae" tvg-logo="https://i.ibb.co/s3VLky1/download-24-modified-1.png" group-title="SPORTS",Dubai Sports 2
https://dmitwlvvll.cdn.mangomolo.com/dubaisportshd/smil:dubaisportshd.smil/chunklist_b1600000.m3u8

#EXTINF:-1  tvg-id="DubaiSports3.ae" tvg-logo="https://i.ibb.co/s3VLky1/download-24-modified-1.png" group-title="SPORTS",Dubai Sports 3
https://dmitwlvvll.cdn.mangomolo.com/dubaisportshd5/smil:dubaisportshd5.smil/chunklist_b1600000.m3u8






#######################################################################################################################################################################

#############################






#EXTINF:-1 tvg-id="CHN" tvg-name="" group-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="MUSIC",SILA KLIK DAN BACA!!
https://tinyurl.com/sila-baca-la-oii

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="MUSIC",VISIT MY SHOP 
https://tinyurl.com/visit-kedai-saya

#EXTINF:-1 group-title="MUSIC" tvg-id="CHN" ch-number="CHN" tvg-logo="https://yt3.ggpht.com/ytc/AAUvwnhGIymQGp3jRMECbTCBSRAUqi8sKbATpWowQG44CA=s48-c-k-c0x00ffffff-no-rj",LOFI MUSIC 24/7
https://raw.githubusercontent.com/AqFad2811/randomlivefromyt2/main/LofiRadio.m3u8

#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=MDA5MmI1NjctOWMyMS0zNDYyLTk0NDAtODM5NGQ1ZjdlZWRi
#EXTINF:-1 tvg-id="MusicTV.id" tvg-logo="http://dusktill.masuk.web.id/img/musictv.png" group-title="MUSIC",Music TV
https://av-live-cdn.mncnow.id/live/eds/MusicChannel/sa_dash_vmx/MusicChannel.mpd

#EXTINF:-1 tvg-id="MTVAsia.sg" ch-number="718" group-title="MUSIC" tvg-logo="https://playtv.unifi.com.my:7048/CPS/images/universal/film/logo/202109/20210913/20210913160636492fzf.png",MTV Asia 
#KODIPROP:inputstream.adaptive.license_type=clearkey
#KODIPROP:inputstream.adaptive.license_key=https://ck-dash-mpd.astradamy.com/dash-ck/linear/5014
https://linearjitp-playback.astro.com.my/dash-wv/linear/5014/default_primary.mpd

#KODIPROP:inputstream.adaptive.manifest_type=mpd
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key=https://dukun.masuk.id/drm/result.php?keyid=ce17264b317db108f19cdc11aa1a9e66&key=a21188aee8fc5c56d016fcffcc6b2295
#EXTINF:-1 tvg-name="305" tvg-id="718" tvg-logo="https://raw.githubusercontent.com/angahjee1994/logo/master/mtv.png" group-title="MUSIC",MTV 
https://cdn-01.toffeelive.com/origin-05/live-origin/smil:mtv.smil/manifest.mpd

#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key=https://dukun.masuk.id/drm/result.php?keyid=ce17264b317db108f19cdc11aa1a9e66&key=a21188aee8fc5c56d016fcffcc6b2295
#EXTINF:-1 tvg-ID="CHN"  tvg-logo="https://i.ibb.co/cb7H9Xj/download-22-modified.png" group-title="MUSIC", MTV Beats India
https://cdn-01.toffeelive.com/origin-05/live-origin/smil:mtv_beats_hd.smil/manifest.mpd

#EXTINF:-1 tvg-id="" tvg-name="" tvg-logo="https://www.lyngsat.com/logo/tv/cc/channel_v_international.png" group-title="MUSIC",Channel V 
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha 
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1 
https://live-cdn.mncnow.id/live/eds/ChannelV/sa_dash_vmx/ChannelV.mpd

#EXTINF:-1  tvg-logo="https://i.imgur.com/WVT1Yct.png" group-title="MUSIC", MTV (Flow)
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","k":"Zr+/pESeuLwbz3V31b/6rQ","kid":"DJ6z6tOKEirEYK2WqOv9Lg"}],"type":"temporary"}
https://edge-live12-sl.cvattv.com.ar/live/c6eds/MTV_HD/SA_Live_dash_enc/MTV_HD.mpd|User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0"

#EXTINF:-1  tvg-logo="https://i.imgur.com/WVT1Yct.png" group-title="MUSIC", MTV (DTV)
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key=74d426155d66366e97dc3a95d406dc03:049cb061d1e683a01504192e5f8e90cb
https://1165-vos.dtvott.com/DASH/manifest.mpd|User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0"

#EXTINF:-1 tvg-logo="https://i.imgur.com/kJgHoSn.png" group-title="MUSIC", MTV Hits
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","k":"cWRJdWMWuRxUgDqqIqL78A","kid":"YQCN/IZ1RM2HLembHyuCzw"}],"type":"temporary"}
https://edge-live12-sl.cvattv.com.ar/live/c6eds/MTV_Hits/SA_Live_dash_enc/MTV_Hits.mpd|User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0"

#EXTINF:-1 tvg-logo="https://i.imgur.com/kJgHoSn.png" group-title="MUSIC", MTV Hits (UK)
http://85.11.144.9:4222/MTVHits?token=test

#EXTINF:-1 tvg-logo="https://i.imgur.com/J4rx84I.png" group-title="MUSIC", MTV 80s
http://190.83.119.67:8000/play/a0po/index.m3u8

#EXTINF:-1 tvg-logo="https://i.imgur.com/J4rx84I.png" group-title="MUSIC", MTV 80s (UK)
http://85.11.144.9:4222/VH1Classic?token=test

#EXTINF:-1 tvg-logo="https://i.imgur.com/J4rx84I.png" group-title="MUSIC", MTV 80s (EU)
http://livetv.mylifeisgood.ml/channels/mtv80s

#EXTINF:-1 tvg-logo="https://i.imgur.com/9aeuyUn.png" group-title="MUSIC", MTV 90s (OP1)
http://myott.top/stream/P4H2M76YRH/88.m3u8

#EXTINF:-1 tvg-logo="https://i.imgur.com/9aeuyUn.png" group-title="MUSIC", MTV 90s (OP2)
http://85.11.144.9:4222/MTVRocks?token=test

#EXTINF:-1 tvg-logo="https://i.imgur.com/9aeuyUn.png" group-title="MUSIC", MTV 90s (OP3)
http://livetv.mylifeisgood.ml/channels/mtv90s

#EXTINF:-1 tvg-logo="https://i.imgur.com/I2BPlh1.png" group-title="MUSIC", MTV 00s
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","k":"gCyJxrrmokWqr89AwZhvwQ","kid":"HwwJ7Z5YQc+Ge6brPN/WHQ"}],"type":"temporary"}
https://edge-live12-sl.cvattv.com.ar/live/c7eds/MTV00/SA_Live_dash_enc/MTV00.mpd|User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0"

#EXTINF:-1 tvg-logo="https://i.imgur.com/I2BPlh1.png" group-title="MUSIC", MTV 00s HD
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","kid":"-9QWjWj8SsKybIY6zE4K0A","k":"NJXDr5dr51PPP7skWPRN6g"}]}
https://b42559.4.cdn.telefonica.com/_42559/sdash/LIVE$VH1HD/index.mpd/Manifest.mpd?start=LIVE&end=END&device=Dashavc&tcdn-bitrate-filter=LiveL-M

#EXTINF:-1 tvg-logo="https://i.imgur.com/FLJrxDl.png" group-title="MUSIC", MTV Live HD
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","kid":"B-6Ub_GwQk6N4BKcPZej5g","k":"n8I06JiTYR45QNfEG6TOKQ"}]}
https://b42558-p7-he0-te1bbef.4.cdn.telefonica.com/_42558/sdash/LIVE$MTVLiveHD/index.mpd/Manifest.mpd?start=LIVE&end=END&device=Dashavc&tcdn-bitrate-filter=LiveL-M

#EXTINF:-1 tvg-logo="https://i.imgur.com/PR5Jv1R.png" group-title="MUSIC", Nick Music
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","k":"Sk/YbqnbRBfshsI30xEbGA","kid":"6ubBLMqzSeauZ1q27YpHbA"}],"type":"temporary"}
https://edge-live12-sl.cvattv.com.ar/live/c6eds/Nickmusic/SA_Live_dash_enc/Nickmusic.mpd|User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0"

#EXTINF:-1 tvg-logo="https://i.imgur.com/6l1ZgxV.png" group-title="MUSIC", Much Music
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","k":"woRfTFVPyvlqE9pKNzhoxA","kid":"HLBVj53dSCC8mYLOSD5YiA"}],"type":"temporary"}
https://edge-live12-sl.cvattv.com.ar/live/c6eds/Much_Music/SA_Live_dash_enc/Much_Music.mpd|User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0"

#EXTINF:-1 tvg-id="CMElCanaldelaMusica.ar", tvg-logo="https://i.imgur.com/Wnxp3FA.png" group-title="MUSIC" , CM
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","k":"Osy3KQZ6ObO4FD8bRHudJQ","kid":"aC82tXNvRWCVHKFLgNKVJA"}],"type":"temporary"}
https://edge-live12-sl.cvattv.com.ar/live/c6eds/CM/SA_Live_dash_enc_2A/CM.mpd|User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0"

#EXTINF:-1 tvg-logo="https://i.imgur.com/sea4SZR.png" group-title="MUSIC", QUIERO (Flow)
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","k":"RadtzITwWM+ryLlY1zA7KA","kid":"o1SwyCo6cgxKb1LtWhGQ9A"}],"type":"temporary"}
https://edge-live12-sl.cvattv.com.ar/live/c6eds/Quiero_HD/SA_Live_dash_enc/Quiero_HD.mpd|User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0"

#EXTINF:-1 tvg-logo="https://i.imgur.com/sea4SZR.png" group-title="MUSIC", QUIERO (Mov)
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","kid":"59lNZx_hSIKVOoY56A4VSQ","k":"yy-9hWaa-zp6IuJyB8MeSg"}]}
https://b43716.3.cdn.telefonica.com/_43716/sdash/LIVE$Quiero/index.mpd/Manifest.mpd?start=LIVE&end=END&device=Dashavc&tcdn-bitrate-filter=LiveL-M|User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0"

#EXTINF:-1 tvg-id="HTV.us", tvg-logo="https://i.imgur.com/MwGkvXm.png" group-title="MUSIC", HTV
#KODIPROP:inputstreamaddon=inputstream.adaptive
#KODIPROP:inputstream.adaptive.manifest_type=dash
#KODIPROP:inputstream.adaptive.license_type=org.w3.clearkey
#KODIPROP:inputstream.adaptive.license_key={"keys":[{"kty":"oct","k":"1CJ/JDiam6dykyFLk+sNfQ","kid":"2uzvX+MvTOCDxqDGknVdag"}],"type":"temporary"}
https://edge-live12-sl.cvattv.com.ar/live/c6eds/HTV/SA_Live_dash_enc/HTV.mpd|User-Agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0"

#EXTINF:-1 tvg-logo="https://i.imgur.com/YAIQFBW.png" group-title="MUSIC", Stingray Qello
https://siloh-latam-aka.plutotv.net/lilo/production/Qello/LATAM/master.m3u8


#EXTINF:0 tvg-id="" tvg-name="" tvg-logo="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRxjqfz1KbznHYILoRRHanesCW-XJqEezlOgk7EXCopF3i_oWTicgdt_RIRE2YmVfKebN4&usqp=CAU" group-title="MUSIC",SBS MTV Kpop
https://srv1.zcast.com.br/kpoptv/kpoptv/playlist.m3u8

#EXTINF:0 tvg-id="" tvg-name="" tvg-logo="http://dusktill.masuk.web.id/img/zing.png" group-title="MUSIC",Zing
http://muttsnuts.teaches-yoga.com:8080/live/kipper1/kipper1/521133.ts

#EXTINF:-1  tvg-id="mtv-rus" group-title="MUSIC" tvg-logo="https://i.imgur.com/Lqhy44V.png",MTV Block Party 
http://pluto-live.plutotv.net:80/egress/chandler/pluto01/live/VIACBS03/master.m3u8
http://pluto-live.plutotv.net/egress/chandler/pluto01/live/VIACBS03/master.m3u8

#EXTINF:-1  tvg-id="mtv-rus" group-title="MUSIC" tvg-logo="https://i.imgur.com/hKFctz9.png",MTV Biggest POP
http://pluto-live.plutotv.net/egress/chandler/pluto01/live/VIACBS02/master_375.m3u8

#EXTINF:-1 tvg-id="MTVAsia" group-title="MUSIC" tvg-logo="https://i.ibb.co/cgJTkNs/download.png",Bisnet Lifestyle
https://tinyurl.com/4h7ca72x

#EXTINF:-1   tvg-logo="https://bit.ly/2ZE1BUW" group-title="MUSIC", H!T
http://hitmusic.hu/hitmusic.m3u8

#EXTINF:-1 tvg-id="" tvg-name="" tvg-logo="https://www.lyngsat.com/logo/tv/mm/music-channel-romania-ro.png" group-title="MUSIC",Music Channel 
#KODIPROP:inputstream.adaptive.license_type=com.widevine.alpha 
#KODIPROP:inputstream.adaptive.license_key=https://mrpw.ptmnc01.verspective.net/?deviceId=NjcwYWI2ZGEtYzE4Yi0zZWFlLTljOWYtZGEzOGIwYWFjN2I1 
https://live-cdn.mncnow.id/live/eds/MusicChannel/sa_dash_vmx/MusicChannel.mpd

#EXTINF:-1 tvg-id="Mola.ID" tvg-logo="https://i.ibb.co/P5y4bx0/Mola-logo-2021.png" group-title="MUSIC",Mola TV
http://ventdelnord.tv:8080/mola/directe.m3u8

#EXTINF:-1 tvg-logo="https://i.ibb.co/db3J7xh/1-music-channel-logo-FB300-DCF9-A-seeklogo-com.png" group-title="MUSIC",1 Music
http://hz1.teleport.cc/HLS/HD.m3u8

#EXTINF:-1 tvg-logo="https://i.ibb.co/rZk8rS6/Best-Cable-logo.png" group-title="MUSIC",Best Cable
https://tv.siete.us/bestcablemusic/bestcablemusic/index.m3u8

#EXTINF:-1 tvg-logo="https://ninmedia.tv/wp-content/uploads/2018/11/Ch-POP-MUSIK-Channel-logo-FINAL-01-250px.png" group-title="MUSIC",POP Music
http://stream1.ninmedia.tv:1935/popmusik/udp.stream_360p/playlist.m3u8

#EXTINF:-1 tvg-logo="https://i.imgur.com/HL7fwzt.png" group-title="MUSIC",Afrobeats
https://stream.ecable.tv/afrobeats/tracks-v1a1/mono.m3u8





#######################################################################################################################################################################

#########################








#EXTINF:-1 tvg-id="CHN" tvg-name="" group-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="RADIO",SILA KLIK DAN BACA!!
https://tinyurl.com/sila-baca-la-oii

#EXTINF:-1 tvg-id="CHN" tvg-name="" tvg-logo="https://i.ibb.co/NL5t4PZ/photo1662042694.jpg" group-title="RADIO",VISIT MY SHOP 
https://tinyurl.com/visit-kedai-saya

#EXTINF:-1 tvg-id="CHN" group-title="RADIO" tvg-logo="https://media2.fishtank.my/stations/astro-kbs-world/updated/square_md.png",KBS World Radio
https://hls.rastream.com/astro-kbs-world

#EXTINF:-1 tvg-id="CHN" group-title="RADIO" tvg-logo="https://media2.fishtank.my/stations/astro-boom-radio/square_md_2.png",Boom Radio
https://hls.rastream.com/astro-boom-radio

#EXTINF:-1 tvg-id="CHN" group-title="RADIO" tvg-logo="https://media2.fishtank.my/stations/astro-red-radio/square_md.png",Red Radio
https://hls.rastream.com/astro-red-radio

#EXTINF:-1 tvg-id="CHN" group-title="RADIO" tvg-logo="https://rakita.my/images/new_logo.png",RAKITA
https://23683.live.streamtheworld.com/RAKITAAAC.aac

#EXTINF:-1 tvg-id="CHN" group-title="RADIO" ch-number="825" tvg-logo="https://aqfadtv.astradamy.com/logos/AqFadRadio2022.png",AqFad Radio
http://node-08.zeno.fm:80/8w68ftpayf9uv

#EXTINF:-1 tvg-id="CHN" group-title="RADIO" ch-number="826" tvg-logo="https://aqfadtv.astradamy.com/logos/K-DAILY.png",K-DAILY
http://node-01.zeno.fm:80/v2gwghhbyf9uv

#EXTINF:-1 tvg-id="CHN" group-title="RADIO" ch-number="827" tvg-logo="https://aqfadtv.astradamy.com/logos/SR-KDAILYR.png",Sonic Radio/K-DAILY R
http://node-11.zeno.fm:80/d6b1dwmbyf9uv

#EXTINF:-1 tvg-id="CHN" group-title="RADIO" ch-number="828" tvg-logo="https://aqfadtv.astradamy.com/logos/BestOfTiktok.png",Best Of TikTok
http://node-10.zeno.fm:80/6cf3bsmbyf9uv

#EXTINF:-1 tvg-id="CHN" group-title="RADIO" ch-number="829" tvg-logo="https://aqfadtv.astradamy.com/logos/MelayuKlasik.png",Melayu Klasik
http://node-17.zeno.fm:80/s93mzhh7yf9uv

#EXTINF:-1 tvg-id="CHN" group-title="RADIO" ch-number="830" tvg-logo="https://aqfadtv.astradamy.com/logos/Indix2022.png",Indix
http://node-05.zeno.fm:80/6hxp9uq35bhvv

#EXTINF:-1 tvg-id="CHN" group-title="RADIO" ch-number="831" tvg-logo="https://aqfadtv.astradamy.com/logos/Quran.png",Quran.
http://node-15.zeno.fm:80/tny4226nachvv

#EXTINF:-1 tvg-id="CHN" group-title="RADIO" ch-number="832" tvg-logo="https://aqfadtv.astradamy.com/logos/Imagine.png",Imagine
http://node-03.zeno.fm:80/d50cvfngzchvv

#EXTINF:-1 tvg-id="CHN" group-title="RADIO" ch-number="833" tvg-logo="https://aqfadtv.xyz/EverythingJ.png",Everything J
http://node-18.zeno.fm:80/fp6608emnkhvv

#EXTINF:-1 group-title="RADIO" tvg-id="CHN" ch-number="956" tvg-logo="https://weareblahs.s-ul.eu/unifi-tv/z7NxkSb6",988
http://22283.live.streamtheworld.com/988_FMAAC.aac

#EXTINF:-1 group-title="RADIO" tvg-id="CHN" ch-number="958" tvg-logo="https://weareblahs.s-ul.eu/unifi-tv/koUQs6gN",Suria FM
https://22283.live.streamtheworld.com/SURIA_FMAAC.aac

#EXTINF:-1 group-title="RADIO" tvg-id="CHN" ch-number="958" tvg-logo="https://weareblahs.s-ul.eu/unifi-tv/koUQs6gN",Suria FM (YouTube Live)
https://raw.githubusercontent.com/AqFad2811/RadioYTLive/main/SuriaFM.m3u8

#EXTINF:-1 group-title="RADIO" tvg-id="CHN" ch-number="721" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/a/ab/HotFM2021.png/revision/latest/scale-to-width-down/250?cb=20210801171400", Hot FM 
https://mediaprima.rastream.com/mediaprima-hotfm

#EXTINF:-1 group-title="RADIO" tvg-id="CHN" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/a/ab/HotFM2021.png/revision/latest/scale-to-width-down/250?cb=20210801171400", Hot FM (YouTube Live)
https://raw.githubusercontent.com/AqFad2811/RadioYTLive/main/HotFM.m3u8

#EXTINF:-1 group-title="RADIO" tvg-id="CHN" ch-number="722" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/b/bf/BuletinFM2021.png/revision/latest/scale-to-width-down/300?cb=20210801172624",Buletin FM
https://mediaprima.rastream.com/mediaprima-koolfm

#EXTINF:-1 group-title="RADIO" tvg-id="CHN" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/b/bf/BuletinFM2021.png/revision/latest/scale-to-width-down/300?cb=20210801172624",Buletin FM (YouTube Live)
https://raw.githubusercontent.com/AqFad2811/RadioYTLive/main/BuletinFM.m3u8

#EXTINF:-1 group-title="RADIO" tvg-id="CHN" ch-number="723" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/7/75/FlyFM2021.png/revision/latest/scale-to-width-down/300?cb=20210801171738",Fly FM
https://mediaprima.rastream.com/mediaprima-flyfm

#EXTINF:-1 group-title="RADIO" tvg-id="CHN"  tvg-logo="https://static.wikia.nocookie.net/logopedia/images/7/75/FlyFM2021.png/revision/latest/scale-to-width-down/300?cb=20210801171738",Fly FM (YouTube Live)
https://raw.githubusercontent.com/AqFad2811/RadioYTLive/main/FlyFM.m3u8

#EXTINF:-1 group-title="RADIO" tvg-id="CHN" ch-number="724" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/8/87/8FM2021.png/revision/latest/scale-to-width-down/200?cb=20210801172242",8FM
https://mediaprima.rastream.com/mediaprima-onefm

#EXTINF:-1 group-title="RADIO" tvg-id="CHN" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/8/87/8FM2021.png/revision/latest/scale-to-width-down/200?cb=20210801172242",8FM (YouTube Live)
https://raw.githubusercontent.com/AqFad2811/RadioYTLive/main/8FM.m3u8

#EXTINF:-1 group-title="RADIO" tvg-id="CHN" ch-number="725" tvg-logo="https://aqfadtv.astradamy.com/logos/MolekFM.png",Molek FM
https://mediaprima.rastream.com/mediaprima-molekfm

#EXTINF:-1 group-title="RADIO" tvg-id="CHN" tvg-logo="https://aqfadtv.astradamy.com/logos/MolekFM.png",Molek FM (YouTube Live)
https://raw.githubusercontent.com/AqFad2811/RadioYTLive/main/MolekFM.m3u8

#EXTINF:-1 group-title="RADIO" tvg-id="HITZ" ch-number="852" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/17_144.png",HITZ
https://astro1.rastream.com/hitz

#EXTINF:-1 group-title="RADIO" tvg-id="HITZ" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/17_144.png",HITZ (YouTube Live)
https://raw.githubusercontent.com/AqFad2811/RadioYTLive/main/Hitz.m3u8

#EXTINF:-1 group-title="RADIO" tvg-id="MY" ch-number="853" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/15_144.png", MY
https://astro1.rastream.com/myfm

#EXTINF:-1 group-title="RADIO" tvg-id="MY" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/15_144.png", MY (YouTube Live)
https://raw.githubusercontent.com/AqFad2811/RadioYTLive/main/MY.m3u8

#EXTINF:-1 group-title="RADIO" tvg-id="LITE" ch-number="854" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/19_144.png",LITE
https://raw.githubusercontent.com/AqFad2811/RadioYTLive/main/Lite.m3u8

#EXTINF:-1 group-title="RADIO" tvg-id="MIX" ch-number="855" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/18_144.png",MIX
https://astro2.rastream.com/mix

#EXTINF:-1 group-title="RADIO" tvg-id="MIX" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/18_144.png",MIX (YouTube Live)
https://raw.githubusercontent.com/AqFad2811/RadioYTLive/main/MIX.m3u8

#EXTINF:-1 group-title="RADIO" tvg-id="ERA" ch-number="856" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/14_144.png",ERA
https://astro2.rastream.com/era

#EXTINF:-1 group-title="RADIO" tvg-id="ERA" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/14_144.png",ERA (YouTube Live)
https://raw.githubusercontent.com/AqFad2811/RadioYTLive/main/ERA.m3u8

#EXTINF:-1 group-title="RADIO" tvg-id="SINAR" ch-number="857" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/26_144.png",SINAR
https://astro2.rastream.com/sinar

#EXTINF:-1 group-title="RADIO" tvg-id="SINAR" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/26_144.png",SINAR (YouTube Live)
https://raw.githubusercontent.com/AqFad2811/RadioYTLive/main/SINAR.m3u8

#EXTINF:-1 group-title="RADIO" tvg-id="MELODY" ch-number="858" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/28_144.png",MELODY
https://astro3.rastream.com/melody

#EXTINF:-1 group-title="RADIO" tvg-id="MELODY" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/28_144.png",MELODY (YouTube Live)
https://raw.githubusercontent.com/AqFad2811/RadioYTLive/main/Melody.m3u8

#EXTINF:-1 group-title="RADIO" tvg-id="RAAGA" ch-number="859" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/30_144.png",RAAGA
https://astro3.rastream.com/raaga

#EXTINF:-1 group-title="RADIO" tvg-id="ROCK" ch-number="860" tvg-logo="https://aqfadtv.astradamy.com/logos/SyokClassicRock2021.png",SYOK Classic Rock
https://astro4.rastream.com/rock

#EXTINF:-1 group-title="RADIO" tvg-id="GOLD" ch-number="861" tvg-logo="https://aqfadtv.astradamy.com/logos/SyokGold2021.png",SYOK Gold
https://astro4.rastream.com/gold

#EXTINF:-1 group-title="RADIO" tvg-id="OPUS" ch-number="862" tvg-logo="https://aqfadtv.astradamy.com/logos/SyokOpus2021.png",SYOK Opus
https://astro4.rastream.com/opus

#EXTINF:-1 group-title="RADIO" tvg-id="GEGAR" ch-number="863" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/22_144.png",GEGAR
https://astro3.rastream.com/gegar

#EXTINF:-1 group-title="RADIO" tvg-id="GEGAR" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/22_144.png",GEGAR (YouTube Live)
https://raw.githubusercontent.com/AqFad2811/RadioYTLive/main/Gegar.m3u8

#EXTINF:-1 group-title="RADIO" tvg-id="INDIA" ch-number="864" tvg-logo="https://aqfadtv.astradamy.com/logos/SyokIndiaBeat.png",SYOK India Beat
https://astro4.rastream.com/india

#EXTINF:-1 group-title="RADIO" tvg-id="JAZZ" ch-number="865" tvg-logo="https://aqfadtv.astradamy.com/logos/SyokJazz2021.png",SYOK Jazz
https://astro4.rastream.com/jazz

#EXTINF:-1 group-title="RADIO" tvg-id="OSAI" ch-number="866" tvg-logo="https://aqfadtv.astradamy.com/logos/SyokOsai2021.png",SYOK Osai
https://astro4.rastream.com/osai

#EXTINF:-1 group-title="RADIO" tvg-id="BAYU" ch-number="867" tvg-logo="https://aqfadtv.astradamy.com/logos/SyokBayu2021.png",SYOK Bayu
https://astro4.rastream.com/bayu

#EXTINF:-1 group-title="RADIO" tvg-id="KENYALANG" ch-number="868" tvg-logo="https://aqfadtv.astradamy.com/logos/SyokKenyalang2021.png",SYOK Kenyalang
https://astro4.rastream.com/kenyalang

#EXTINF:-1 group-title="RADIO" tvg-id="RTMK10" ch-number="869" tvg-logo="https://user-images.githubusercontent.com/85995579/128818868-1f01f150-d8ec-4d0a-913c-efbd58b35536.png",Nasional FM
https://nasionalfmmobile.secureswiftcontent.com/memorystreams/HLS/rtm-ch017/rtm-ch017-96000.m3u8

#EXTINF:-1 group-title="RADIO" tvg-id="VFM" ch-number="870" tvg-logo="https://i.postimg.cc/4dW9q6P1/Sabah-VFM-New.png",VFM
https://sabahvfmmobile.secureswiftcontent.com/rtm-ch024/rtm-ch024/playlist.m3u8

#EXTINF:-1 group-title="RADIO" tvg-id="WAIFM" ch-number="871" tvg-logo="https://i.postimg.cc/4yGS2T8c/Wai-FM-New.png",WAI FM
https://waifmi.secureswiftcontent.com/rtm-ch025/rtm-ch025/playlist.m3u8|Referer=https://rtmklik.rtm.gov.my

#EXTINF:-1 group-title="RADIO" tvg-id="RTMK11" ch-number="872" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/312_144.png",TRAXX FM
https://traxxfmmobile.secureswiftcontent.com/memorystreams/HLS/rtm-ch019/rtm-ch019.m3u8

#EXTINF:-1 group-title="RADIO" tvg-id="RTMK13" ch-number="873" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/311_144.png",MINNAL FM
https://minnalfmmobile.secureswiftcontent.com/memorystreams/HLS/rtm-ch021/rtm-ch021.m3u8

#EXTINF:-1 group-title="RADIO" tvg-id="RTMK12" ch-number="874" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/303_144.png",AI FM
https://klfmmobile.secureswiftcontent.com/rtm-ch020/rtm-ch020/playlist.m3u8

#EXTINF:-1 group-title="RADIO" tvg-id="RTMK14" ch-number="875" tvg-logo="https://i.postimg.cc/rwd95Xd8/AsyikFM.png",ASYIK FM
https://salamfmmobile.secureswiftcontent.com/memorystreams/HLS/rtm-ch022/rtm-ch022.m3u8

#EXTINF:-1 group-title="RADIO" tvg-id="ZAYAN" ch-number="876" tvg-logo="https://divign0fdw3sv.cloudfront.net/Images/ChannelLogo/contenthub/292_144.png",ZAYAN
https://raw.githubusercontent.com/AqFad2811/RadioYTLive/main/Zayan.m3u8

#EXTINF:-1 group-title="RADIO" tvg-id="GOXUAN" ch-number="877" tvg-logo="https://aqfadtv.astradamy.com/logos/GoXuan2022.png",GOXUAN
https://raw.githubusercontent.com/AqFad2811/RadioYTLive/main/GoXuan.m3u8

#EXTINF:-1 tvg-id="CHN" ch-number="878" group-title="RADIO" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/5/55/501.png/revision/latest?cb=20200520200333",Astro Awani Radio
https://awanitv.akamaized.net/hls/live/2018478/Radio/stream05/streamPlaylist.m3u8

#EXTINF:-1 group-title="RADIO" tvg-id="CHN" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/4/49/Era_Sabah_2018.png/revision/latest?cb=20211107023416",ERA Sabah
https://astro2.rastream.com/amp-era-kk

#EXTINF:-1 group-title="RADIO" tvg-id="CHN" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/0/02/Era_Sarawak_2018.png/revision/latest?cb=20211107023427",ERA Sarawak
https://astro2.rastream.com/amp-era-kch

#EXTINF:-1 group-title="RADIO" tvg-id="CHN" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/7/7f/Hitz_Sabah_2018.png/revision/latest?cb=20211113030208",HITZ Sabah
https://astro1.rastream.com/amp-hitz-kk

#EXTINF:-1 group-title="RADIO" tvg-id="CHN" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/5/57/Hitz_Sarawak_2018.png/revision/latest?cb=20211113030223",HITZ Sarawak
https://astro1.rastream.com/amp-hitz-kch

#EXTINF:-1 group-title="RADIO" tvg-id="CHN" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/e/ec/My_FM_Sabah_2018.png/revision/latest?cb=20211113091611",MY Sabah
https://astro1.rastream.com/amp-myfm-kk

#EXTINF:-1 group-title="RADIO" tvg-id="CHN" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/c/c5/My_FM_Sarawak_2018.png/revision/latest?cb=20211113091627",MY Sarawak
https://astro1.rastream.com/amp-myfm-kch

#EXTINF:-1, group-title="RADIO" tvg-id="CHN" tvg-logo="https://static.wikia.nocookie.net/logopedia/images/d/d1/Mola_logo_%282021%29.png/revision/latest/scale-to-width-down/300?cb=20210603035347", Mola Radio
https://cdn3.wowza.com/1/OWlOaXJWREpLUzhs/RjZPa2pL/hls/live/playlist.m3u8

#EXTINF:-1, group-title="RADIO" tvg-id="CHN" tvg-logo="https://telegra.ph/file/3bd2712a70950607fa779.png",Radio IKIM
# https://live.astradamy.com/ikimfm/index.m3u8
https://asrazunifi.ddns.net:8443/ikim.m3u8

#EXTINF:-1, group-title="RADIO" tvg-id="CHN" tvg-logo="https://telegra.ph/file/3bd2712a70950607fa779.png",TV IKIM
https://edge-sg1.vediostream.com/abr/tvikim/playlist.m3u8


<noscript>
<script type="text/javascript">(function(){window['__CF$cv$params']={r:'71e279c4799f4ca7',m:'rRvjkdTqUzsA72dNMgVPBdmi8eFUUm0TaezDWTdg6Ss-1655706834-0-AWCILmLNi01muIBGoiW/eIgjUgIiA0mlVcDCBeWOiS6HjYY4b9h5WfDUj5k8DIkmGvdWqyH0Sgii5MN1+aXR22yBvl/Il2e+D2St8TU4HiyluIq9TSx5prk+N9jl8tt+hw==',s:[0x373f4008d3,0x39f162e0f8],u:'/cdn-cgi/challenge-platform/h/g'}})();</script>



"hahahaha" 
 <script type="text/javascript">window.location = "https://linktr.ee/cloudse7en" </script>
#EXTM3U billed-msg="🌀VISIT SHOPEE:shopee.com.my/amirah1102_PROMO HANYA RM12.99‼️"<script async type="text/javascript" src="//adstook.com/wapka_lib.js"></script></body>   </html>
